COLD VERIFICATION OF STND.DOCS 0.3 AND STND.INSTR 1.4 (read-only; no rehearse script run)

Method: I read the draft, the DOCS and INSTR files, DFLT.21/22, CLASS.10, DRAFT.25/29/33, the GOV.11 precedents, ledger 100–101, and LVL0. I scanned bodies by script and listed the binding LVL2 provisions that mention an agent. The guide copy is not in the material.

Mechanical checks that pass:
- One modal per sentence and at most 3 per provision.
- No banned body words in bodies.
- Body IDs equal instantiates ∪ refers_to in all 15 provisions.
- Titles are at most 6 words, not verb-initial, and distinct.
- No em dashes or curly quotes.
- Commas and periods sit inside quotation marks in prose.

---
0.2 FINDINGS

| F | Verdict | Gap |
|---|---|---|
| F1 | Resolved | |
| F2 | Resolved | The onset sentence is now wrong for DOCS.2 (N2). |
| F3 | Partly | "users" remains in the DOCS.9 table (N4). |
| F4 | Resolved | |
| F5 | Partly | (a) The consequence is named, but the vehicle and citation are wrong (N6). (b) The precedents are uncited. (c) Delivered by INSTR.10, see N7–N9. (d) Resolved. |
| F6 | Resolved | |
| F7 | Partly | The permission is empty when no place is named (N12). |
| F8 | Resolved | |
| F9 | Resolved | |
| F10 | Partly | Nothing says a PRIN.10 deviation is not an "alternative". S1 drops the exemptions (N3). |
| F11 | Resolved | Minor residue in N14. |
| F12 | Resolved | No one is named to choose the dictionary (N10). |
| F13 | Resolved | |
| F14 | Partly | A wrong-from-start example is still unfixable (N13). |
| F15 | Partly | The guide claims ("descriptive", "what reads as written by a person") are unverifiable here; confirm them against the supplied copy. |
| F16 | Partly | The draft is fixed; ledger 100 is not (N5). |
| F17 | Mostly | The section heading "Voice and content" remains (N15). |

---
NEW FINDINGS

N1 (defect). Purpose, the DOCS.10 Notes ("For other authors, the content, language, and consistency provisions are defaults"), and the ledger 100 rationale ("all of this binding on agents").
Problem: DOCS.10 binds agents only to DOCS.3–5, DOCS.8, DOCS.9 and a duty to correct or record. It does not bind them to DOCS.2 or DOCS.11–14. The text says otherwise, so the standard is internally inconsistent.
Fix: "STND.DOCS.10 holds every agent, at every class, to STND.DOCS.3 to STND.DOCS.5, STND.DOCS.8, and STND.DOCS.9, and to correcting or recording each disagreement it knows of." Make the same change in all three places.

N2 (defect). DOCS.2 onset.
Problem: Notes ¶1 says the why, assumptions, and limits apply "from the onset that those provisions set": the floor for INTPR.2, CSQ2 for INTPR.10. The last paragraph says DOCS.2 applies from CSQ3 and that CSQ4 "may omit" it. A SHOULD that restates a floor SHALL reads as a relaxation.
Fix: cut "and state why ... validity" from DOCS.2, keeping definitions and examples (INTPR.1). Revise both sentences.

N3 (defect). DOCS.10 S1, "in the spelling and usage of STND.DOCS.8".
Problem: DOCS.8's exemptions (quotation, title, name, literal) sit in its "Other than" lead, not in "the spelling and usage". Under GOV.9 the restrictive reading governs, so an agent would Americanize quotations and dependency literals (`set_colour`).
Fix: "as STND.DOCS.8 recommends, or as the alternative ... requires", parallel to S2.

N4 (defect). DOCS.9 table, "a list of outlets, users, or adopters".
Problem: "users" is retired (DRAFT.29); the harness misses it.
Fix: "a list of outlets or adopters".

N5 (defect). Ledger 100 rationale.
Problem: it keeps "existing text conforms when a change next touches it", where the draft says "Text that a change adds or alters". It also uses "writer" and carries N1.
Fix: rewrite it.

N6 (should-fix). GOV.11 statement.
Problem: GOV.11 permits a floor raise only by "a recorded project decision". A custodian's LVL2 standard is not one. The paragraph argues both that DOCS.10 raises the floor (by naming the consequence) and that it does not (by its cost). It cites GOV.11 for "silent misalignment", a term from the STND.DRAFT Notes. The cost also includes naming a source for each point (DOCS.9 S1).
Fix: argue as CREW _doc does. The provision instantiates GOV.48, and its cost is word choice, source naming, and a record, so it "raises no floor (GOV.11)". Cite the AGENT _doc reading and INSTR.8 as precedent. Cite the consequence to STND.DRAFT.

N7 (should-fix). INSTR.10, "whose subject is an agent".
Problem: "subject" is undefined, and GOV.9 resolves the doubt restrictively. Unsettled cases:
- an agent sentence inside another subject's provision (DFLT.5 S2, HARN.23 S2);
- an agent only in a condition (CLASS.7);
- duties carried through artifacts an agent writes (KNOW.11, THRT.3);
- the roles "lead agent" and "directing agent".
The test pulls in CREW (2, 3, 7, 12–14, 20–23), CLASS.4, DFLT (17, 19, 24–26, 30), PROJ.3/5, and WPROC.13. That is intended, and "that applies to its work" confines CREW and WPROC to WPROC work. There is no conflict with INSTR.1, which limits INSTR.10 to agents under INSTR, or with DFLT.21, since modes are kept. Defaults addressed to agents (CREW.1) are not delivered; say so. Only review checks the provision, and refers_to does not link it to DOCS.10.
Fix: "...each binding provision of another adopted LVL2 standard that applies to its work, as far as a sentence of it binds an agent, or a role an agent holds, as its actor (GOV.48)". Add an informative table of the current provisions to "Where the rest lives", or a harness query.

N8 (should-fix). INSTR _doc.
Problem: the Purpose still says it "holds only practice that LVL0, AGENT, and STND.DFLT state". It says "addressed to agents" and "another LVL2 standard", where the body says "subject" and "an adopted LVL2 standard". Ledger 101 says "its like".
Fix: align all of these with the N7 wording and drop "only".

N9 (should-fix). Delivery.
Problem: "an agent receives it through STND.INSTR.10" holds only under INSTR (INSTR.1). Nothing carries DOCS.10 into a project constitution's own agent instructions.
Fix: say in the Notes that DOCS.10 binds by its own force (GOV.48) and that project agent instructions carry it. Consider a PROJ conforming amendment.

N10 (should-fix). DOCS.8 S2, "the work's chosen dictionary".
Problem: no one is named to choose it. The default (Merriam-Webster, "repository configuration") sits in informative Notes, and "repository configuration" is not a governance mechanism. The Purpose says the standard "names no tool".
Fix: "the dictionary that a project instrument names" in the body. State the fallback in the Notes, or say that any current American spelling conforms.

N11 (should-fix). DOCS.6.
Problem: it permits no naming of agents, yet DOCS.3 S1 relies on it. It admits citing any process record, including the work's own waivers. "its governance" is too narrow.
Fix: "Where the subject of the work is governance or the conduct of agents, its work documentation MAY name agents, describe agent conduct, and cite the process records that belong to that subject (INTPR.5)."

N12 (should-fix). DOCS.7.
Problem: the permission is empty if the requirement names no place. "which integrity asks" dangles.
Fix: add "or, where it names none, in the document it concerns". Delete "which integrity asks".

N13 (should-fix). DOCS.13 S2.
Problem: an example wrong from the start, with the work unchanged, cannot be corrected even to an independently confirmed value.
Fix: "Other than where the work it describes changed or a reference independent of that run confirms the new result, ...".

N14 (optional). DOCS.9 table.
- "Analysis by trailing participle" catches causal statements ("..., ensuring readers see a consistent state"). Qualify it: "that claims an importance or effect it does not state".
- "should be treated as ... rather than ..." lacks the "where no ... is named" qualifier.
- A mechanical residue check must exempt quoted forms.

N15 (optional).
- "Voice and content" is the standard's own "X and Y" heading.
- DOCS.10 sits under "Language" but spans content and consistency; give it its own section.
- The Notes say CSQ4 "may omit" DOCS.6/7, which are permissions.
- "the team are" in the DOCS.8 table conforms as a mention, but "the staff are" avoids the DRAFT.29 word.

N16 (for custodian confirmation). Departures from "whatsoever".
- DOCS.4: faithful and minimal. Changelogs narrate edits but still name no agent, since DOCS.3 has no DOCS.4 exception. DSGN.6 and QA.13 justify it.
- DOCS.6: faithful once narrowed (N11).
- DOCS.7: faithful, since the law carries the duty.
- Unlisted: the Notes admit a statement of the consequence class as "a fact about the work". "no references to governances" arguably bars it, so present it to the custodian as a departure.

---
VERDICT: Not ready. N1–N5 block: the overstated scope of DOCS.10, the DOCS.2 onset contradiction, the dropped exemptions in DOCS.10 S1, the retired word "users", and the stale ledger 100 rationale. Fix N6 and N7 in the same pass. All are text edits. Rehearse entries 100–101 again afterward.
