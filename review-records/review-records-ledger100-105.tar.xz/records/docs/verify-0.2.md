COLD VERIFICATION OF STND.DOCS 0.2 (read-only; no files changed; no rehearse script run)

Method: read the draft and the 11 per-provision files; LVL0, INSTR, DFLT, DRAFT.1-42, CLASS.10, WPROC, AGENT.2/3/4/5/17/25/47, CODE.10 and its _doc; the dispositions; the 13 pairs; findings.py on the rehearsed corpus; scripted scans of the draft for table words, quote/comma placement, dashes, curly quotes, and body words. I could not see the Wikipedia guide, only the custodian's summary of it.

Mechanical results that pass:
- Bodies contain none of "such as", "for example", "can", "will", "must", "is to", "need not", "significant", "any".
- Modals per provision: DOCS.3, .6, .8 and .9 have 3; the rest have 1-2.
- Every body ID equals instantiates ∪ refers_to, in all 11 provisions.
- Titles are ≤6 words, not verb-initial, and distinct across the corpus.
- No range citations in bodies. The References table is complete.
- No em dashes, curly quotes, bold or emoji in the draft.
- The only harness findings are 6 review-class ones: g.11 on DOCS.3 and DOCS.7, g.18 on DOCS.3, .6, .8 and .9.

---
DISPOSITION TABLE (0.1 rows)

| Row | Verdict | Remaining |
|---|---|---|
| C1, P13 (class onset) | Partly | Language and consistency are now defaults and DOCS.7 is added. DOCS.1/.3/.4 stay binding for every writer at CSQ4 with no GOV.11 argument (F6). DOCS.7's floor argument is thin (F5). The Notes range wrongly includes DOCS.7 (F2). |
| C2 (two senses of "documentation") | Resolved | Purpose still says work documentation "says nothing about" agents, which DOCS.4 and the changelog exception contradict (F17). |
| C3, P1 (Process record) | Mostly resolved | The list omits release record, incident record, roadmap. The principle omits "released" (F13). |
| C4, P3 (edit narration) | Resolved | DOCS.3 S2 vs REPRO.7 rejected-alternatives is unaddressed (F14). |
| C5, P7 (exception lead, negated list) | Partly | The exception leads. The negated list in DOCS.3 S1 and DOCS.7 S2 breaches DRAFT.15 (F8). |
| C6 (DOCS.4) | Resolved with a caveat | DOCS.4 S2 is a SHALL but the Notes say the requirement "binds on its own terms". The "place that the requirement names" is empty when none is named (F7). |
| C7, P6 (scope exclusions) | Resolved | |
| C8 (pedagogy, idioms, "only", "always") | Partly | DOCS.1 lacks "only". Nothing stops text addressed to an agent reader. "Always" is carried only for known inconsistency (F9, F10). |
| C9, P2 (attribution lines) | Resolved | The S3 label exemption covers the trailers. |
| C10 (Terms imports) | Resolved | "Work report" and "Workbench" are used but not imported (optional). |
| C11, C12, P12 (usage rows) | Partly | New false positives (F12). The Notes breach the punctuation row (F4). |
| C13, P11 (identifiers) | Resolved | The "touches it" scope is ambiguous (F16). |
| C14, P9, P10 (false positives, speculation row, decoration) | Partly | Remaining overbroad rows are listed in F11. |
| C15, P19 (source) | Resolved | One Notes claim about the guide cannot be checked (F15). |
| C16 (missing signs) | Partly | Still missing: abrupt cutoffs, robust, quietly, steady, matters, practical, plain "not X, but Y". The em-dash and curly-quote rows are misstated (F11). |
| C17 (checkability) | Resolved | "Knows" is weak (F9). |
| C18, P4 (transition, append-only) | Resolved | The scope of "touches" needs fixing (F16). |
| C19-C21 (drafting, self-conformance, Notes accuracy) | Partly | F1, F3, F4, F8, F17. |
| P5, P14 ("same change", "change", merges) | Partly | F1. |
| P15, P16 (DOCS.10) | Resolved with a caveat | A wrong example cannot be fixed (F14). |
| P17 (notation vs name) | Resolved | |
| P18 (review coverage) | Resolved | |
| P20 (duplicates) | Resolved | The synonym row now breaks DRAFT.17 (F3). |
| P21, P22 (reading copies, INSTR.6) | Not applied, as the dispositions say | Acceptable as a later harness unit. |

---
FINDINGS

Defects

F1. DOCS.8 S2, Notes paragraph on DOCS.8, and the Terms row "Work documentation". The Terms row excludes "governance text and project instruments" from work documentation. S2 and the Notes still treat a statement "in an instrument that only the human owner adopts" as a statement of the work documentation. Under the Terms it is not one. "Refer it" has no addressee. QA.5 already says report to the human owner and to whoever is responsible. If the addressee is the human owner, that is a decision outside GOV.50 (STND.DRAFT.42). The Notes claim "the writer of the change does not edit it", but QA.5 lets an actor fix a small, in-scope defect.
Fix: delete the instrument clause from S2 and the Notes, or amend the Terms row. Make S2 read "Where such a statement lies outside the version history of the work, the actor making the change SHOULD record it in defect tracking and report it as QA.5 asks (INTPR.3, QA.4, QA.5)". Cite QA.5 in instantiates.

F2. Notes, "STND.DOCS.7 is the floor ..." paragraph. The text says "STND.DOCS.2 and STND.DOCS.5 to STND.DOCS.11 ... instantiate provisions of the Articles that STND.CLASS.10 applies in full from CSQ3". DOCS.7 sits in that range. It instantiates GOV.48, not an Article, and binds agents at every class. The same paragraph calls DOCS.7 "the floor of the standard", but DOCS.1, .3 and .4 are equally binding, and "floor" is the GOV.10 term of art.
Fix: write "STND.DOCS.2, STND.DOCS.5, STND.DOCS.6, and STND.DOCS.8 to STND.DOCS.11". Replace "is the floor of the standard" with "is the agent rule of the standard".

F3. DOCS.3 S2 body and the DOCS.6 table label. DOCS.3 S2 uses "users", a retired word (STND.DRAFT.29; the harness does not check it). The same body uses "writer", which is not a defined role. The label "One thing under several names" uses "several" (DRAFT.17). The harness skips these.
Fix: "relying parties" for "users", "author" (LEX.author) for "writer", and "Synonym cycling" for the label.

F4. Notes, the "reads as written by a person" sentence. `plain "is" and "has", plain words ("used", not "utilized"; "wrote", not "authored")` places commas outside quotation marks in prose. That breaks the last row of the DOCS.5 table. The same sentence uses a "not X" contrast.
Fix: put the commas inside the quotes and recast, for example: write "used" for "utilized" and "wrote" for "authored".

F5 (should-fix, design). DOCS.7 and the GOV.48 route. The mode derivation is sound: the instantiates closure reaches GOV, as for STND.INSTR.8, and DRAFT.25 needs no binding_reason. Four weaknesses:
(a) GOV.11 allows a floor raise only by a recorded decision "naming the consequence that warrants it". The Notes give a cost argument and cite PRIN.10, but name no consequence.
(b) CLASS.10's precedent works only because GOV.48's own text names INTPR.11. The duties in DOCS.7 derive from INTPR.3 and INTPR.12, which GOV.48 does not name. Their binding at CSQ4 rests solely on calling the provision an "agent instruction".
(c) Agents receive instructions per DFLT.21 ("the agent instructions SHALL be [STND.INSTR's] provisions"), and INSTR.1 scopes INSTR to agents that take instructions from it. DOCS.7 is in neither, so an agent following its issued instructions never meets it.
(d) S1 cites only GOV.48 for a duty that is substantively INTPR.12.
Fix: state the consequence in the Notes. Suggested wording: reviewers verify agent-written text against the work (INTPR.1), and generated-prose habits and known false statements defeat that check at every class. Say outright that DOCS.7 is an agent instruction under GOV.48, citing the INSTR.8 and CLASS.10 precedents. Add INTPR.12 to the instantiates list and S1 citation. Either add a one-line INSTR provision that points to DOCS.7 (a minor amendment of INSTR in the same entry), or add an applicability clause to DOCS.7 modeled on INSTR.1 and extend DFLT.21.

F6 (should-fix). Binding DOCS.3 S1/S3 and DOCS.4 S2 for every writer at CSQ4. INTPR.2 says documentation is "for human readers first" and records why, assumptions and limits. It says nothing about naming agents or citing process records. Only the notes-to-self part follows from INTPR.5 ("by every actor"). The bans are non-waivable at CSQ4 for human writers. The closing Notes sentence ("ask for no documentation that the floor does not already require") answers volume, not prohibition. DOCS.4 S2 is the one binding provision that requires content.
Fix: record the GOV.11 argument. Or bind the agent parts of DOCS.3 through GOV.48 (like DOCS.7) and keep them default for people, except the notes-to-self ban, which INTPR.5 already supports. Make DOCS.4 S2 a permission ("MAY carry that statement, in the words and the place the requirement names"). The law carries the duty, and "permits" then matches DOCS.3's lead (see F7).

F7. DOCS.3 lead and DOCS.4 S2. DOCS.3 says "Other than as STND.DOCS.4 permits", but DOCS.4 S2 is an obligation. If a requirement names no place or wording, "the words and the place that the requirement names" is empty. Fix: "permits or requires" in DOCS.3, and "or, where it names none, in the documentation the requirement concerns" in S2. Alternatively adopt the permission wording from F6. Also split DOCS.4: the permission and the duty are applied apart (DRAFT.28).

F8 (should-fix). DOCS.3 S1 and DOCS.7 S2: negated lists. DRAFT.15 asks for one sentence per item. The dispositions kept the list as "review class", but DRAFT.15 is a default and has no exemption at LVL2. One sentence per item would make DOCS.3 five SHALL NOTs, which exceeds DRAFT.28. Fix: split DOCS.3 into three provisions (agents; edit narration; process records). The standard is not yet live, so renumbering is cheap. That also clears the 3-modal finding. For DOCS.7 S2, use a positive form: "an agent SHALL record in defect tracking, or correct, each statement it knows to disagree".

F9 (should-fix). Fidelity to "consistent with itself and the code", and to "for human readers only".
(a) DOCS.7 S2 binds only a statement the agent "knows" disagrees. An agent that never searches never knows. Define knowledge to include what the DOCS.11 search for the names a change alters finds.
(b) Nothing forbids text addressed to an agent reader inside work documentation (for example "If you are an AI assistant ..."). DOCS.3 covers notes to the writer or to a later session only. Add "address an agent" to the DOCS.3 agent provision. PRIME.11 treats such text as data anyway.
(c) The Notes' wording changes meaning: "false of the work or of the documentation" versus the body's "disagree with the work or with another statement".
(d) "Globally" is not interpreted. Say whether it means across the documentation set (DOCS.8 S3 covers that) or across projects (nothing covers it).

F10 (should-fix). DOCS.7 S1 scope and escape hook. The custodian said "everywhere and at all times". DOCS.7 reaches only human-facing writing and source names. It leaves out working-notes workspace entries, workbench entries, knowledge entries and briefs to directed agents. Spelling is cheap, so make the spelling rule cover all text an agent writes and keep the pattern rule for human-facing writing. The hook "or as the alternatives that a project instrument adopts" is what GOV.19 requires, and it is sound. A recorded deviation from a SHOULD (PRIN.10) is not an "alternative", so state which routes count. The Notes should say that "at all times" is limited to what GOV.19 allows.

F11. DOCS.6 table against the guide summary (task 3).
Missing:
- abrupt cutoffs (text ends mid-sentence or mid-structure);
- vocabulary: robust, quietly, steady, matters, practical. The Notes call "robust statistics" correct, so the word belongs in the table as praise. "Matters" and "practical" need a qualifier, for example "what matters" or "practical" used as vague approval;
- plain "not X, but Y" in the negative-parallelism row;
- refusal forms ("I cannot ...") in the stock summaries and refusals row.
Misstated:
- Punctuation by formula. The row restricts the sign to "spaced" em dashes. The guide's sign is em dash overuse, and chat output typically uses unspaced dashes. Fix: "em dashes, spaced or not, standing for commas, colons, or parentheses, or used more than occasionally". The clause "uniform short sentences" is not in the custodian's summary; drop it or verify it.
- Curly quotes. The row flags only a mix of curly and straight. The sign is typographic quotes and apostrophes in a plain-text medium. Fix: "curly quotation marks or apostrophes in a medium whose convention is straight ones".
- Notability by citation count. The name does not match the guide's sign (claimed notability or coverage). "Widely used" and "trusted by" are legitimate when sourced.
- Vague attribution. The tail "a marker of an incomplete list before a list that is complete" names no form. Give the form, for example "including" before a closed list.
Rows that forbid correct technical usage, with no escape in S3:
- Markup of another medium: "fenced blocks around content" bans every code example, and DOCS.2 asks for examples. Fix: "a fence around the whole text or around prose".
- Disclaimers that fill gaps: "should not be confused with" and "does not by itself establish" are exact statements ("passing one is never evidence of the other", VV.4). Add "where no specific limit or confusion is named".
- Change descriptions by formula: "preserved", "retained", "refined", "enhanced" are ordinary words. LVL0 uses them (RSRC.4, RSRC.7, DSGN.2, SIMPL.8) and the DOCS.10 Notes use "recaptured". Scope the row to a description of a change that gives no evidence. "A list of what was not changed" sits near AGENT.47's required statements of departures, so note the exception.
- Address to a requester: "Would you like ..." and "Let me know if ..." are the normal register of a message to the owner. The row's last clause applies to text left in documents. Say so, so DOCS.7 does not bar an agent's reply.
- Heading row: "a heading over no text of its own" matches the reading copy's group headings ("Provisions", "Voice and content"). Exempt prescribed structure explicitly.
- "Aligns with", "rich", "powerful", "leverage" rely on the S3 technical-sense exemption. That is acceptable, but add statistical leverage and fuel-rich to the Notes' examples if you want them to stay.

F12. DOCS.5 table.
- Overbroad or wrong: "aerial" (aerial survey, unmanned aerial vehicle), "torch" (plasma, welding and ICP torches), "mains" (water mains), "spanner" (spanner wrench), "spelt" (the grain), "square brackets" and "curly brackets" (both in common American use), "Monday to Friday" (current in American business use).
- Fix: qualify each as the electrical or tool sense ("aerial (antenna)", "torch (flashlight)", "mains (electrical)"). Drop the square brackets, curly brackets and "Monday to Friday" rows.
- "Analogue → analog" can contradict the dictionary rule in S1, since some dictionaries list "analogue" first for the noun.
- The "first spelling in a standard American dictionary" rule names no dictionary. Name one in a project instrument or in the Notes.
- Mentioned British words in the table breach S1 unless "a word mentioned as a word" is added to the exemptions.
- The "Used" column has no stated rule for 24-hour or other idioms. The idiom coverage is a few rows plus "usage", which is acceptable but incomplete. State that the table is not exhaustive. The Notes do.
- S1 carries two conditions (the "Other than" lead and "of two current spellings"), against DRAFT.16. Split the sentence.
- "Those of the tables of STND.DRAFT.33 and of this provision included" is awkward; reword.

F13. Process record term. Add "release record" (WPROC.14) and "incident record" (QA.15). Add "released" to the principle ("governed, built, reviewed, or released"). Say whether the consequence-class statement counts: "classification" is listed, so a README's "this is CSQ2" would be barred, yet INTPR.10 and PRIME.3 call for statements like it.

F14. Two substantive gaps in behavior.
- DOCS.3 S2 vs REPRO.7. REPRO.7 requires recording rejected alternatives and reasons, and allows the record as a comment. "Narrate the edits" is clear about edits but not about alternatives. Add a Notes sentence and example: "Backward Euler is used because the explicit method is unstable above step h" is documentation.
- DOCS.10 S2: the shown result changes "only with a change to the work". An example that was wrong from the start, or a spec-correct example the work gets wrong, cannot be repaired. Fix: "SHALL NOT be replaced by the output of the failing run unless the work it describes changed (VV.3, VV.8)". Delete "change only with".

F15. Notes accuracy.
- "agents already keep these out under STND.INSTR.8". INSTR.8 covers plans, notes, and the session account. It does not cover naming an agent or its instructions. Rewrite as: "STND.INSTR.8 already keeps plans, notes and session accounts out; STND.DOCS.3 adds naming of agents and their instructions and extends the rule to every writer."
- Scope of "human-facing documentation" (INSTR.8, the LEX gloss) versus "work documentation" is not stated. A work report is arguably documentation under INSTR.8 yet AGENT.2 requires an account of what the agent did. Add one sentence: work reports are human-facing writing, not work documentation.
- "A fabricated or unresolvable reference also breaches PRIME.2". Link rot is not a breach. Write "a fabricated reference breaches PRIME.2 and an unconfirmed citation VV.2".
- "The guide also lists what reads as written by a person ..." Not in the custodian's summary. Verify against the supplied copy; delete if absent.
- AGENT.3 (inferred/assumed marks) and PRIME.3 (unverified label) are not mentioned. Add them to the Notes as required labels that DOCS.6 S3 admits.

F16. Transition sentence. "Existing text conforms when a change next touches it" is ambiguous for names: it could force renaming a legacy API on any bug fix. Write "text that a change adds or alters". DOCS.7 binds "names it gives", which is consistent. GOV.42 expects the custodians to record the transition period. Say the ledger entry does.

F17 (optional). Purpose: "says nothing about the agents that helped write it" is contradicted by DOCS.4 and the changelog exception; add "except as STND.DOCS.4 permits". The imports line omits Work report and Workbench. DOCS.2's "limits of INTPR.10" is an inline citation and awkward; write "the limits of its validity (INTPR.1, INTPR.10)" and list INTPR.10 in instantiates. DOCS.2's "why, assumptions, limits" restates INTPR.2, which is a floor obligation; as a SHOULD from CSQ3 it can look like a relaxation. Say in the Notes that only first-use definitions and examples are new. Titles "Readers and voice", "Agents and governance as subject", "American spelling and usage", "Plain and specific statement" are all "X and Y" headings, a pattern the standard lists. "Revision History" is title case, which is prescribed. The DOCS.6 residue row contains the tool strings themselves, so any mechanical residue check must exempt quoted forms. DOCS.5 body has no `defines` for its table, unlike DRAFT.33.

---
Task 5 interactions (summary)
- INSTR.8: overlap handled except F15 and F5(c).
- REPRO.5, WPROC.2: consistent. Commit trailers are admitted by the S3 label exemption.
- CODE.10, PRIME.13: consistent. Constants' sources and safe ranges are not process records.
- PRIME.3, AGENT.3: unmentioned (F15).
- AGENT.2: consistent. The explanation goes in the work report or commit message, which are not work documentation.
- AGENT.17, AGENT.25: no conflict.
- STND.CODE.4 (suppression reason as the decision record): consistent with DOCS.3 S3.
- WPROC.8: Notes use is fine.
- Pairs DOCS.10 against CPS.3, HDES.6, HW.7, HW.CPU.3, HW.EMBED.5, ML.7: no conflict. DOCS.10 excludes hardware, and the Notes say the runs are not evidence.
- Pair list gaps: DOCS.7 has no pairs, and the LVL2 neighbours INSTR.8, CODE.10, WPROC and CLASS.10 are not paired. I checked them by hand (above).

Class onset: DOCS.1/.3/.4/.7 at every class; the rest from CSQ3, CSQ4 may omit. This matches CLASS.10. The sentence about INTPR.10 and CSQ2 is a no-op, since CSQ2 is more severe than CSQ3 and the stricter row already applies.

Answers to task 2
- Is the GOV.48 route sound for "everywhere and at all times"? Sound as a binding-mode mechanism, with precedent. Weak on the GOV.11 consequence, on delivery to agents (DFLT.21/INSTR.1), on scope (workspace, workbench and briefs are left out), and on "knows". F5, F9, F10.
- Does DOCS.7 raise the floor? Not in volume of documentation. The Notes' "raise no floor" is arguable at CSQ4 until the consequence is named. F5.
- Departures from the custodian's "whatsoever": the DOCS.4 carve-outs and the changelog exception. Ask the custodian to confirm them.

VERDICT: Direction and structure are sound and mechanically clean. Fix the 7 defects/should-fix items F1-F7 (the missing GOV.11 consequence, the DFLT.21/INSTR delivery gap, the DOCS.8/Terms contradiction, the Notes range error, the retired word "users" and the "several" label, the DRAFT.15 split of DOCS.3), correct the misstated and overbroad DOCS.6/DOCS.5 rows, then re-rehearse.

Nothing for memory.
