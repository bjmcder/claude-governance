# Verification of the rulings of 2026-10-23 (CODE 1.1, CXX, PY, JL 0.4)

Read-only. Body scans (modals, banned words, titles, body IDs, spelling) were clean. No struck name survives in any provision, Term, Note, or rationale, and no dangling reference remains (old PY.3, "Support window", "rule set", the restriction table). Counts and ATs match.

## Findings

### Defect

**D1. Dates (entries 102 to 105, `adopted`, Revision History, headers).** All say 2026-10-22, yet each cites the rulings of 2026-10-23. Entry 102 is "ratified on 2026-10-22" for a ruling "of 2026-10-23"; entry 104 is "ratified on 2026-10-22 and 2026-10-23". *Fix:* set DATE and AT to the ratification date (2026-10-23 or later) in content9/apply9 (the custodian's), content_cxx/py/jl, and apply_cxx/py/jl. Also 100 and 101 if they are ratified together.

**D2. The floor of CXX.29 is attributed to a ruling not yet made.** The last CXX Note says "That these binding provisions raise no floor … is the custodian's ruling of 2026-10-23", and that paragraph includes CXX.29. The rationale says "The custodian rules that the binding provisions raise no floor". The ruling covered only the agent-only and PRIME.4 rules, and decisions.md item 1 still asks for one on CXX.29. *Fix:* in both places, name STND.CXX.3 and STND.CXX.16 to STND.CXX.18. State CXX.29's own argument: it adds only the naming of the means to PRIME.2 and reaches only high-assurance code. Keep it on the decisions list.

### Should-fix

**S1. CXX.26 is now vague.** No build detects all undefined behavior, and the Notes no longer say which detection is meant. *Fix:* "…detects at run time invalid memory accesses and each kind of undefined behavior that the repository configuration lists, and fails…".

**S2. CXX.30, sentence 1.** No provision says where "the validation or qualification that the work requires" is stated. *Fix:* "…that the decision record of STND.CXX.28 states the work requires", and add STND.CXX.28 to refers_to.

**S3. The term "High-assurance coding standard" against "any standard".** It admits only standards that have their own deviation procedure. *Fix:* "…a procedure for recording deviations, its own or one that the adopting decision record sets".

**S4. CXX.31 against the Notes.** CXX.31 is a SHALL for all high-assurance code, but the onset Note calls it "required for the safety-related components … and recommended" elsewhere. The Note also says it tightens DSGN.3 and VV.1, while it instantiates only REPRO.7. *Fix (Notes):* "STND.CXX.31 requires the record of each deviation wherever such a standard is adopted (REPRO.7)."

**S5. CXX.16.** "enter, in code that commands physical hardware, the designed safe state" puts a second condition mid-sentence (DRAFT.16). PY.22 and JL.15 fixed the same phrase. *Fix:* "enter the designed safe state of PRIME.13 of the hardware that it commands".

**S6. JL Notes, Docstrings.** "lines of about 92 characters" is a configuration number. *Fix:* "a line length, which the repository configuration sets".

### Optional

- **O1. CXX.30, sentence 3.** The MAY admits an edition that sentence 1's SHALL excludes. Open sentence 1 with "Other than for a feature that a decision record admits under this provision,".
- **O2. Names outside hazard examples.** The CXX scope Note names MPI, OpenMP, and CUDA; use the Purpose's generic terms. The PY Docstrings Note names "NumPy, SciPy, and pandas"; use "major scientific libraries".
- **O3. CXX Notes.** Drop the dated "2026-06-14 … release 0.8".
- **O4. CXX Notes.** Drop "No provision requires a decision of the human owner … (STND.DRAFT.42)". It is drafting narration.
- **O5. CODE 1.1 (custodian's text).** "A layout tool … leaves these blank lines in place" is not true of every tool; write "Where the layout tool keeps…". "Once adopted" goes stale after entries 103 to 105, and the record name says 100-104.
- **O6. JL Versions Note.** Add "other than a long-term-support line" (recollection, unverified).
- **O7. Housekeeping.** PY decisions item 2 is stale (JL is now titled "Julia standard"). findings.log also holds a pre-existing g.12 note on INSTR.6.

### Checked and sound

- CXX.28 accepts any adopted standard, with its revision and procedure.
- CXX.29 is checkable and binding through PRIME.2. At CSQ4 it is vacuous or costs wording, so it raises no floor.
- The class order of CXX.28 to CXX.31 holds.
- CODE.13 is language-neutral, a default under INTPR.1, and consistent with CODE.5. PY, JL, and CXX cite it correctly.
- The PY renumbering is correct throughout the Notes and the rationale.
- No regression against either prior verification.

**Not checked:** the facts that are still marked unverified (no network).

## Rulings

| Ruling | Status |
| --- | --- |
| Floor judgments agreed | Partly (D2) |
| Keep as drafted | Applied |
| Shared: agnostic, project chooses | Partly (S6, O2) |
| CXX 1: any high-assurance standard | Partly (S3, S4) |
| CXX 2: no restriction table | Applied |
| CXX 3: validation status, no edition | Partly (S2) |
| CXX 4: newest supported edition | Applied |
| CXX 5: licensing | Applied |
| CXX 6: transition none | Applied |
| CXX 7: owning alias, no GSL | Applied |
| PY 8: versions, line length, tools | Applied |
| PY 9: remove PY.3, renumber | Applied |
| JL 10: latest, no pin | Applied |
| CODE.13 grouping | Applied |
| Ledger order | Partly (D1) |

## Verdict

**Not ready to present for ratification.** D1 misdates every entry against the rulings it cites. D2 records a custodian ruling that has not been made. Both are wording fixes in the modules. After they and S1 to S6 are made, a diff check is enough re-verification.
