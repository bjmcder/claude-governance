FINAL COLD VERIFICATION: STND.DOCS 0.4 (revision 1.0) AND STND.INSTR 1.4 (read-only)

Method: I read the drafts, harness files, the content8 diff, apply8.py, ledger entries 100 to 104, CLASS.10, and LVL0. Scans pass for modals, banned words, body IDs, titles, dashes, quotes, and spelling. The reading copies match the harness. There is no 0.3 disposition file.

## Findings

Defect
- D1. Ledger 100 (apply8.py RATIONALE) says DOCS.10 holds agents "to the content and language provisions". That takes in DOCS.1, 2, 6, and 7. Fix: copy the Purpose list (DOCS.3, 4, 5, 8, 9, and correcting or recording).
- D2. Ledger 101 keeps "an adopted LVL2 standard whose subject is an agent", which no longer matches the body. Fix: use the INSTR_ROW wording.
- D3. The Notes give no reasons for the departures from the direction ("everywhere and always"). For other authors, and for agents under DOCS.2 and DOCS.11 to 14, the rules are defaults that CSQ4 may omit. The statement of the consequence class is presented as "not a citation" (prior N16). Fix: add a Notes paragraph, "Departures from the direction". Give a reason for each departure: the defaults (binding them would raise the floor under GOV.11 and GOV.19 unless a project records that decision), DOCS.4's notices, DOCS.6, DOCS.7, the consequence-class statement, and DOCS.8's exemptions.

Should-fix
- S1. The last Notes paragraph says "STND.DOCS.2 to STND.DOCS.9 ... work of CSQ4 may omit them". That range takes in the permissions DOCS.6 and 7. GOV.9 would then remove DOCS.3's exceptions for agents at CSQ4, which DOCS.10 binds, and a statement that a license requires would be barred. Fix: list DOCS.2 to 5, 8, 9, and 11 to 14, and add "STND.DOCS.6 and STND.DOCS.7 are permissions, which STND.CLASS.10 does not stage."
- S2. DOCS.3 S2 excepts only DOCS.6, but a DOCS.7 statement describes agent conduct. Fix: "Other than as STND.DOCS.6 and STND.DOCS.7 permit, ...".
- S3. DOCS.10 S2 says "as STND.DOCS.9 recommends". DOCS.9's exemptions are a MAY, which is not a recommendation (the analog of prior N3). Fix: make DOCS.9 S3 an "Other than in a term of art in its technical sense, a quotation, ..." lead on S2.
- S4. The Notes say "the judgment is the custodian's, recorded here (PRIN.10)" before ratification, against shared decision 7. Fix: delete it and list the judgment for the custodian.
- S5. "The actor fixes it where it is small and within the scope of its unit" (Notes, consistency paragraph) is an obligation that no provision holds. Fix: delete it, or put it in DOCS.11.
- S6. "For other authors ... the content ... provisions are defaults" contradicts the binding DOCS.1. Fix: add "the other ..., apart from STND.DOCS.1".
- S7. The PY _doc and ledger 103 say PY.5 "binds ... through STND.INSTR.10" (prior N9). Fix: "binds by its own force (GOV.48); STND.INSTR.10 carries it", as the CXX and DOCS Notes say.
- S8. Ledgers 100 and 101 cite claude/drafts/docs-review.md, which the Project does not hold. Fix: write it before ratification, or cite the verification records.

Optional
- O1. DOCS.7 "absent one" is a condition after its clause, and DOCS.8 S2 joins two conditions. Split them.
- O2. "Globally consistent" in the Notes is a phrase that no provision uses. Attribute it or cut it.
- O3. "the team are" in the DOCS.8 table: use "the staff are" (prior N15).
- O4. Add a row to INSTR "Where the rest lives" for DOCS.10, CXX.3, and PY.5 (prior N7).
- O5. findings.log also has g.11 (INSTR.3) and g.12 (INSTR.6), which predate this amendment.

## STND.INSTR.10 delivery

The agent-only binding rules are DOCS.10 (S1 to S3), CXX.3 (S1 and S2), and PY.5. Each has an agent as the actor of each sentence, so INSTR.10 carries it. Each already binds by its own force under GOV.48. INSTR.10 therefore adds no obligation and raises no floor, and "that applies to its work" keeps each provision's scope. JL has no agent-only binding rule: JL.13 to JL.15 bind code under PRIME.4, as the PRIME.4 provisions of CXX and PY do, and none of these is carried, correctly. Apart from D3, the custodian's direction is met in the bodies. The cross-language shared rules were checked only for S7.

## Prior findings

| N | Status | Note |
|---|---|---|
| N1 | Partly | Standard fixed; ledger 100 not (D1) |
| N2 | Resolved | |
| N3 | Resolved | DOCS.9 analog (S3) |
| N4 | Resolved | |
| N5 | Partly | Transition fixed; D1 remains |
| N6 | Mostly | AGENT _doc reading uncited; S4 |
| N7 | Partly | Wording adopted; no table (O4); ledger stale (D2) |
| N8 | Partly | _doc fixed; ledger 101 not |
| N9 | Resolved | PY residue (S7) |
| N10 | Resolved | |
| N11 | Resolved | |
| N12 | Resolved | |
| N13 | Resolved | |
| N14 | Resolved | Residue-check exemption is a harness matter, not checked |
| N15 | Partly | Heading and section fixed; S1, O3 |
| N16 | Not | D3 |
| F15 | Not checkable | Guide copy, the exact words of the direction, and the Merriam-Webster "suggestion" are not in the material |

## Verdict

Not ready to present for ratification. D1 and D2 put false statements in the ledger, and D3 leaves the statement of departures that the direction requires undone. All are text edits in apply8.py and content8.py. Fix S1 to S3 in the same pass, because they decide what DOCS.10 binds an agent to at CSQ4. Then rehearse entries 100 and 101 again and resolve S8.
