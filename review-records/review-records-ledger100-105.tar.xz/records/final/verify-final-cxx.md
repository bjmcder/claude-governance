# Final cold verification: STND.CXX 0.3

**Checked:** the draft, its provision files, and `apply_cxx.py`, against verify-0.2, the dispositions, the brief, LVL0, DRAFT, CLASS, CODE, CPS, the PY, JL, and DOCS binding provisions, and the research. Scans found no fault in modals, banned words, titles, body IDs, binding mode (only 3, 16, 17, 18 reach PRIME or GOV, all binding), or spelling.

**Not checked:** the drafter's custodian decisions list (not on disk); vendor status pages (no network).

## Findings

### Defect

**D1. CXX.29, sentence 2.** It lets high-assurance code "use that feature", but sentence 1 says the unit SHALL be compiled at C++17. The Notes' candidates (concepts, `std::span`, `consteval`, `bit_cast`) all need `-std=c++20`, so the permission cannot be used. *Fix:* "…high-assurance code MAY be compiled at that later edition and use that feature and no other feature of that edition (REPRO.7)."

**D2. CXX.3, sentence 2.** It ties agents to "the edition that STND.CXX.2 gives" and, unlike PY.5 and DOCS.10, has no clause for a project alternative (GOV.19). An agent in a project that replaced CXX.2 cannot create a unit at the project's edition, because the exemption accepts only "the compiler or the rule set". *Fix:* "…older than the edition that STND.CXX.2, or the alternative that a project instrument adopts in its place, gives". In both sentences, widen the exemption to "the compiler, the rule set, the hardware contract, or the qualification of the toolchain that requires it".

### Should-fix

**S1. Notes hygiene (brief item 8).** These are unsourced and unmarked: fast-math deletes `isnan`; `__FINITE_MATH_ONLY__` is always 0 or 1; `integer`/`implicit-conversion` report defined behavior; the standard does not declare `expected`/`optional`/`error_code` `[[nodiscard]]`; type-level `[[nodiscard]]` covers `std::function`; "about 500 rules" (the research says "several hundred"); GCC's C++23 "ABI that is able to change"; close calls failing on a full disk. Mark each unverified, or omit it. `GSL_UNENFORCED_ON_CONTRACT_VIOLATION` is also unsourced, and I recall that GSL 3.0 removed it (verify).

**S2. Edition test (prior 6).** The Notes say the test "keeps a unit at C++20". From recollection, libc++ marks the C++17 parallel algorithms and some C++20 papers as partial, so a libc++ matrix may land lower. Say so, and confirm that this is on the decisions list.

**S3. The Notes misstate LVL0 or state obligations.**
- "Never … installs": PRIME.7 allows installation under a recorded authorization. *Fix:* "never buys them (PRIME.6) and installs one only under a recorded authorization (PRIME.7)".
- "Never from copied rule text" is an obligation. *Fix:* "the repository holds rule identifiers and diagnostics, not rule text".
- "Code takes the class of the most severe work it is compiled into (GOV.14)" contradicts GOV.14 ("not to its code"). *Fix:* "code compiled into CSQ0 work is used at CSQ0 (GOV.14)".

**S4. CXX.18, sentence 1.** CPS.5 and CPS.9 do not apply at CSQ4. On the reading "a check of that kind", sentence 1 raises the floor. *Fix:* open with "Where CPS.5 or CPS.9 applies to the work, …".

**S5. Onset paragraph.** It names only the lowering of an edition under CXX.3. Sentence 2 also costs a record when an agent creates a new unit at CSQ4, where CXX.2 may be omitted. State that, and list it among the custodian's decisions, as PY.5 is listed.

**S6. Sanitizer line.** `local-bounds`, `integer`, and `implicit-conversion` are Clang groups, and I recall that GCC rejects `local-bounds`. Prefix the line with "With Clang:".

### Optional

- **O1.** CXX.16: add commas, as in PY.23 and JL.15 ("enter, in code that commands physical hardware, the designed safe state").
- **O2.** The Purpose and the rationale say "delivers", but the term adds "or runs to produce a reported result".
- **O3.** Add MSVC `_M_FP_FAST` to the header guard.
- **O4.** The research marks MISRA's categories [R]; only MISRA Compliance:2020 needs "unverified".
- **O5.** The deferral that the Notes attribute to STND.WPROC.9 is under RSRC.12; cite it.
- **O6.** Add this report to the records list in the rationale.

### Focus questions

- **Floor at CSQ4:**
  - CXX.16 lists only PRIME.4's responses and the shared propagation forms, which match PY.23 and JL.15. It does not raise the floor.
  - CXX.17 costs one attribute per declaration. That is the same kind of tightening of PRIME.4 that CODE.6 and CODE.7 make, so it is acceptable under that precedent.
  - CXX.18, sentence 2, asks only what CODE.6 asks; sentence 1 needs S4.
  - CXX.3 is an agent-only rule under GOV.48 that costs one sentence; it is acceptable after D2.
- **Scope and class order:** CXX.28 covers all delivered code of CSQ1 and CSQ0 work, and CXX.30 is a SHALL for safety-related components at CSQ0 and a SHOULD elsewhere. No CSQ0 code gets less than CSQ1 code, so CLASS.18's order holds.
- **Technical claims:** the finite-math, contraction, `unused-result`, UBSan grouping, hardening-macro, MISRA (C++17, TC1, vendor claims), and JSF/JPL claims are accurate as far as I can check offline.
- **Rationale:** it matches 0.3 (31 provisions; binding 3, 16, 17, 18; transition; AT 12:10).

## Prior findings (verify-0.2)

| # | Status |
| --- | --- |
| 1 | Resolved (O2) |
| 2 | Resolved |
| 3 | Resolved (S6) |
| 4 | Resolved (S1) |
| 5 | Resolved |
| 6 | Partly (S2) |
| 7 | Resolved |
| 8 | Resolved |
| 9 | Resolved (S3) |
| 10 | Resolved |
| 11 | Resolved |
| 12 | Resolved (S5) |
| 13 | Resolved |
| 14 | Resolved |
| 15 | Resolved |
| 16 | Partly (D2) |
| 17 | Resolved |
| Carried S5 (GSL) | Partly (S1) |

## Verdict

**Not ready to present as it stands.** D1 and D2 are one-sentence fixes; make S1 to S3 with them. After that it is ready for ratification, and checking the diff is enough re-verification.
