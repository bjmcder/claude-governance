# Final cold verification: STND.PY 0.3 and STND.JL 0.3

Read-only. I read both reading copies, the provision files, the content and apply modules, the prior verifications and dispositions, both research notes, LVL0, DRAFT.16, DRAFT.42, PROJ.3, and both logs. A scan of all 66 bodies was clean: body IDs equal instantiates ∪ refers_to, at most three modals per provision and one per sentence, no banned words (the only hit was the type name "Any"), and distinct titles of at most six words. `verify` passes, with g.18 and g.14 notes only. The Notes contain no "recorded here" and no drafting narration.

## Findings

### Defect

**D1. PY.23 against JL.15 (shared rule 1), and the PRIME.4 floor at CSQ4.** PY.23 asks for a response "beside each record of the condition that it writes to a logger", and the Notes (Reporting) say "the logger record is no part" of the response. JL.15 instead counts a log record at `Warn` or `Error` as visible degradation. PRIME.4 accepts any visible degradation with a diagnosis. Under PY.23, an entry point that configures a handler, writes `log.error("no convergence; using last iterate")`, and continues degrades visibly, yet it breaches a binding provision at CSQ4. PY's reason for the rule (PY.22's NullHandler silences library records) holds only for library code.

*Fix:* delete the "beside…logger" phrase. Add as sentence 3: "A record that library code writes to a logger SHALL NOT be the only visible degradation (PRIME.4)." That makes three modals. In the Reporting Notes, write "of which a record from library code is no part; an entry point whose handler shows the record degrades visibly through it."

### Should-fix

**S1. PY.15 version combinations (prior PY-3, only partly fixed).** The research note says "NumPy 2.5.0 supports Python 3.12 to 3.14; 3.15 support starts at its first release candidate", and that sentence is ambiguous. The Notes conclude "NumPy 2.5 supports Python 3.12 to 3.14, so the oldest and the newest combinations … are different environments". That does not follow, and it suggests that the newest combination (3.15 with NumPy 2.5) does not exist. The problem recurs: each October a new Python can come out before some core package (SciPy) supports it, and PY.15 then cannot be met.

*Fix:* "…and on the newest Python feature release that the newest release of each core package supports, with those releases (VV.8)." In the Notes, either state the 3.15 support status as unverified or drop the "so" clause.

**S2. PY.17 against PY.18 and JL.23 (shared rule 5).** PY.17 exempts only "a generator spawned from another". So `PCG64.jumped()` or a counter-based generator keyed in library code, both of which PY.18 admits, breaches PY.17. JL.23 exempts "a generator that STND.JL.24 derives".

*Fix:* "Other than a generator that STND.PY.18 derives, …", and add STND.PY.18 to refers_to.

**S3. JL.14 title "Resource exhaustion rethrown".** After the fix of prior JL-2, the body allows every response of JL.15, so the title misstates the provision.

*Fix:* "Resource exhaustion in catch blocks".

### Optional

- **O1. PY.23 and JL.15 sentence 1.** The phrase "enter, in code that commands physical hardware, the designed safe state" puts a second condition mid-sentence (DRAFT.16). *Fix in both:* "enter the designed safe state of PRIME.13 of the hardware that it commands".
- **O2. PY.28 title "Exhaustion in broad handlers".** The body also covers handlers that name MemoryError directly. *Fix:* "Exhaustion caught by handlers".
- **O3. PY Notes, Departures.** "asks for nothing that the floor of GOV.10 excludes" misstates the test. *Fix:* "costs only the form of the code it writes, so it does not raise the floor (GOV.11, GOV.48)". PY.5's "or changes" reaches the unannotated parameters of a legacy function that an agent edits in one line. Confirm that reach within the PY.5 floor decision.
- **O4. PY Notes, Floor.** It says PY.26, PY.28, and PY.31 "forbid only a construct", but PY.28 sentence 1 and PY.31 ask for a response. *Fix:* "ask only for a response that STND.PY.23 gives, or forbid a construct that leaves a listed condition without one".
- **O5. PY Notes, Versions.** The research note gives the 3.15.0 release as 2026-10-09 and does not flag it [verify]. *Fix:* "released on 2026-10-09", and drop "unverified" (brief item 8).
- **O6. JL.34 (g.18).** The deprecation sentence applies apart from the two bounds-checking sentences. Split it out as JL.35 "Deprecations fail test runs", or record the g.18 acceptance.
- **O7. Fidelity to the directions.** JL.6's underscore rule departs from the manual that the Julia direction names. PY.6's exclusion of notebooks departs from "always" in the Python direction. The Notes state and justify both, but neither is in the decisions list. Add both.

### Checked and sound

- **Binding provisions.** PY.28 and JL.14 match brief item 2, and PY.31 is brief item 3's single sentence. PY.26 and JL.13 ask only what PRIME.4 requires under the shared "Untrusted input" Term. PY.5 is an agent-only rule under GOV.48, and PROJ.3 covers the checker (DRAFT.42).
- **Shared rules.** The exact-comparison MAY is identical in PY.21 and JL.21 and not restated in the Notes. PY.18 and JL.24 word the streams the same. Both classify performance approximations in the Notes only.
- **JL.34 merge.** Sentence 2 opens "Other than that run", so the contradiction is gone. Under the default `--depwarn=no`, the production run raises no deprecation warnings, so sentence 3 does not conflict.
- **Rationales.** The counts (32, 34) and provision numbers match 0.3, AT is 12:20 and 12:30, and the only ledger number is the shared TAIL's entry 15.
- **Directions and facts.** All four Python directions and both Julia directions are carried. The release and tool facts I spot-checked match the research notes.

**Not checked:** the custodian cover messages with the decisions lists (not on disk), and whether `Future.randjump` and Random123.jl run on 1.13 (the drafts mark both unverified).

## Prior findings

| Prior | Status |
| --- | --- |
| PY-1 (PY.32 confinement) | Resolved (PY.31) |
| PY-2 (PY.29 narrowing) | Resolved (PY.28) |
| PY-3 (PY.16 combinations) | Partly: S1 |
| PY-4 (sampler fact) | Resolved. The research note, §8, supports it, so the verifier's premise was wrong |
| PY-5 (response set) | Resolved, but D1 is new |
| PY-6, 7, 8 | Resolved |
| PY-9 (stream facilities) | Partly: S2 |
| PY-10 to 17 | Resolved (PY-13: decisions list unseen) |
| PY-18 (ledger order) | Resolved (AT 12:20) |
| JL-1 (JL.34/35) | Resolved |
| JL-2 (JL.14/15 narrowing) | Resolved, but S3 (title) |
| JL-3 to 17 | Resolved |
| JL-18 (`isapprox` details) | Declined, with a sound reason (unsourced) |
| JL-19 to 21 | Resolved |
| JL-22 (PY consistency) | Resolved on the PY side (PY.19 s2, PY.21 MAY, PY.32 trimmed) |

## Verdict

**Not ready to present for ratification yet.** One defect remains. D1: binding PY.23 forbids, at CSQ4, a visible degradation that PRIME.4 accepts, and it diverges from JL.15 on the shared response list. The fix is wording only. After D1 and S1 to S3, which are also wording changes, both standards are ready to present without another review round. The PY.5 floor, the reach of "Untrusted input", and O7 go to the custodian as listed decisions.
