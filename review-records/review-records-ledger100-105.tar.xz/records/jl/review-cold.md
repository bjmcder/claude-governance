# Cold review of STND.JL 0.1 (condensed by the lead agent from the reviewer's report)

Facts about 1.13 come only from the research note and are unverified.

## Fidelity and the version rule

1. **(S) JL.1 does not deliver "latest".** The reference version moves only at a DEPS.4 review (at most every 12 months), and 1.12 lost support the day 1.13 shipped. A floor equal to the reference admits 1.14 and later, which are never tested. JL.1 also drops the DEPS.3 clause "consistent with the rest of the environment".
   - Fix: add a trigger tied to a new stable minor release, or to the end of the publisher's support for the reference.
   - Fix: add the DEPS.3 consistency clause.
   - Fix: add a scheduled, informational check on `1` and `pre`.
2. **(S) /en/v1/ is a moving alias.** State that the manual of the reference version governs (`/en/v1.13/`). List every departure from the manual and its source:
   - underscored function names;
   - `# Returns` and `# Throws`;
   - explicit imports;
   - the pinned formatter.
3. **(S) JL.2 scope.** Use "each `Project.toml` of the work", so analysis environments are covered as well as packages. Mention stdlib compat entries (verify).
4. **(S) Manifest.** The Notes sentence "work that reports results keeps its manifest under version control" is an obligation sitting in informative text. Make it a default (REPRO.9, REPRO.1). Libraries commit no manifest (verify); applications and result-producing work do. Mention `Manifest-v1.13.toml`. "It runs that tool's own tests" has the same problem.
5. **(S) Open choices left for the custodian.** The Notes say "the choice the custodian decides" and "a choice for the custodian". Record the decision as taken, or remove the sentences.

## Technical correctness

6. **(D, verify) `checkdocs`.** Documenter `checkdocs` reports docstrings missing from the manual, not public names without a docstring. Add `Docs.undocumented_names(Pkg)` (1.11+), asserted empty in tests. `modules` is required; `setdocmeta!` only provides setup.
7. **(D, verify) JL.13 BigFloat.** Passing the precision to each constructed value does not control arithmetic precision, because results take the current default. Delete that alternative. Keep only the function forms, or `@with`/ScopedValue. Note that `big"..."` literals fix precision at parse time.
8. **(D) Naming attribution.** The manual prefers squashed lowercase function names and uses underscores "when necessary". The JL.3 row follows Blue/SciML; say so and give the reason. SciML marks internal names with `__`; the one-underscore rule is Blue's. Handle macros and mathematical notation (`A`, `Q`, `Σ`, `H`) via DOCS.9.
9. **(S) JL.3 sentence 3.** It contradicts the Mutating function Term (`Random.seed!`). Apply the exclusion only to sentence 1, and allow `!` for IO or RNG mutation. Neither sentence covers mutation of non-argument state, and the manual's argument-order rule is dropped without saying so.
10. **(S) JL.5 Type piracy Term.** It flags `Base.convert(::Type{MyT}, ...)`, `promote_rule`, `zero(::Type{MyT})`, and `eltype`. Count `Type{Owned}` and owned type parameters as owned, as Aqua does. Aqua exclusions follow CODE.4.
11. **(S) Type-stable call Term vs the tools.** `@inferred` checks the return type, and JET `@test_opt` checks runtime dispatch; neither checks locals. Define the property as no runtime dispatch plus a concrete or small-union inferred return type. Use the allowed-type form of `@inferred` for Nothing/Missing. In JL.7, write "limit inference".
12. **(S) JL.8.**
    - `@assert` "might be disabled at certain optimization levels"; no setting removes it today. Reword to "a check the language does not promise to keep".
    - Add `@boundscheck`, which `@inbounds` and `--check-bounds=no` elide; that is the likelier trap.
    - An unmarked `A[i]` with an untrusted `i` also falls under sentence 2. Give the idiom `checkbounds(Bool, A, i) || throw(BoundsError(A, i))`.
    - Use the Term "Execution setting" (STND.CODE).
    - A configured list of untrusted entry points would make the rule decidable.
    - The transition sentence cannot apply to a binding provision; limit it to the defaults.
13. **(S) JL.9.**
    - "Changes results" should be "can change results".
    - `@fastmath` also ignores signed zeros and permits contraction.
    - Add `muladd`/FMA contraction, `--math-mode=fast`, `@assume_effects`, and `unsafe_*`.
    - Sentence 2 only classifies; it does not weaken the SHALLs of NUMER.16 and NUMER.17.
    - The title omits subnormals.
14. **(S) JL.10 and JL.11.**
    - Tasks created deterministically already give scheduler-independent streams (Random docs). State when per-part generators are needed.
    - Seeding by `seed+i` or `hash` gives no independence evidence (NUMER.24), and `hash` changed in 1.13. Cite NUMER.24 and forbid `hash` for seed derivation.
    - Allow the generator to be carried in a state struct (CODE.2 "through its interface").
    - "Entry point" needs defining for tests.
    - `seed!` seeds the current task's stream.
    - `threadid()` can exceed `nthreads()` with the interactive pool.
15. **(S, verify) JL.12.**
    - StableRNGs fixes the generator stream, but `randn`, `shuffle`, `randperm`, and `rand(rng, 1:n)` may change across versions.
    - `Dict`/`Set` iteration order depends on `hash`. Add an order-independence clause.
16. **(S) JL.16 doctests.**
    - Seeded `Xoshiro` output changes when the reference moves. Use StableRNG, or show output that does not depend on the seed.
    - `jldoctest` matches exactly, while DOCS.10 wants a tolerance. Require rounded output or a `filter`.
17. **(S) JL.14.**
    - The signature rule does not fit modules, types, or constants. Scope it to functions and methods, and put module docstrings above `module`.
    - "Each heading a first-level heading of the table" bans `# Fields`.
    - No row holds the CODE.3 contract.
    - Fix: add rows for Fields and for Contract or Notes.
18. **(S) JL.15.** "Each generic function SHOULD carry one docstring" reaches internal helpers and Base functions the work extends. Write "Each documented generic function".
19. **(S) JL.4.**
    - Sentence 3 flags Base names not marked `public`.
    - Extensions and tests legitimately use internals; allow ExplicitImports `ignore` with a reason.
    - "Supported" is a judgment.
    - "public and export on one name is an error from 1.12" is unverified.
20. **(O) JL.18.**
    - `--check-bounds=yes` and coverage change inlining. Run allocation and inference assertions in a separate job.
    - `--depwarn=error` fails on dependency deprecations; say where exclusions go.
    - Verify the 1.13 `Pkg.test` claim.

## Conflict and duplication

21. **(S) Restatements.**
    - JL.8 restates CODE.6 (acceptable).
    - JL.14 sentence 2 restates CODE.3.
    - JL.20 adds little beyond DEPS.9 and DEPS.8.
    - JL.17 duplicates JL.2 on compat.
    - Soften the Purpose claim that the standard "restates neither", or merge JL.20 into the Notes.
22. **(O) Class onset.**
    - Treat DSGN.3 (its CSQ0 part) and DSGN.15 (its CSQ2 verification part) as DSGN.2 is treated.
    - Write "may omit". JL.8's mode is correct.

## Checkability

23. **(S) Mechanize the simple checks.** JL.7, .9, .10, .11, .13, and .19 can be checked by grep:
    - `threadid(`;
    - `Random.seed!` outside entry points;
    - global `setprecision(`;
    - `@inbounds` without a comment;
    - `≈` without tolerances;
    - bare `rand(` in doctests;
    - `@assert` in `src`.

    Add a "source greps" row with the false-positive caveat. "Numerical kernel" needs a configured list. JL.17 says "static check" but Aqua loads the package.

## Drafting

24. **(S) Drafting rules.**
    - JL.1 sentence 2 has two conditions (DRAFT.16).
    - JL.3, JL.4, and JL.14 sentence 1 are bundles applied apart (DRAFT.28); split them.
    - JL.20 misdescribes CODE.5.
    - The imported Term "Work documentation" is unused.
    - JL.2 "bound with an upper limit" leaves inclusivity implicit (DRAFT.18).
    - The title "Per-task state and streams" misfits its content.

## Prose

25. **(S/O) Prose.**
    - Strip the rehearsal narration from the header.
    - "Together serve as the dependency record" avoids the copula; use "are".
    - "It is not an optimization that RSRC.4 holds back" is a negative parallelism.
    - The antecedent of "whose record states why" is unclear.
    - Do not cite the unadopted STND.PY.
    - Split the dense Notes paragraphs by provision.

## Gaps

26. Gaps to consider:
    - **(S) Result-affecting run settings.** Record thread count, BLAS vendor and threads, `-O`, `--math-mode`, `--cpu-target`, and `--check-bounds` (REPRO.2, NUMER.5).
    - **(S) Shared-state data races (DSGN.15).** Add a default: locks or atomics for shared mutable data, and no accumulation into a shared scalar inside `@threads`.
    - **(O)** Precompile-time state.
    - **(O)** Error types and swallowing `catch`.
    - **(O)** Package extensions, `[weakdeps]`, and workspaces.
    - State that Distributed, GPU packages, juliac/trim, and Pkg apps are out of scope.

Verdict: the structure, mode assignment, and drafting hygiene are good. Fix 1 to 5 (version lag, tool mapping, BigFloat remedy, naming attribution, @assert premise) before ratification.
