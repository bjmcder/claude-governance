# Dispositions of the cold verification of STND.JL draft 0.2

Numbers are those of draft 0.3, which has 34 provisions. JL.35 merged into JL.34; JL.19 sentence 2, JL.24 sentence 2 and JL.31 sentence 3 moved to the Notes or merged.

| # | Finding | Disposition |
| --- | --- | --- |
| 1 | JL.34 contradicts JL.35 | **Fixed.** Merged into JL.34. Sentence 1 is the production-configuration run. Sentence 2 opens "Other than that run" and forces bounds checks. |
| 2 | JL.14 and JL.15 allow fewer responses than PRIME.4 | **Fixed per brief items 1 and 2.** JL.15 ("Julia responses to listed failures") now lists every response: throw, halt with a diagnosis, the designed safe state of PRIME.13, visible degradation with a diagnosis, or a returned condition. A log record counts as visible degradation only at `Warn` or `Error`. JL.14 now says "respond as STND.JL.15 requires". The Notes now say "one of the responses that PRIME.4 already allows". |
| 3 | Patch revision, qualified revision, HW.7 | **Fixed.** JL.3 sentence 1 now reads: other than where a qualified revision fixes it, the Julia revision of the production configuration and of the checks is the latest patch of the reference version. JL.1 sentence 3 lets both stay at a qualified revision. The Production configuration Term now includes the Julia revision. The Notes state that a patch move is a runtime change under HW.7 and STND.DEPS.5. |
| 4 | Entry point Term too narrow | **Fixed.** The Term now covers "a program, a test, a script run directly, or a documentation example". |
| 5 | Library code excludes package extensions | **Fixed.** Extensions are now library code. JL.9 sentence 2 opens "Outside the use that a package extension makes of the package that it extends". |
| 6 | JL.13 sentence 3 reaches `eachindex` indices | **Fixed.** The Untrusted input Term excludes an index from `eachindex`, `axes` or `CartesianIndices` of the indexed array, as valid by construction. |
| 7 | JL.6 and JL.7 flag methods of external functions | **Fixed.** JL.6 sentence 3 adds a MAY: a method of a function that no module of the work defines keeps that function's name, with or without `!`. |
| 8 | JL.19 sentence 2 restates HW.CPU.3; antecedent; `@async` | **Fixed.** Sentence 2 moved to the Notes as a statement of HW.CPU.3. The remedy now rests on operations that do not yield. The claims about migration only at yield points and about `@async` remain unverified, because the research note does not support them (brief item 8). |
| 9 | `--depwarn=error` is session-wide; table caveat; runtest row | **Fixed.** JL.34 sentence 3 now reads "each deprecation warning that a run raises SHOULD fail that run", unless listed. The table row adds `depwarn: error`, and its caveat now describes `--depwarn=yes` plus `@test_logs` or a collecting logger for listed exemptions. |
| 10 | Purpose claims nothing restates STND.CODE | **Fixed.** The Purpose now names JL.13 for CODE.6, JL.14 and JL.15 for CODE.7, and JL.16 and JL.21 for CODE.12 and CODE.10. JL.16 now admits a discard that carries the reason of STND.CODE.12. |
| 11 | Class onset: "static checks"; NUMER/HW scope | **Fixed.** Now "mechanical checks (DSGN.3)". The NUMER/HW sentence now reads "the part of each default that rests on NUMER, HW.7, or HW.CPU.3 applies only to work those profiles bind; its other parts apply to all work". |
| 12 | Docstrings Notes misstate DOCS.13 | **Fixed.** The Notes now state the DOCS.13 condition descriptively; `doctest = :fix` is named as the means on that one occasion. |
| 13 | `Future.randjump` missing; JL.24 sentence 2 | **Fixed per brief item 8.** `Future.randjump` is named in the Notes and marked unverified for 1.13, since the research note does not mention it; Random123.jl is marked the same way. JL.24 sentence 2 (on `hash`) moved to the Notes. JL.24 now says "generator library", per brief item 5. |
| 14 | Drafting narration; over-hedging; setprecision | **Fixed.** The narration of the research is removed. "Unverified" is dropped from the `export`+`public` error (1.12) and the `Pkg.test` change (1.13), both [S] in the research note. The JL.20 Note now states the 1.12 thread safety of `setprecision` with a function argument [S]. |
| 15 | Overflow called "silent continuation" | **Fixed.** Now described as invalid input that passes the checks of DSGN.2 undetected. |
| 16 | "Replaces the second sentence" reads as an obligation | **Fixed.** Now "may replace". |
| 17 | (O) Size and merges | **Fixed.** All the merges listed: JL.34 with JL.35; JL.31 sentence 3 removed, since JL.25 covers exact drawn values and the Notes place output-independent doctests outside it; JL.19 sentence 2 and JL.24 sentence 2 moved to the Notes. Restating sentences in the Failures, Arithmetic, Randomness and Comparisons Notes are trimmed, including the restated exact-comparison and named-constant sentences (brief item 4). Result: 34 provisions. |
| 18 | (O) `isapprox` details: atol sets rtol to 0; max(\|x\|,\|y\|) | **Declined.** The research note does not support either fact, and brief item 8 says to omit such facts rather than add them unsourced. |
| 19 | (O) `--math-mode=fast` a no-op | **Fixed per brief item 8.** It is removed from the list of performance approximations. The research note is silent on it, so no claim is made either way. JL.5 still records the math-mode option. |
| 20 | (O) Drafting: JL.21 trailing condition; JL.12 sentence 3 scope; JL.33 Julia floor | **Fixed.** JL.21 now reads "including, at the rounding and numerical-error tiers, …", and its MAY uses the brief item 4 wording. JL.12 sentence 3 is limited to globals that a numerical kernel reads. JL.33 checks "the presence of the bounds"; the Notes leave the Julia floor to review. |
| 21 | (O) "X included" constructions | **Fixed.** Now "including X" in the Entry point and Untrusted input Terms, JL.7, JL.9, JL.34, and the Notes. The logger sentence was rewritten. |
| 22 | (O) Consistency with PY | **No change in JL.** JL already matches the shared rules. The PY-side items belong to PY's author. The two drafts' rehearsal header lines differ in wording only. |

## Final verification (verify-final-pyjl.md, JL items)

| # | Finding | Disposition |
| --- | --- | --- |
| D1 | PY.23 and JL.15 differ on log records | **No change in JL.** JL.15 already counts a log record at `Warn` or `Error` as visible degradation, which is what the verifier's fix asks of PY. Listed as decision 5. |
| S3 | JL.14 title misstates the body | **Fixed.** The title is now "Resource exhaustion in catch blocks", which is distinct in the corpus and in the PY and CXX drafts. |
| O1 | JL.15 sentence 1 has a condition in mid-sentence | **Fixed.** It now reads "enter the designed safe state of PRIME.13 of the hardware that it commands", the same wording PY uses. |
| O6 | JL.34 deprecation sentence applies apart | **Fixed.** The sentence is split out as JL.35 "Deprecations fail test runs". The Purpose, the configuration table and the rationale now count 35 provisions. |
| O7 | JL.6 underscore departure is missing from the decisions | **Fixed.** Added as decision 6 in decisions.md. |

## Rulings of 2026-10-23 (revision brief 0.4)

| Ruling | Disposition in draft 0.4 |
| --- | --- |
| Floor judgments agreed: PRIME.4 response rules, "Untrusted input" reach | The Failures Notes now state them as the custodian's ruling of 2026-10-23 (PRIN.10). |
| Underscore naming kept | Kept in JL.6. The Departures Notes cite the ruling. |
| The manual's docstring headings kept | Kept in JL.30. The Departures Notes cite the ruling. |
| Warn or Error log record as visible degradation | Kept in JL.15. The Failures Notes cite the ruling. |
| Shared rule: platform and compiler agnostic; versions and tools chosen by the project owner | Applied. No provision, Term, or Note now names a version number, an interval, or a package or tool. The recommended-configuration table is removed. JL.8's `@compat` sentence is removed. JL.31 says "a doctest that the documentation build of the work runs" instead of naming the block form. The Terms Reference version and Reference manual lose their version examples. The Notes keep only facts that explain a hazard, without versions, and keep Base and standard-library functions as language constructs. The Purpose states the rule (GOV.18). |
| JL item 10: use the latest, no pinned version or tools | Applied. JL.1 now says the reference version SHOULD be the latest stable minor version consistent with the rest of the computational environment (STND.DEPS.3), with no day-count trigger, and keeps the qualified-revision MAY. JL.3's scheduled check runs at the interval that the repository configuration sets. |
| Grouping moved to STND.CODE.13 | JL adds no grouping rule. The Direction Notes cite STND.CODE.13. The rehearsal is apply8, apply9 (STND.CODE 1.1), then apply_jl. |
| Ledger order and rationale | The rationale counts 35 provisions and states the rulings. It cites no ledger number apart from the shared tail line (entry 15). The AT time is 12:30. On my rehearsal copy JL lands at entry 103, because CXX and PY are not applied there; in the full sequence it is entry 105. |
| Draft title (external edit) | The document title "Julia standard", set in content_jl.py by another editor and matching the mnemonic register, is kept. |
