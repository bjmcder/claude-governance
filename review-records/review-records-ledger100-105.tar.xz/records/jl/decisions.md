# STND.JL draft 0.4: open decisions for the custodian

The custodian's rulings of 2026-10-23 settled every decision in the 0.3 list. No decision is open.

Unverified facts that the Notes still mark (for information, not for decision):
- whether a setting removes an `@assert` today;
- whether a task migrates only where it yields;
- whether a package imported by other work commits no manifest by common practice.
