STND.HARN.28 pair review of STND.JL draft 0.1 (read-only; I ran no scripts and wrote no files). The harness list matches the corpus (75 pairs). Provision text in draft.md equals STND/JL/1..20.md. Facts that need a network check are collected in F23.

VERDICT: do not ratify as drafted. There is no hard conflict with any LVL1 provision, but 3 defects (F1 to F3) and 13 should-fix items need correcting first. The worst are: JL.1 can force a Julia minor bump at every release or dependency bump, JL.9 leaves floating-point control state outside HW.CPU.3, and JL.3 contradicts itself.

## 1. PAIR VERDICTS (75)

The harness list carries only bases, not verdicts, so these are mine.

| Verdict | Pairs |
|---|---|
| Compatible | 67 |
| Conflict | 0 |
| Gap | 2 (#36, #75) |
| Redundancy | 1 (#73) |
| Trap | 5 (#26, #54, #55, #56, #62) |

Compatible, by basis. Pairs with two bases count under both, so 67 pairs give 70 incidences. VV.8 15, REPRO.3 14, REPRO.2 10, DSGN.2 9, REPRO.9 6, REPRO.6 4, DSGN.15 3, PRIME.4 3, DSGN.16 2, REPRO.7 2, DSGN.17 1, INTPR.1 1.

Compatible pairs worth a caveat:
- **#7 (JL.1 with HW.7) and #9 (JL.1 with HW.CPU.3):** these are compatible only if a move of the reference version re-triggers HW.7 evidence. See F2.
- **#23 (JL.11 with HW.12):** the Notes send the thread-count partition decision to REPRO.3, but HW.12 is the declaration that owns it.
- **#61 (JL.20 with NUMER.4):** the Notes give no statement-level format-off for aligned notation tables. See F22.
- **#65 (JL.8 with HDES.14):** JL has no Julia form of silent integer wrap. See F16.

Non-compatible pairs:

- **#26 JL.11 with NUMER.24: trap.**
  - JL.11 says to seed each part's generator "from the recorded seed and the index" and names no construction.
  - STND.VVUQ.62 forbids an arithmetic combination of a root seed and a worker index. It also asks for a root seed of at least 128 bits and for spawning, jump-ahead or counter-based keys. NUMER.24 still requires evidence of independence.
  - The obvious Julia derivations are `seed+i` and `hash((seed,i))`. The first breaks VVUQ.62. The second breaks JL.12, because `hash` values changed in 1.13. See F5.
- **#54 JL.18 with HW.7, #55 with HW.CPU.3, #56 with HW.EMBED.5: trap.**
  - JL.18 forces `--check-bounds=yes` on every test run, so no test run is ever on the production configuration.
  - With forced checks, `@inbounds` and `@simd` code is not vectorized. That can change reduction order, and so the delivered arithmetic.
  - HW.7 and HW.CPU.3 need evidence "under its current settings", or a record that the difference cannot matter. HW.EMBED.5 needs the verified image to be the deployed one.
  - See F9.
- **#62 JL.3 with NUMER.4: trap.**
  - JL.3 forces lowercase underscore names for variables and uppercase names for global constants, with no exemption for the notation that NUMER.4 requires to map to code.
  - A literal reading flags `A`, `N`, `Δt`, `σ` and `ħ`.
  - See F11.
- **#36 JL.14 with NUMER.4: gap.**
  - JL.14 says "Each heading … SHOULD be a first-level heading of the table".
  - NUMER.4 equations and approximation, DOCS.2 assumptions and limits, and CODE.3 requires/guarantees/preserves have no row.
  - No document says where they go. See F10.
- **#75 JL.9 with NUMER.5: gap.**
  - `set_zero_subnormals(true)` is a hardware mode. NUMER.5 and HW.5 own recording it in the working precision and hardware contract, and HW.CPU.3 owns confirming and restoring it.
  - JL.9 cites neither. The shared-matters table gives HW as owner. See F3.
- **#73 JL.9 with NUMER.16: redundancy.**
  - JL.9's second sentence ("SHOULD be treated as a performance approximation") restates the NUMER definition of Performance approximation and NUMER.16/NUMER.17, which are SHALL.
  - JL.9's modality is weaker, and its stated onset is wrong. See F4.

## 2. FINDINGS

### Defects

**F1. JL.3 sentence 3 contradicts the Term "Mutating function".**
- The Term excludes IO streams and generators. Sentence 3 says every `!` function "SHOULD be a mutating function".
- So `Random.seed!`, `take!(::IOBuffer)`, and any user `reset!(rng)` or `advance!(rng)` breach the standard, although this is Base's own convention. The Notes even say the exclusion exists because a generator "changes on every call".
- Fix: keep the exclusion only for the obligation in sentence 2. Make sentence 3 read "Each function whose name ends in `!` SHOULD change the state of at least one argument, an IO stream or a random number generator included."

**F2. JL.1 sentence 2 ("at each review of pinned revisions under STND.DEPS.4") couples the Julia minor to every release and every dependency bump.**
- DEPS.4 triggers a review at each release, at most every 12 months, and in each unit that changes any pinned revision.
- Literally, every `Pkg.update` unit or release would move the reference version to the latest minor, and JL.2 would then move the compat floor.
- This contradicts the Notes, which say the version moves "at least once in 12 months". It also drops DEPS.3's qualifier "consistent with the rest of the computational environment", which matters because the table itself lists tools with unstated 1.13 support (Aqua, ExplicitImports, JET on 1.10, DispatchDoctor).
- It ignores a qualified revision (a revision fixed by a hardware contract) and HW.7 contract currency. A runtime change re-opens HW.7, HW.CPU.3 and HDES.3 evidence, and VV.8 re-verification.
- Fix: restrict the trigger to "when the work sets its reference version, and at the reviews that DEPS.4 holds at its 12-month interval". Add "consistent with the rest of the computational environment (STND.DEPS.3), and unless a qualified revision fixes another". Add "a change of the reference version is a change of runtime under HW.7 and STND.DEPS.5".
- Also state that the exact patch release used by each run is recorded (DEPS.8). Sentence 3 floats "latest patch" and so names no revision (HDES.3, HW.3).

**F3. JL.9 and floating-point control state (HW.CPU.3, HW.5, VVUQ.4): not addressed. The harness missed this pair; it shares no LVL0 basis.**
- HW.CPU.3 is binding. It requires confirmation of the delivered arithmetic in each thread or pool that performs the operations, at the start of a run and before reporting. It also requires restoring changed state before control returns to code the contract does not cover.
- `set_zero_subnormals(true)` changes FTZ/DAZ on the current OS thread only. JL.11's own Notes say tasks migrate between threads. A literal reading of JL.9 therefore yields code that cannot reliably satisfy HW.CPU.3: a task that migrates runs with the other mode.
- STND.VVUQ.4 says values below the smallest normal number are judged at tier 3 or lower where a build flushes subnormals.
- JL.9 only says "treat as a performance approximation". It has no scoped form, unlike JL.13 for BigFloat.
- Fix: add to JL.9 "Code that calls `set_zero_subnormals` SHALL (or SHOULD) apply it in every thread and task that runs the affected kernels, restore the previous state before returning (HW.CPU.3), and record it in the delivered arithmetic (HW.5, NUMER.5)." Cite HW.CPU.3 and HW.5 as owners.
- Add one Note: Julia has no function-scoped form, so a scoped wrapper with try/finally is the remedy.

### Should-fix

**F4. JL.9 sentence 2, redundancy, modality and onset (#73).**
- The Notes say all defaults apply "from CSQ3". NUMER.16 instantiates INTPR.10, and CLASS.10 starts INTPR.10 at CSQ2. NUMER's own Notes give onset as the least severe class of the LVL0 provisions it instantiates. A reading that JL.9 starts at CSQ3 therefore narrows NUMER.16 (PRIME.15).
- "SHOULD be treated as" lets a project replace the classification of `@fastmath` by a recorded decision. NUMER.16/17 make the listing a SHALL for NUMER-bound work.
- Fix: state sentence 2 as a classification. For example: "On the path of a numerical result, a use of `@fastmath`, `@simd`, `set_zero_subnormals(true)` or `--math-mode=fast` is a performance approximation under NUMER." Say that NUMER.16 and NUMER.17 apply from their own onset. Drop JL.9's instantiation of NUMER.16/17 or say it adds nothing to them.

**F5. JL.11 per-part seeding, with STND.VVUQ.62, NUMER.24, JL.12 hash and #26.**
- Fix: JL.11 should require a derivation that meets STND.VVUQ.62. That means a root seed of at least 128 bits and no arithmetic combination of seed and index. Name an allowed form, such as the root seed words and the index passed as separate words of a vector seed, or a documented jump or split. State that the derivation must not use `hash`. Cite NUMER.24 for the evidence, as the PY Notes do. Julia's `Random` has no spawn, so the Notes should say how.
- Check on 1.13 whether `Xoshiro`'s vector seeding hashes its input before relying on it (see F23).

**F6. JL.12 covers too little (REPRO.3, CODE.9, NUMER.26, VVUQ.64).**
- It covers "test whose reference holds exact values" only. A fixed-seed statistical test that has no stored values also changes verdict when the stream changes.
- Because JL.1 moves the Julia version, such a test will fail at a version bump. NUMER.26 then forbids the usual cure of reseeding to pass, unless a repetition rule was recorded.
- It covers `hash` values but not results that depend on `Dict` or `Set` iteration order, such as a floating-point sum over `values(d)`. That order depends on `hash`, which changed in 1.13.
- Fix: widen the first sentence to "each test whose verdict depends on the stream of a seeded generator". Add "Results SHOULD NOT depend on `Dict` or `Set` iteration order". Verify whether `shuffle`, `randperm` and `randn` on a `StableRNG` are stable, or say only `rand`-level draws are.

**F7. JL.16 doctests against DOCS.10 and JL.12.**
- DOCS.10 compares shown results "within a stated tolerance". A `jldoctest` matches printed text exactly. JL.16 names `jldoctest` and says nothing about tolerance. Printed floats vary in the last digits across platforms and libm versions.
- A doctest seeded with `Xoshiro(seed)` has output that changes when the Julia minor moves (JL.1). That is a change to the shown result without a change to the work, which DOCS.10 sentence 2 rules out. JL.12's remedy (a stable generator) is not carried over to doctests.
- JL.16 covers docstring examples only. DOCS.10 covers all work documentation, including README and manual pages.
- Fix: JL.16 sentence 3 should read "…construct a generator whose stream stays fixed across versions (JL.12), or show output that does not depend on the draws". Add "Floating-point output shown in a doctest is rounded or compared by `isapprox` with stated tolerances (DOCS.10)". Extend the reach to examples in manual pages and the README.

**F8. JL.16 sentence 1 versus the recommended configuration.**
- As far as I know, Documenter's `checkdocs = :public` checks that existing docstrings appear in the manual. It does not detect a public name with no docstring.
- Fix: recommend `Base.Docs.undocumented_names(Pkg)` (1.11 and later) or `Aqua.test_undocumented_names`, and verify they exist on 1.13. Keep `checkdocs` as a separate row.

**F9. JL.18, and #54 to #56.**
- Fix: add "At least one run of the tests that carry numerical-result evidence SHALL use the production configuration, with bounds checking not forced. Evidence for HW.7, HW.CPU.3 and HW.EMBED.5 is taken from that run, or the difference is recorded as unable to affect the property."
- `--depwarn=error` is global, so a deprecation inside a dependency fails the tests. That blocks a Julia or dependency update the work cannot fix, and clashes with JL.1 and DEPS.3. Scope it to deprecations from code of the work. If a suppression is needed, give each one a stated reason (CODE.4).

**F10. JL.14 and JL.15 against NUMER.4, DOCS.2, CODE.3, the Notes and PY.**
- The heading set is closed. Method equations (NUMER.4), assumptions and limits (DOCS.2) and requires/guarantees/preserves (CODE.3) have no home. Only `# Extended help` could hold them.
- Fix: add a heading `# Notes`, or say that this content goes under `# Extended help` or beside the implementation.
- The Notes attribute rules to JL.14 and JL.15 that no provision states. These are: opening and closing quotes on their own lines, `raw` strings, "See also", and the module docstring above `module`. Either add them to the provision or say they are guidance.
- "Open with the signature of the documented call" does not fit modules, constants and types.
- Names:
  - The Notes say `# Returns` and `# Throws` "match the Returns and Raises sections of numpydoc". They match in name only for `Returns`.
  - PY uses `Parameters` and `Raises`, plus `Yields` and `Attributes`. JL uses `Arguments` and `Throws`. DOCS.9 asks for one name per concept within a work.
  - Either reword the claim to "correspond to", or adopt the numpydoc names.
  - The PY standard fixes section order and JL does not. Add an order: Arguments, Returns, Throws, Examples, Implementation, Extended help.
  - PY.10 forbids restating annotation types in entries. The JL `# Arguments` table row does not say this. Add the same sentence.

**F11. JL.3 naming, with NUMER.4, DOCS.9 and the Notes.**
- Add an exemption row: "a name whose case or subscripts are fixed by the notation documented under NUMER.4 may keep that notation (DOCS.9)". Cover mathematical constants such as `ħ`, and type parameters (`T`, `N`) and macros, which the table does not list.
- "Name internal to its module" is undefined. Read literally it covers every local variable and every struct field. Define it as a module-scope name not declared `export` or `public`, and say whether fields are included.
- The Notes say JL.3 follows "the manual's style guide", then say Base and the manual keep function names without underscores and JL.3 departs from them. As I recall, the manual says "without underscores" for functions. State that JL.3 departs from the manual and why.

**F12. JL.19 against PY.13, STND.VVUQ.3 and VVUQ.5.**
- Infix `a ≈ b` cannot carry `atol`/`rtol`. As worded, JL.19 is either unsatisfiable or is a ban on infix `≈`. Say that tolerances go in `isapprox(a, b; atol=, rtol=)` or in the keywords of an `@test` expression.
- PY.13 also forbids `==` on floating point except under a recorded bitwise requirement, and covers any tolerance-taking comparison in library code. JL.19 covers only tests that use `isapprox` or `≈`. Add the sentence, and widen the scope to any use of `isapprox` or `norm(a-b) < tol`.
- Julia's `isapprox` on arrays compares norms, not elements. VVUQ.5 asks for larger-of relative and absolute parts. Note this, or ask for an elementwise form.
- A NaN equals a NaN only with `nans=true`. VVUQ.3 says a NaN agrees with a NaN. Say so, as the PY Notes do.

**F13. JL.10 versus PY.12 and DSGN.17.**
- "A subtype of `AbstractRNG`" admits `Random.default_rng()` (the global state, DSGN.14) and `RandomDevice()` (not seedable, so no recorded seed under REPRO.1).
- Fix: require the generator to be one the caller constructs from a recorded seed.
- Also state that a wrapper method that fills in `default_rng()` is itself a function that draws.
- State that "entry point" includes test entry points, since `Random.seed!` at the top of `runtests.jl` is common.
- The difference from PY.12 is justified (Base takes the generator first and positional; SPEC 7 uses the `rng` keyword). Say so in the Notes. PY.12 forbids drawing from global state. JL.10 forbids only seeding it, but its first sentence has the same effect.

**F14. Dependency record and pinning (DEPS.4, DEPS.10, REPRO.9).**
- The Notes say `Project.toml` and `Manifest.toml` "serve as the dependency record". DEPS.10 allows this only when the files give each package's revision, reason and license identity. Pkg files give revision only, and Pkg rewrites them.
- Reword with the condition, and name where reason and license are kept.
- No provision requires results-reporting work to commit `Manifest.toml`. Without one there are no pinned revisions for DEPS.4, DEPS.5 and DEPS.8 to review. Only the Notes mention it. Fix: add this to JL.2 or a new provision.
- JL.2 covers only deps and weakdeps of "each package". Julia's own definition of a bound means "1.13" already has an upper limit (below 2.0), so the "with an upper limit" test is nearly vacuous. It omits `[extras]` and test dependencies (which JL.17 and Aqua check) and non-package projects. Align JL.2 with JL.17.

**F15. JL.6 Term "Type-stable call" versus the recommended tools.**
- The Term requires a concrete type for every local variable. `@inferred` checks only the return type. `@test_opt` checks runtime dispatch, not union locals. A `Union` of two concrete types, which the compiler splits efficiently, fails the Term.
- Fix: define the Term by what the named checks decide, such as no runtime dispatch in the kernel and a concrete return type. Or state that a clean `@test_opt` plus `@inferred` is the evidence.

**F16. Failures asymmetry with PY.17 to PY.19.**
- PY has three binding forms of CODE.6/7. JL has only the assert and index rule. A `catch` block that swallows `InterruptException` or `OutOfMemoryError` (PRIME.4 lists resource exhaustion) is covered only by CODE.7 in general terms.
- Julia integer arithmetic wraps silently (PRIME.4 "silent continuation") and no JL provision mentions it.
- Fix: add a binding provision "a `catch` block SHALL rethrow what it does not handle, and SHALL NOT discard `InterruptException` or `OutOfMemoryError`", and a default on overflow-checked arithmetic where input is untrusted.

### Optional

**F17.** JL.4: `public` needs 1.11. A package with a lower floor (the LTS alternative in the Notes) cannot comply. Say "`@compat public` from Compat.jl on earlier versions".

**F18.**
- JL.7 allows hard-coded `Float64` fields as "concrete types". That blocks dual numbers and so NUMER.27 (derivatives). Prefer a type parameter where NUMER.27 applies.
- A `const` global holding a mutable object is still hidden state (DSGN.14). Say so.

**F19.** JL.9: add `muladd` (fusing depends on the hardware) and the command-line options `--math-mode=fast` and `--cpu-target` to the list of constructs. Mention BLAS thread count as a variation source for HW.12.

**F20.** JL.13: confirm that BigFloat precision and rounding are still global on 1.13. As I recall, they became task-local in a recent release. If so, the Notes premise is out of date.

**F21.**
- The Notes leave decisions open ("the choice the custodian decides", "Whether to keep those two headings is a choice for the custodian") in a text that headers describe as adopted. Record the outcome, so no provision or Note asks the human owner for a decision (DRAFT.42).
- The draft title says "draft 0.1, for review" while the header says "Adopted". This is the rehearsal form and PY is the same.

**F22.**
- PY.3 (statements grouped by step) and the grouping direction have no Julia counterpart. Confirm with the custodian whether the direction is language-neutral. If it is, it belongs in CODE and not in PY.
- Add a statement-level formatter-off (Runic or JuliaFormatter directive) for aligned notation, with a reason (CODE.4).

**F23.** Unverified offline. Check each before ratifying:
- "Pkg.test no longer forces bounds checking in 1.13".
- The `hash` change in 1.13.
- `public` plus `export` being an error from 1.12.
- The "General registry" disclosure rule that DOCS.4 would apply to.
- JET 0.12 support for 1.12 and 1.13.
- DispatchDoctor's version range.
- `@testset rng=` in 1.12.
- Julia 1.13.2 as latest stable on 2026-10-22.
- The 1.12 support date of 2026-09-10.
- Existence of `Base.Docs.undocumented_names` and `Aqua.test_undocumented_names`.

**F24.** JL.8 Notes say a check written with `@assert` "is one that an execution setting removes". The manual says only that assertions "may be disabled", and no flag does so today. Reword to "may be removed". The binding force then rests on PRIME.4 and CODE.6 and on the manual's own warning.

**F25.** JL.20: "the tool that STND.CODE.5 recommends" misreads CODE.5, which asks the repository configuration to name a tool. The formatter pin overlaps DEPS.9 and REPRO.9; cite REPRO.9.

**F26.** JL.2's floor at the latest stable minor differs from PY.11's oldest-supported-release rule. This follows the custodian's "latest" direction. The Notes should say that JL.2 is deliberately the opposite of the PY.11 rule that dependents' environments stay supported.

## Internal JL consistency (summary)
- Self-contradiction: JL.3 sentence 3 against its Term (F1).
- Overlap: JL.8 sentence 1 restates CODE.6 for `@assert`. This is acceptable because it names the Julia construct. JL.9 sentence 2 overlaps NUMER.16/17 (F4). JL.16 sentence 1 and JL.17's exports check overlap lightly; Aqua tests both.
- Consistent: JL.2 with JL.18 sentence 3; JL.9 with JL.18 on `@inbounds`; JL.10 with JL.11.
- Traps: JL.1 trigger (F2), JL.11 seed derivation with JL.12 (F5), JL.18 forced checks (F9), JL.3 notation (F11).

Nothing in memory needs saving from this review.
