# Cold verification of STND.JL draft 0.2

I read the reading copy, the rehearsed STND/JL files (each file's frontmatter citations match its body), and the cited CODE, DOCS 0.3, VVUQ, NUMER, HW, DEPS, CLASS.10 and DRAFT provisions. I ran no scripts.

## Findings

**Defects**

1. **JL.34 and JL.35 contradict each other.**
   - JL.34 sentence 1 says "each run of the tests SHOULD force bounds checking".
   - JL.35 asks for a run "with bounds checking as that configuration sets it".
   - Both hold only if production also forces bounds checking.
   - *Fix:* start JL.34 sentence 1 with "Other than the run of STND.JL.35, …", or merge the two provisions.

2. **JL.15 and JL.14 allow fewer responses than PRIME.4.** PRIME.4 accepts halting, visible degradation, or entry into a designed safe state (PRIME.13), each with a diagnosis. Both provisions bind at every class, so each raises the floor (GOV.11) and makes the Notes' claim "asks for the response that PRIME.4 already requires" false.
   - JL.15 allows only throw or return. At CSQ4 that forbids an entry point that logs `@error` and exits, and a CPS path that enters its safe state.
   - JL.14 allows only rethrow or halt. That forbids visible degradation after an `OutOfMemoryError`.
   - *Fix:* add "halt with a diagnosis, or enter a designed safe state" to JL.15. Add "degrade visibly, or enter a designed safe state, with an actionable diagnosis" to JL.14.
   - PY.29 has the same defect. PY.32 already uses the full form.

**Should-fix**

3. **JL.3 sentence 1, JL.35, and the Notes on patch revisions.**
   - Checking on "the latest patch release" ignores a qualified revision and the patch that produces the results, so HW.7 evidence can come from a different runtime.
   - A patch move is also a runtime change under HW.7 and STND.DEPS.5.
   - *Fix:* JL.3: where a qualified revision fixes Julia, check on that revision; otherwise check on the latest patch. Add the Julia revision to the Production configuration Term.

4. **The Entry point Term is too narrow.** It counts only `runtests.jl`.
   - A `StableRNG` built in a test file, a testset, or a doctest therefore breaches JL.23.
   - JL.25 and JL.31 require exactly such a generator inside doctests.
   - PY's Term counts "a test".
   - *Fix:* "…a program, a test, a script run directly, or a documentation example".

5. **The Library code Term excludes package extensions.** Extensions then escape JL.22, JL.9 and JL.33. *Fix:* keep extensions in library code, and let JL.9 sentence 3 admit an extension's use of the internals of the package it extends.

6. **JL.13 sentence 3 reaches too far.** Under the Untrusted input Term, `A[i]` with `i in eachindex(A)` on a public argument needs an explicit check that cannot be removed, at CSQ4. *Fix:* state that an index from `eachindex`, `axes`, or `CartesianIndices` of the indexed array is valid by construction.

7. **JL.6 and JL.7 flag methods of external functions.** A method of `Base.haskey` or `Base.iterate` must keep the external name. *Fix:* add "A method of a function that no module of the work defines MAY keep that function's name."

8. **JL.19 sentence 2.**
   - It restates HW.CPU.3, which says SHALL, as a SHOULD (the redundancy that pair review #73 flagged).
   - Its "that code" points to the wrong antecedent.
   - *Fix:* move it to the Notes.
   - The Notes call it unverified that `@async` tasks do not migrate. The `@async` docstring states that `@async` disables migration, and it discourages `@async` in libraries. My recollection is that a task migrates only at a yield. Base the wrapper remedy on operations that do not yield.

9. **JL.34 sentence 2 and `--depwarn=error`.** The option applies to the whole session, so a listed dependency deprecation still fails the run. The table's caveat "none" is wrong, and the `julia-runtest` row omits `depwarn: error`. *Fix:* state that a listed exemption needs `--depwarn=yes` plus a test that fails on each unlisted deprecation record (`@test_logs` or a collecting logger).

10. **The Purpose's claim that "no other provision restates STND.CODE" is false.**
    - JL.14 and JL.15 are the Julia forms of CODE.7.
    - JL.21 sentence 2 restates CODE.10.
    - JL.16 overlaps CODE.12.
    - *Fix:* reword the claim, and have JL.16 refer to CODE.12 so that a discard with a reason counts as "handled".

11. **The Class onset Notes.**
    - (a) "STND.JL.11 and STND.JL.33 ask for static checks" contradicts the Checking Notes. Write "mechanical checks (DSGN.3)".
    - (b) "Defaults that instantiate NUMER, HW.7, or HW.CPU.3 apply only to work those profiles bind" removes JL.5, JL.12 and JL.21 from work outside NUMER, although they rest on REPRO.2, RSRC.5 and VV.3. Write "the part of each default that rests on …".

12. **The Docstrings Notes misstate STND.DOCS.13.** They allow `doctest = :fix` "only in a change that a reviewer examines". DOCS.13 allows it only after a change to the work that the example describes, and the sentence is an obligation sitting in the Notes. *Fix:* state the DOCS.13 condition, descriptively.

13. **The Randomness Notes omit `Future.randjump`.** It is the `MersenneTwister` jump-ahead in the manual's Future stdlib (my recollection; the research note does not mention it). It is the only standard-library way for library code to meet JL.24, which otherwise looks as if it rests on unverified packages. *Fix:* name it, and confirm it in the 1.13 manual. JL.24 sentence 2 (on `hash`) follows from sentence 1, so it can move to the Notes.

14. **Narration of the drafting and over-hedging (brief item 9).**
    - Two phrases describe the drafting: "the research … read summaries … ran no Julia" and "The research reports". Drop them.
    - The research note marks two facts as stated in the sources ([S]): the `export`+`public` error in 1.12, and the `Pkg.test` bounds change in 1.13. Drop "unverified" from both.
    - The JL.20 Note can cite the 1.12 thread safety of `setprecision` with a function argument.

15. **The Notes call overflow "silent continuation".** That is PRIME.4's prohibited form, which would make JL.17 binding. Describe it as undetected invalid input under DSGN.2.

16. **"Replaces the second sentence of STND.JL.2" (Versions Notes)** reads as an obligation. Write "may replace".

**Optional**

17. **Size.** The draft has 35 provisions and about 7,200 words. 0.1 had 20 and 4,000; PY has 33 and 6,000. The growth comes mostly from splitting bundles, as the reviews asked. These merges lose nothing:
    - JL.34 with JL.35;
    - JL.31 sentence 3 into JL.25 (add "or show output that does not depend on the draws");
    - JL.19 sentence 2 and JL.24 sentence 2 into the Notes.

    That leaves 34. The Failures, Arithmetic and Randomness Notes restate provisions and could lose about a quarter of their text.
18. **`isapprox` details for the Notes.** A positive `atol` sets the default `rtol` to 0. The relative part is taken of max(|x|,|y|) rather than of the reference, which makes it looser than STND.VVUQ.5.
19. **`--math-mode=fast`.** I recall it has been a no-op since Julia 1.8. Verify, then drop it from the list of performance approximations.
20. **Drafting.**
    - JL.21 sentence 1 has a trailing condition (DRAFT.16; PY.21 shares it).
    - JL.12 sentence 3 covers every function, not only kernels, so it applies apart from the rest of the bundle (DRAFT.28).
    - JL.33 should check "the presence of" the bounds, since Aqua does not check the Julia floor.
21. **Prose (DOCS.9).** The trailing "X included" construction makes the Entry point Term, "by one that discards every record included", and JL.7 sentence 2 hard to read. Write "including X". Otherwise I found none of the table's patterns or the banned words, and no modal limit is exceeded.
22. **Consistency with PY.**
    - PY.33 sentence 2 keeps the performance-approximation wording that JL rightly removed (pair review F4).
    - PY.21 lacks the exact-comparison MAY (brief decision 4).
    - PY.20 lacks JL.25 sentence 2.
    - The two drafts differ in their rehearsal header line.

    The other shared rules match. JL needs no GOV.48 agent provision, because the Julia direction has no "always".

## Dispositions

| 0.1 findings | Status in 0.2 |
| --- | --- |
| Cold 1–11, 13, 15–18, 22–26; pair #7, #9, #23, #61, #65, F1–F8, F10–F12, F14, F15, F17–F20, F22–F26 | Resolved. The declines are reasoned. New items arise from cold 12 (6), F2 (3), F3 (8), F5 (13), and cold 23 (11a) |
| Cold 14, F13 | Partly: the Entry point Term (4) |
| Cold 19 | Partly: extensions excluded wholesale (5) |
| Cold 20 | Partly: depwarn list (9), over-hedged (14) |
| Cold 21 | Partly: the Purpose's claim (10) |
| F9 | Partly: the JL.34/JL.35 conflict (1) and depwarn (9) |
| F16 | Resolved, but JL.14 narrows PRIME.4 (2) |
| F21 | Partly; declining the header change is acceptable (22) |

## Verdict

Not ready for ratification. Two defects block it: the contradiction between JL.34 and JL.35 (1), and the binding JL.14 and JL.15 raising the floor beyond PRIME.4 (2). Items 3–13 should also be fixed. All the fixes are wording changes, so draft 0.3 can be presented without a full review round.
