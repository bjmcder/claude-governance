# Cold verification of STND.PY draft 0.2

Read-only text scans only. Every provision's body IDs match instantiates ∪ refers_to; modals, banned words, and title distinctness pass.

## Findings

**1. Defect. PY.32, and the Notes "Failures" claim.** Sentence 1 binds confinement to a with statement at every class. PRIME.4 does not require that. An entry point that sets `np.seterr(invalid="ignore")` process-wide and checks every result with `isfinite` meets PRIME.4 and CODE.7, but it violates PY.32. It also contradicts PY.31 and the Notes, which put such settings at the entry point. The Notes claim that these provisions "ask for the response that PRIME.4 already requires, so they raise no floor" is false for this sentence. Sentence 2 says "within that statement", but sentence 1 confines the statement to "only the operations" suppressed. The check usually follows the block. Fix: delete PY.32 and keep its content in the Notes as the Python reading of CODE.7, with PY.31 doing the scoping. Or reduce it to one sentence: "Where code suppresses a warning or an error report that signals a condition that PRIME.4 lists, it SHALL detect each such condition by another means and respond to it as STND.PY.23 requires (PRIME.4)."

**2. Defect. PY.29 narrows PRIME.4.** It allows only "raise that MemoryError again or halt". So at CSQ4 it forbids two patterns that PRIME.4 permits:
- visible degradation, such as a chunked fallback with a warning;
- `raise SolverError(...) from exc`, which raises a different exception.

Also, a suppression context has no handler, so "its handler" cannot be applied to `contextlib.suppress`. Fix: "Where an except clause catches MemoryError by naming it, a class from which it derives, or no class, its handler SHALL raise an exception, halt with a diagnosis, or degrade visibly (PRIME.4)." Then add: "A suppression context SHALL NOT name MemoryError or a class from which it derives (PRIME.4)." JL.14 has the same narrowing, so fix both together.

**3. Defect. PY.16 cannot be met as written.**
- "The newest Python release that the package declares" is undefined, because packages declare only a lower bound on requires-python.
- If "with the oldest declared release of each core package" also governs the newest Python, the combination does not exist. NumPy 2.5 supports only 3.12 to 3.14 (research note), so NumPy 2.3 has no 3.15 build.

Fix: "...SHOULD run on the oldest declared Python release with the oldest declared release of each core package that it uses, and on the newest Python feature release with the newest release of each (VV.8)."

**4. Defect. Notes "Randomness": an unsourced fact.** The claim "as the binomial and multinomial samplers did in NumPy 2.5" appears nowhere in the research note or the reviews. Under brief item 9, remove it or mark it unverified.

**5. Should-fix. PY.23: the response set.**
- It omits halting and the designed safe state of PRIME.4 (PRIME.13), which CPS code uses.
- "Issue a warning" is met by a DeprecationWarning, PendingDeprecationWarning, ImportWarning, or ResourceWarning, which the default filters ignore. That is silent.
- PY.23, PY.29, and PY.32 give three different response lists for one PRIME.4 list.

Fix: "...it SHALL raise an exception, halt, transition to a designed safe state, issue a warning of a category that the default warnings filters show, or return the condition in its result..." Then refer PY.29 and PY.32 to PY.23.

**6. Should-fix. PY.7 contradicts adoption.** The change that adopts strict checking has to add the failing modules, and PY.7 sentence 2 forbids that. Fix: "Where a change adds a module to that list, a change of a dependency or the adoption of strict checking SHOULD be what makes it fail (DSGN.3)." Or add the adopting change to the exception.

**7. Should-fix. PY.21 against JL.21 (shared rule 4).** "Exact comparison is allowed for exact values" sits only in the Notes, phrased as an obligation ("uses the equality operators"). JL.21 makes it a MAY. Fix: add "A comparison of exact values, or one that the bitwise tier of STND.VVUQ.1 admits, MAY use the equality operators (VV.3)", and drop the Notes sentence.

**8. Should-fix. PY.14 scope.** It says "each example of a docstring". DOCS.13 and JL.31 cover all work documentation, and only the Notes mention the doctest glob. Fix: "Each example of the work documentation that STND.DOCS.13 runs...".

**9. Should-fix. PY.19 against VVUQ.62 and JL.24.** PY.19 admits only "the spawning facility of NumPy". VVUQ.62 and JL.24 also admit jump-ahead (`PCG64.jumped`) and counter-based keys, which is also the form JAX code uses. Fix: "a spawning, jump-ahead, or counter-based facility of its generator library ... and the index of the part".

**10. Should-fix. Errors in the rule map.**
- PY.24 "Left to review: None" is wrong. B006 misses a mutable module constant used as a default, and B008 flags immutable calls as well.
- PY.25 "None" is wrong. PTH flags os.path and open calls, but not a path held as a str parameter or attribute. Name these gaps in the review column.

**11. Should-fix. Obligations and drafting narration left in the Notes (brief item 9).**
- "a project with a dependency that reads annotations at run time records which of the two it uses"
- "code that a notebook grows into moves to library code"
- "a deferral under RSRC.12 that the work process records"
- "were not run when this standard was drafted, and only the Ruff configuration was exercised"

Fix: move the first into a provision or drop it; restate the second and third as consequences of cited provisions; write the last as "...are unverified".

**12. Should-fix. PY.33 sentence 2.** "SHOULD be treated as a performance approximation" is a classification that NUMER.16 and NUMER.17 (SHALL) depend on. As a replaceable default it lets a project reclassify fast-math out of NUMER.17 (PRIME.15, DRAFT.23). Fix: move it to the Notes, which already say it. Also write "SciPy's check_finite=False" in the body.

**13. Should-fix. The floor judgment for PY.5.** "A judgment of the custodian recorded here (PRIN.10)" states a judgment that has not yet been made. The mode is correct (DOCS.10 precedent, INSTR.10); list the judgment as a decision in the cover message. The same applies to the shared "Untrusted input" term (public-interface arguments are untrusted), which makes PY.27 and JL.13 reach every public function at CSQ4.

**14. Optional. Strict-checking Notes.** mypy reports an unannotated dependency as `import-untyped`, and its calls become Any, not "untyped calls". The override is `ignore_missing_imports` or `follow_untyped_imports`. Mark `# noqa: ANN401 reason` (free text after the code) unverified for Ruff.

**15. Optional. Agreement with JL.** There is no counterpart to JL.26, which pairs B5 raised: PYTHONHASHSEED varies the iteration order of a set of str. Add one sentence to the Notes or a default (REPRO.3). PY.29 could name RecursionError alongside JL.14's StackOverflowError.

**16. Optional. Size (33 provisions).** These changes lose nothing:
- Drop PY.32 (finding 1).
- Merge PY.9 and PY.10, which are both about suppression and Any, for three modals.
- Move PY.33 sentence 2 to the Notes.
- Move PY.25 (pathlib) to configuration: its INTPR.1 fit is weak, and PTH does the work.

That leaves 30 to 31 provisions. Keep PY.27 (parallels JL.13).

**17. Optional. Prose against DOCS.9.**
- Three titles follow the "X and Y" formula: "Assertions and untrusted input", "Interrupt and exit handlers", and "Relaxed checks and arithmetic". Suggested replacements are "Assertions on untrusted input", "Interrupts raised again", and "Relaxed numerical checks".
- Split the Notes paragraphs "Failures" (392 words), "Strict type checking" (266), and "Versions" (259). Otherwise the prose is clean.

**18. Optional. Ledger entry.** JL 0.2 also claims entry 102 on the same base, so the collision from B24 persists. The lead agent sets the order.

## Dispositions

| Rows | Verdict |
| --- | --- |
| Cold 1(i)–(iii), 1 PRIN.10, 2–4, 5, 7–15, 17, 19, 20, 23–26, 28, 31 | Resolved (5 with finding 14) |
| Cold 6, 22 | Partly. Findings 1 and 2: PY.29 and PY.32 still go beyond PRIME.4 |
| Cold 16 | Partly. Finding 7 |
| Cold 18 | Partly, declined with a sound reason (PLW1514) |
| Cold 21 | Partly. Finding 6 |
| Cold 27 | Partly. Finding 10 |
| Cold 30 | Resolved, but conflicts with brief item 9 (finding 11) |
| Cold 1 uniformity, 29, 31 (B904, global, dataclasses) | Declined, with reasons |
| Pairs gaps, traps, B1–B4, B6–B8, B10, B12–B21 | Resolved (B8 partly, finding 7) |
| Pairs B5 | Partly. Findings 9 and 15 |
| Pairs B9 | Partly. Finding 1 |
| Pairs B11 | Partly. Finding 3 |
| Pairs B22 | Partly. Findings 7, 8, and 9 |
| Pairs B23 | Partly. Finding 4 adds a new unsourced fact |
| Pairs B24 | Partly. Finding 18 |

## Verdict

**Not ready to present for ratification.** Findings 1 to 4 block it: PY.32 and PY.29 bind beyond PRIME.4 while the Notes claim they raise no floor, PY.16 cannot be met as written, and the NumPy 2.5 sampler claim has no source. After them, and after findings 5 to 9, 0.3 is ready to present with the PY.5 floor judgment and the untrusted-input scope listed as custodian decisions. Change PY.29 together with JL.14.
