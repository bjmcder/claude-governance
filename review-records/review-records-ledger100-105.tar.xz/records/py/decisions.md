# STND.PY 0.4: decisions still open for the custodian

The rulings of 2026-10-23 settled the floor judgments (STND.PY.4, the PRIME.4 rules, the reach of "Untrusted input"), the notebook exclusion, annotation-only parameter types, numpydoc style, type-checked tests and scripts, and the removal of version floors, line lengths, and named tools. Open:

1. STND.PY.28 (KeyboardInterrupt and SystemExit raised again) rests on SIMPL.6, a weak basis, since PRIME.4 does not list either. Recommend keeping it as a default.
