# Dispositions of the cold verification of STND.PY draft 0.2

Provision numbers in the Disposition column are those of draft 0.3. Map from 0.2 to 0.3: 1–8 unchanged; 9 and 10 merged as 9; 11–20 become 10–19; 20 is new; 21–24 unchanged; 25 (pathlib) moved to configuration; 26–33 become 25–32.

| # | Class | Disposition |
| --- | --- | --- |
| 1 | Defect | Fixed. STND.PY.31 is the single sentence of brief item 3, referring to STND.PY.23; scoping stays in STND.PY.30. The Notes "Floor" paragraph now says only that these provisions ask for no work that PRIME.4 does not, and the Error settings paragraph gives the process-wide entry point with isfinite checks as meeting STND.PY.31. |
| 2 | Defect | Fixed. STND.PY.28 follows brief item 2: a handler of MemoryError or RecursionError, named, through a base class, or bare, responds as STND.PY.23 requires; a suppression context names neither nor a base class of either (written positively, "SHALL be neither ... nor", to avoid a negated list). The Notes name the permitted responses, raising another exception from it and a visible chunked fallback included. |
| 3 | Defect | Fixed. STND.PY.15 runs on the oldest declared Python with the oldest declared release of each core package, and on the newest Python feature release with the newest release of each. The Notes say the two are different environments. |
| 4 | Defect | Fixed by sourcing, not by removal. The research note, section 8, states that the NumPy 2.5 release notes report different samples from Generator.binomial and multinomial for the same seed; the Notes now attribute the fact to those release notes. The verifier's premise that it appears nowhere in the research note is mistaken. |
| 5 | Should-fix | Fixed. STND.PY.23 carries the one response list of brief item 1 (raise, halt with a diagnosis, the designed safe state of PRIME.13 for code that commands hardware, visible degradation with a diagnosis, return in the result), and a warning counts only in a category that the default filters show. STND.PY.28 and STND.PY.31 refer to it. |
| 6 | Should-fix | Fixed. STND.PY.7 excepts the change that adopts strict checking. |
| 7 | Should-fix | Fixed. STND.PY.21 carries the MAY of brief item 4; the Notes sentence is removed. STND.PY.21 now has three modals (g.18 review), a bundle that the brief prescribes. |
| 8 | Should-fix | Fixed. STND.PY.13 covers each example of the work documentation; the term is imported from STND.DOCS. |
| 9 | Should-fix | Fixed. STND.PY.18 admits a spawning, jump-ahead, or counter-based facility of the generator library, with the part index (brief item 5). |
| 10 | Should-fix | Fixed. The rule map names the gaps of B006, B008, and PTH. |
| 11 | Should-fix | Fixed. The four sentences are dropped or restated as consequences: the run-time annotation choice is left to the dependency; a module that a notebook imports is library code by the term; release-time checks are a deferral under RSRC.12; the configuration is "unverified" without narration. Other drafting narration ("as a run of each on a sample file showed") is also removed. |
| 12 | Should-fix | Fixed. STND.PY.32 keeps only its first sentence, naming SciPy's check_finite=False; the classification as a performance approximation is stated in the Notes (brief item 6). |
| 13 | Should-fix | Fixed. "Recorded here (PRIN.10)" is removed; the Notes state the rule and its reason. The PY.5 floor judgment and the reach of "Untrusted input" are listed as decisions in the cover message (brief item 7). |
| 14 | Optional | Fixed. The Notes describe mypy's report of an unannotated import and the override, with the setting names marked unverified; the "# noqa: ANN401 reason" form is marked unverified. |
| 15 | Optional | Fixed. New default STND.PY.20 mirrors STND.JL.26 (string hash, set order); STND.PY.28 names RecursionError. |
| 16 | Optional | Fixed. STND.PY.9 merges the dynamic-type and suppression provisions (three modals, g.18 review accepted as one practice of reasoned escapes); pathlib moves to configuration; STND.PY.32 sentence 2 moves to the Notes; STND.PY.31 is one sentence. Count: 32, with the new STND.PY.20 from finding 15. |
| 17 | Optional | Fixed. Titles: "Assertions on untrusted input", "Interrupts raised again", "Relaxed numerical checks". The Notes paragraphs "Failures", "Strict type checking", and "Versions" are split. |
| 18 | Optional | Fixed by the brief: PY rehearses after DOCS and INSTR, with AT 12:20 for the final order of entry 103; the rationale cites no ledger entry number of its own. The rehearsal itself lands at 102 because apply_cxx is not applied first. |
| JL verifier 22 | Optional | Fixed. STND.PY.19 adds the counterpart of STND.JL.25 sentence 2 (repetition rule under NUMER.26); the reading-copy header follows the JL form (title line, then the composer's lines). |

## Final verification (scratch-all/verify-final-pyjl.md, PY items)

| # | Class | Disposition |
| --- | --- | --- |
| D1 | Defect | Fixed. The "beside ... logger" phrase is deleted from STND.PY.23; sentence 3 added: a record that library code writes to a logger SHALL NOT be the only visible degradation. Reporting Notes: an entry point whose handler shows the record degrades visibly through it. STND.PY.23 now has three modals (g.18 review, one response rule). |
| S1 | Should-fix | Fixed. STND.PY.15 runs on the newest Python that the newest release of each core package supports, with those releases; the Notes drop the "so" clause and mark NumPy 2.5 support for 3.15 unverified. |
| S2 | Should-fix | Fixed. STND.PY.17 excepts "a generator that STND.PY.18 derives"; STND.PY.18 added to refers_to. |
| O1 | Optional | Fixed with the wording shared with JL: "enter the designed safe state of PRIME.13 of the hardware that it commands". |
| O2 | Optional | Fixed. STND.PY.28 is titled "Exhaustion caught by handlers". |
| O3 | Optional | Fixed. Departures Notes: STND.PY.5 binds by its own force and does not raise the floor (GOV.11, GOV.48); the legacy-function reach is in decision 1. |
| O4 | Optional | Fixed. Floor Notes now say the three provisions ask only for a response that STND.PY.23 gives, or forbid a construct that leaves a listed condition without one. |
| O5 | Optional | Fixed. "released on 2026-10-09", unverified mark dropped. |
| O7 | Optional | Fixed. Notebook exclusion is decision 3 in decisions.md. |
| DOCS S7 | Should-fix | Fixed. Purpose and Departures Notes, and the apply_py rationale, say STND.PY.5 binds by its own force (GOV.48) and STND.INSTR.10 carries it. Coordinator's title for STND.PY.23 kept. |

## Rulings of 2026-10-23 (revision-brief-0.4.md)

Draft 0.4 numbers: 0.3's STND.PY.3 removed; 0.3's 4 to 32 become 3 to 31.

| Ruling | Disposition |
| --- | --- |
| Floor judgments agreed | Applied. Notes state the rulings of 2026-10-23 (PRIN.10) for STND.PY.4, for STND.PY.22, STND.PY.25, STND.PY.27, and STND.PY.30, and for the reach of "Untrusted input". Purpose and rationale say STND.PY.4 binds by its own force (GOV.48) and STND.INSTR.10 carries it. |
| Keep as drafted (notebooks, annotation-only parameter types, numpydoc, tests and scripts typed) | Applied. Kept; the Notes cite the ruling for the notebook exclusion and for annotation-only parameter types. |
| Shared rule: platform, version, and tool agnostic | Applied. No provision names a version, platform, tool, or library to depend on: STND.PY.9 speaks of the array library's types, STND.PY.15 of the generator object and global random states, STND.PY.18 of the generator library, STND.PY.29 and STND.PY.31 of a numerical library. The recommended configuration table, the rule map, tool versions, and release dates are removed from the Notes; library functions remain only as examples of a hazard, without versions. The "Support window" term is removed. |
| PY 8: versions, line lengths, tools | Applied. STND.PY.13 declares the oldest releases as chosen under STND.DEPS.3 and reviewed under STND.DEPS.4; STND.PY.14 keeps the oldest and newest declared combinations; line length is a choice that STND.PY.1 leaves to the repository configuration; tools are the project's choice, the provisions stating what each decides. |
| PY 9: remove PY.3 | Applied. Removed; the Grouping Note cites STND.CODE.13; provisions renumbered (31). |
| Ledger order | Applied. AT 12:20 for entry 104; the rationale cites no entry number and counts 31. Rehearsal after apply8 and apply9 lands at 103 because CXX is not applied first. |
