# Dispositions of the reviews of STND.PY draft 0.1

Numbers in the Disposition column are those of draft 0.2. "Applied" means the finding is met in draft 0.2 as described; "Declined" gives the reason.

## Cold review (review-cold.md)

| # | Class | Disposition |
| --- | --- | --- |
| 1(i) | Should-fix | Applied. The pending uniformity decision is removed from the Notes; the decision goes in the cover message. |
| 1(ii) | Should-fix | Applied. New binding STND.PY.5 (GOV.48, DSGN.1) binds agents to annotate, delivered by STND.INSTR.10; checking stays a default. The PRIME.7 argument now concerns tool runs only and names the standing authorization of STND.PROJ.3 (STND.DRAFT.42). |
| 1(iii) | Should-fix | Applied. Class onset paragraph addresses the CSQ0 row of DSGN.3. |
| 1 (PRIN.10, caveat) | Should-fix | Applied. Notes record the PRIN.10 judgment and the drift caveat (INTPR.3). |
| 1 (uniformity route) | Should-fix | Declined in the text; listed as a decision for the custodian. |
| 2 | Should-fix | Applied. Notes name the sources of the idioms (PEP 8 Programming Recommendations, PEP 257, typing specification, SPEC 7, NumPy, logging guide). Mechanical gaps: see 17 and 18. |
| 3 | Should-fix | Applied. Notes state the departure from NumPy, SciPy, and pandas practice with its reason; decision listed in the cover message. |
| 4 | Optional | Applied. Notes say form and style directions are defaults by GOV.19, and module and class layout is left to the formatter and import rules. |
| 5 | Defect | Applied. "Strict type checking" is redefined by the findings that mypy strict reports; pyright coverage of two of them marked unverified; STND.PY.6 adds stubs or a coded per-module override for untyped dependencies. SciPy stubs marked unverified. |
| 6 | Defect | Applied. STND.PY.29 binds MemoryError under handlers of Exception, BaseException, or every exception, and suppression contexts; KeyboardInterrupt and SystemExit move to default STND.PY.30. |
| 7 | Defect | Applied. Support window defined by the quarter of the SPEC 0 schedule table; dated values in the Notes agree with it; the 3.15 release date is marked unverified. |
| 8 | Should-fix | Applied. STND.PY.13 omits types only in Parameters and Attributes; Returns and Yields keep the type that numpydoc requires, written as the annotation writes it. Sphinx autodoc description mode named as an alternative; the combination with numpydoc marked untested. |
| 9 | Should-fix | Applied. "Raised exceptions" dropped from STND.PY.2; Raises agreement left to review; DOC rules run without gating. |
| 10 | Should-fix | Applied. STND.PY.14 and the doctest row: NUMBER compares to the shown precision. |
| 11 | Should-fix | Applied. STND.PY.22 limits the logger to diagnostics, progress, and decisions; binding STND.PY.23 requires raise, warn, or return for conditions PRIME.4 lists. |
| 12 | Optional | Applied. STND.PY.11 admits a narrower type; Notes explain ArrayLike's breadth and recommend a concrete scalar type; the np.floating argument question marked unverified. |
| 13 | Optional | Applied. Sentence rewritten; the Types paragraph split into Strict type checking and Arrays. |
| 14 | Optional | Applied. STND.PY.18 records fresh entropy at the entry point. |
| 15 | Optional | Applied, marked unverified in the Notes. |
| 16 | Should-fix | Applied. STND.PY.21 states the parameters of the tier of STND.VVUQ.1, the parts of STND.VVUQ.5, and the NaN treatment of STND.VVUQ.3; the equality ban is removed, since VVUQ.1 tier 1 admits exact values. |
| 17 | Should-fix | Applied. STND.PY.1 lets notation names keep their case; Notes and configuration list them under the ignore-names setting of pep8-naming. |
| 18 | Should-fix | Applied in part. S (with S101 per-file ignore for tests) and FA added; per-file ignores for D and T20 added. PLW1514 is not selected: it is a preview rule (status unverified) and selecting PL brings many rules unrelated to this standard; the encoding rule is left to review. |
| 19 | Should-fix | Applied. Public interface is restricted to library code, with "__all__" taking precedence; D105 ignored in the configuration. |
| 20 | Should-fix | Applied. STND.PY.12 asks for units, shape, and range "that each item has". |
| 21 | Should-fix | Applied. New STND.PY.7, one list of exempted modules that changes do not grow. |
| 22 | Should-fix | Applied. Binding STND.PY.29 and STND.PY.32 are limited to PRIME.4's list; broader scoping of settings is default STND.PY.31 (DSGN.14) for all code outside entry points; Notes say STND.CODE.7 still applies inside the with statement and no longer claim PRIME.4 lists overflows. |
| 23 | Should-fix | Applied. Term "Untrusted input" added; STND.PY.27 kept as the checkable Python form of STND.CODE.6; new default STND.PY.28 for run-time checks without assert, from CSQ1. |
| 24 | Optional | Applied. STND.PY.15 and STND.PY.16 bind distributed packages; applications pin under STND.DEPS.3 and STND.DEPS.4. |
| 25 | Defect | Applied. RSRC (and NUMER) added to the class onset paragraph. |
| 26 | Optional | Applied. Versions paragraph rewritten. |
| 27 | Should-fix | Applied. Rule map table added; STND.PY.4 narrowed to names the checker does not infer, enumeration members excluded, functions defined by def; STND.PY.11 limited to parameters, returns, module-level names, and class attributes. |
| 28 | Should-fix | Applied. Explanations moved out of the bodies; the negated list in the generator provision removed; paths and encodings split (STND.PY.25, STND.PY.26); strict checking and py.typed split (STND.PY.6, STND.PY.8); floors and release checks split (STND.PY.15, STND.PY.16); "Work documentation" import dropped. |
| 29 | Optional | Declined. The composer writes the heading of the adopted copy; the reading copy's first lines state it is a rehearsal for review, as the STND.DOCS reading copies do. No adopted copy is written before ratification. |
| 30 | Optional | Applied. Paragraphs split; phrasing fixed; Notes state that the mypy, pytest, and numpydoc configurations were not run. |
| 31 (packaging) | Optional | Applied in part. STND.PY.15 uses package metadata and STND.PY.8 the distribution; naming pyproject.toml is left to configuration. |
| 31 (exceptions, B904) | Optional | Declined, to keep the standard minimal; STND.CODE.7 and STND.CODE.12 already govern discarded failures. |
| 31 (global statement) | Optional | Declined. DSGN.14 and STND.PY.17, STND.PY.24, and STND.PY.31 cover the shared state that matters most in scientific code. |
| 31 (security) | Optional | Applied as configuration only (S rules). Not a provision: GUARD.17 judges secure practice against the threat model of each project, which a language standard does not know. |
| 31 (notebooks, suppress) | Optional | Applied. Notebooks are outside STND.PY.6 by a stated departure; contextlib.suppress is in STND.PY.29. |
| 31 (dataclasses, dtype, f-strings) | Optional | Declined, to keep the standard minimal. |

## Pair review (review-pairs.md)

| # | Class | Disposition |
| --- | --- | --- |
| A gap #10, #19 | Gap | Applied by STND.PY.18 (entropy and seeds recorded). |
| A gap #27 | Gap | Applied by STND.PY.21 (named constant with its NUMER.11 basis). |
| A gap #51 | Gap | Applied by STND.PY.29. |
| A gap #55 | Gap | Applied by STND.PY.31 (SciPy and accelerator libraries) and STND.PY.32. |
| A trap #1, #56 | Trap | Applied by STND.PY.1 and the configuration. |
| A trap #2 | Trap | Applied. Qualified revisions are exempt in STND.PY.15; HW.7 and STND.DEPS.5 cited in the Notes. |
| A trap #20 | Trap | Applied by STND.PY.18. |
| A trap #36 | Trap | Applied by STND.PY.23. |
| B1 | Defect | Applied. Binding STND.PY.23. |
| B2 | Defect | Applied. See cold 5. |
| B3 | Defect | Applied. NUMBER and IGNORE_EXCEPTION_DETAIL; doctest glob for documents. |
| B4 | Should-fix | Applied. See cold 1(iii) and 25. |
| B5 | Should-fix | Applied. STND.PY.17 to STND.PY.20 follow the shared rules of the revision brief: generator through rng, construction at entry points from recorded seeds, spawned streams by part index (STND.VVUQ.62), stable streams for exact references, global state unseeded in library code. |
| B6 | Should-fix | Applied. See cold 8. A numpydoc run was not possible here; the Returns form is marked for verification in the Notes. |
| B7 | Should-fix | Applied. STND.PY.29 covers Exception, tuples through "a class from which it derives", and suppression contexts. |
| B8 | Should-fix | Applied. See cold 16. |
| B9 | Should-fix | Applied. STND.PY.32 requires detection by another means; Notes say confinement does not make discarding acceptable; STND.PY.31 extends to SciPy and accelerator libraries. |
| B10 | Should-fix | Applied. See cold 19; Library code defined by importable packages, tests and entry-point modules excluded. |
| B11 | Should-fix | Applied. STND.PY.16 includes the oldest core package releases; the lock file named as the exact record (STND.DEPS.10); qualified revisions exempt; the library statement is now normative in STND.PY.15; the release-time run noted as an RSRC.12 deferral; NumPy 2.2 settled by the quarter reading. |
| B12 | Should-fix | Applied. Notation names configured once; W505 on displayed mathematics takes a coded suppression. |
| B13 | Should-fix | Applied. See cold 27. |
| B14 | Should-fix | Applied. Rule map added; T20 per-file ignores; raises clause dropped from STND.PY.2. |
| B15 | Should-fix | Applied. STND.VVUQ is cited by provision and appears in the derived References table. |
| B16 | Optional | Applied. New default STND.PY.33, on the model of STND.JL.9. |
| B17 | Optional | Applied. STND.PY.26 keeps the error handler strict; Notes cover nan_to_num and clip. |
| B18 | Optional | Applied. Notes name the standing authorization of STND.PROJ.3. |
| B19 | Optional | Applied. STND.PY.12 states the STND.CODE.3 contract and the condition of each raised exception. |
| B20 | Optional | Applied. STND.PY.3 excepts blank lines that the formatter inserts. The ERA001 false positive on heading comments is not noted, since the research did not confirm it. |
| B21 | Optional | Applied in the Notes. |
| B22 | Optional | Applied. Comparison and random-number provisions follow the shared rules of the revision brief, so that PY and JL agree. |
| B23 | Optional | Applied in part. The 3.15 date is marked unverified. Ruff 0.16.8 and Black 26.5.1 were run locally by the research; mypy 2.4, Pyrefly 1.0, the NumPy plugin deprecation, and the Ruff 0.16 default change come from fetched release pages and are kept. |
| B24 | Optional | Applied. Rehearsed after STND.DOCS 0.3 and STND.INSTR 1.4 as ledger entry 102; the order with STND.JL is for the lead agent to set. |
