REVIEW OF STND.PY DRAFT 0.1 (read-only; no files touched, no scripts run, no network). Python/tool facts I could not confirm offline are marked "unverified". I did not independently check anything the research note labels [local test].

## (a) Fidelity to the directions and the handling of "always"

1. DEFECT-adjacent / should-fix. Draft Notes "Types", with Purpose. The custodian's "always" becomes SHOULD from CSQ3. The draft is honest that CSQ4 may omit and that GOV.11 caps the onset. Three problems remain.
   - (i) The Notes contain a pending decision inside adoptable text: "The custodian may instead record that uniformity... That record would make them binding". After adoption this is stale. It belongs in the cover message. The standard should state the decision taken.
   - (ii) The PRIME.7 argument against binding agents is weak. Writing annotations needs no tool. A provision can be conditional ("where a checker is in the provisioned environment") or rely on a standing authorization, which STND.DRAFT.42 requires LVL2 to accept. The draft never mentions the STND.DOCS.7 route.
   - (iii) The draft says CLASS.10 applies DSGN.1 and DSGN.3 "in full from CSQ3". The CLASS.10 table has a row "CSQ0 | Mechanical checking of each contract of a safety-related component (DSGN.3)". The Notes must address that row. One sentence suffices: the row concerns safety-related components, and strict checking of other code rests on the general DSGN.3 SHOULD.
   - Fix: add an agent-only binding provision on the DOCS.7 model. Draft wording: "An agent SHALL annotate each parameter and return value of each Python function it writes or changes, as STND.PY.4 recommends, or as the alternative a project instrument adopts in its place requires (GOV.48, DSGN.1)." It costs the agent nothing beyond writing. Checker passage stays a default, and the agent runs the checker only where one is provisioned.
   - The custodian should record the PRIN.10 judgment that this does not raise the floor, as DOCS Notes do.
   - Caveat to state: unchecked annotations can drift (INTPR.3). That is why the checker stays a default at CSQ3.
   - The GOV.19 uniformity route is credible for PY.4 and PY.5 only if projects import each other's code, which is the draft's own example. It would not reach CSQ4 under GOV.11 anyway. Recommendation: GOV.48 route for writing; keep checking a default; take the uniformity route only if the custodian affirms the cross-project reason.

2. Should-fix. D1 ("PEP standards for style and idioms, enforced mechanically wherever possible"). The "Style PEPs" Term is only PEP 8 and PEP 257. The "Idioms" provisions come from SPEC 7, NumPy, and the logging docs, not PEPs. Several provisions have an available mechanical check that the config omits (see 17, 18). Fix: state in the Notes that idioms are PEP 8 "Programming Recommendations", PEP 257, and the typing PEPs via the specification, with the other idioms from named non-PEP sources. Cover the mechanical gaps (see 17, 18).

3. Should-fix. D3 ("numpy doc styles"). PY.10 forbids restating types in the docstring. NumPy, SciPy, and pandas practice keeps docstring types. The research note called this the custodian's Q5 decision. The draft adopts option B silently, and the Notes only say the guide is "silent". Surface it as a decision. Also see finding 8 (Returns).

4. Optional. D4 ("shall"). Add one sentence in the Notes: D1, D3, and D4 are form or style and therefore defaults by GOV.19, whatever the verb in the direction. PY.3 covers function bodies only. Import grouping is covered by Ruff `I`. Say module and class level are left to the formatter.

## (b) Technical correctness

5. DEFECT. Notes "Types" says a project meets "Strict type checking" with "mypy in strict mode". The Term requires reporting "each value whose type becomes Any without an annotation that states it". `mypy --strict` does not do that. Its 13 flags have no disallow-any-expr, only warn-return-any and disallow-any-generics. pyright strict's reportUnknown* is nearer. Fix: weaken the Term to what mypy strict reports (untyped defs, incomplete defs, untyped calls, generics without arguments, unused ignores, returning Any). Or require `disallow_any_explicit` or basedpyright `reportAny`. Also state how third-party untyped packages are treated. Under "calls into unannotated code" every call into an untyped scientific dependency is a finding. Allow a module-level override recorded in the repository configuration, or stubs. SciPy needing community stubs for strict mode is unverified.

6. DEFECT. PY.18 and the Notes "Failures". MemoryError derives from Exception, not only BaseException. `except Exception: pass` swallows it and PY.18 allows that. Meanwhile PY.18 binds on KeyboardInterrupt and SystemExit, which PRIME.4 does not list. So the binding rationale does not fit its citation (STND.DRAFT.23). See finding 22 for the mode consequences.

7. DEFECT. Notes "Versions" against the Term "Support window". By the Term's arithmetic (36 and 24 months before 2026-10-22), Python 3.12 (released 2023-10) is out, but NumPy 2.2 (released 2024-12) is still inside. The Notes say new work declares NumPy 2.3. The research note says 3.12 is "still inside the SPEC 0 window for a few more weeks". Three readings conflict. Fix: define the window as the drop dates in SPEC 0's schedule table, with the table values recorded as dated data in the Notes. Or compute by months and correct the NumPy 2.3 sentence. Separately, the 3.15 release date "2026-10-09" is unverified. My recollection of the PEP 790 schedule is 2026-10-01; verify.

8. Should-fix, unverified. PY.10 against numpydoc for Returns and Yields. The research note says "Returns and Yields: the type is always required". A single-line Returns header is parsed as a type, so a typeless entry is not expressible. numpydoc check RT02 is not excluded. Fix: restrict PY.10 to Parameters and Attributes, or specify the Returns form and test it with the validator and sphinx-autodoc-typehints. Combining numpydoc with sphinx-autodoc-typehints is untested here (the note says the numpydoc, mypy, and pytest blocks were never executed). Sphinx's built-in `autodoc_typehints = "description"` is an alternative to mention.

9. Should-fix. Recommended configuration row "Docstring agreement of PY.2". PY.2 requires agreement of "raised exceptions" with the function. numpydoc validation has no Raises check (the code list in the research note has none). Ruff DOC501 and DOC502 are preview and called "optional". The recommended setup therefore cannot check one of the three things PY.2 requires. Fix: select DOC501 and DOC502 as non-gating, or drop "raised exceptions" from PY.2 and leave it to review. The "Existing numpydoc hook coverage of PR01 to PR03 under the AST-based pre-commit hook" is unverified.

10. Should-fix. Doctest row. DOCS.10 requires results "compared within a stated tolerance". Stdlib doctest has none. The listed flags NORMALIZE_WHITESPACE and ELLIPSIS give no tolerance. The research note says pytest adds NUMBER (floats match to the written precision). Add NUMBER, or pytest-doctestplus FLOAT_CMP (unverified), and state the tolerance.

11. Should-fix. Notes "Idioms" on logging. A NullHandler on a library logger means a WARNING or ERROR is silent when the application configures nothing (an attached handler also stops lastResort printing). PY.14 says to report "anomalies" through the logger, which conflicts with INTPR.7 and PRIME.4 in practice. Fix: say anomalies that bear on a result are also raised, warned, or returned in the result. The logger carries diagnostics.

12. Optional. PY.8 against `numpy.typing.ArrayLike`. It admits `str` and `bytes` and carries no dtype, so numeric inputs lose checking. Note this. The `NDArray[np.floating[Any]]` form brings an `Any` that PY.6 would then demand a comment for; whether `np.floating` needs the argument under strict in NumPy 2.3 or later is unverified. Say which form is expected.

13. Optional. Notes "Types": "The shape type of an array also states a fixed number of dimensions" is unclear. Rewrite or drop it. Also split the very long paragraph.

14. Optional. PY.12. `rng=None` gives fresh OS entropy, so the default is nondeterministic. Add that when `rng` is None the entropy used is recorded (`SeedSequence().entropy`) to meet REPRO.1.

15. Optional. PY.19. `warnings.catch_warnings` is not thread-safe before the 3.14 context-aware option, which is on by default only on free-threaded builds. Say so, since the Notes discuss free-threading.

## (c) Conflicts, duplication, floor

16. Should-fix. PY.13 against STND.VVUQ (and NUMER.11). VVUQ.1 defines six comparison tiers and VVUQ.5 already requires a relative and an absolute part for tiers 3 and 4.
    - PY.13 sentence 1 applies to every function that takes tolerances. That includes ULP comparators (tier 2, `maxulp`) and statistical criteria (tier 5). It cannot be satisfied for either.
    - Sentence 2 forbids `==` except under "a recorded requirement of bitwise identity". VVUQ tier 1 also admits "each value is an exact value", which is not a bitwise-identity requirement.
    - The Notes cite VVUQ only for NaNs, and STND.VVUQ is absent from the References table although the Notes cite it. Reconcile with VVUQ.1 and VVUQ.5 by citing them (refers_to), and narrow PY.13 to tiers 3 and 4.

17. Should-fix. N803/N806 against NUMER.4 and INTPR.1. pep8-naming (N) flags uppercase or single-letter names for matrices and operators, which NUMER.4 requires to map to the notation. PY.7 would force a `# noqa: N806` per use. The HARN.28 pairs listed PY.1, PY.2, and PY.3 against NUMER.4 and the Notes never resolve it. Fix: record the N-rule exemptions once in repository configuration under PY.1, and say so in the Notes.

18. Should-fix. Rule coverage gaps. The linter list has no `S` (bandit), so there is no assert-used check for PY.17 (S101, with tests excluded) and no rule for the security gaps in item 31. It also omits `PL` (PLW1514 unspecified-encoding for PY.16). The Notes mention `FA` but it is not in the select list. `T20` and `D` will flag scripts, CLIs, and tests unless per-file ignores are given.

19. Should-fix. "Public interface" Term. It covers every unprefixed name of "the work", so test modules, test functions, and fixtures need numpydoc docstrings under PY.9. Ruff D103 will also flag them. Restrict the Term to library code, or exclude tests and scripts. Also note that Ruff D105 demands docstrings on magic methods, which the Term excludes.

20. Should-fix. PY.10. "each entry SHOULD carry the units, the shape, and the range" cannot hold for a flag or a string. Add "where it has them".

21. Should-fix. Migration. PY.5 requires strict checking of "all Python source", while the Notes say existing source conforms "when a change next touches it". Whole-program strict checking cannot be adopted that way. State the gradual route: nonconforming modules are listed once in repository configuration and the list shrinks.

22. Should-fix on PY.18 and PY.19 (mode and floor). Mode is mechanically forced to binding because they instantiate PRIME.4, and no default instantiates a floor ID. But the text goes beyond PRIME.4.
    - PY.18 forbids log-and-degrade with BaseException, which PRIME.4 permits ("degrade visibly"). It also forbids the standard concurrent.futures/asyncio pattern of storing an exception for re-raise elsewhere, and a top-level handler that logs and raises SystemExit.
    - PY.19 binds every warning, including a DeprecationWarning filter, though PRIME.4 lists only invalid input, precondition violations, non-convergence, and resource exhaustion.
    - Non-waivable force (GOV.45) on rules broader than PRIME.4 is a floor-raising prohibition under GOV.11. The draft's argument "they ask for no work beyond the floor" is the DOCS.7 argument, which rested on GOV.48 and a recorded judgment.
    - PY.19 limits itself to "library code" although the section claims binding at every class. A script that calls `np.seterr(all='ignore')` globally is outside the rule.
    - The Notes claim PRIME.4 requires invalid operations and overflows to be loud. PRIME.4 does not list those.
    - The Notes route suppressions through CODE.12, but CODE.12 covers only failures PRIME.4 does not list. CODE.7 still bars discarding a listed kind inside a `with` block.
    - Fixes:
      - PY.18: "Where an except clause names no exception class or names BaseException or Exception, it SHALL raise again each MemoryError that it catches, and SHALL otherwise halt, degrade visibly, or raise again (PRIME.4)". Move the KeyboardInterrupt and SystemExit rule to a default.
      - PY.19: replace "library code" with "code" and narrow it to PRIME.4's listed kinds.
      - If the custodian wants the broader reach, record that judgment in the Notes.
      - Say in the Notes that CODE.7 still applies inside the `with`.

23. Should-fix. PY.17. "Untrusted input" is not defined, so the rule is not decidable. Public-API validation by `assert arr.ndim == 2` is common in scientific code. Add a Term (data from outside the work's own code, and the arguments of public-interface functions, unless the project's threat model says otherwise). PY.17 largely duplicates CODE.6, which already forbids removable checks of untrusted data. Keep it only as the checkable Python form, or fold it into the Notes. Add that at CSQ1 and above, VV.10 and DSGN.2 run-time invariant checks must survive `-O`, so those use an explicit `raise`. The claim "an assertion of an internal invariant stays correct" glosses this.

24. Optional. PY.11 is a SPEC 0 rule written for library maintainers. Applied to applications it forces upgrade churn each release and conflicts with archived, long-lived reproducible code (REPRO.12). Say it is for libraries, with applications declaring and testing a recorded floor.

25. Factual, DEFECT (small). Notes "Class onset": "each default provision instantiates only DSGN, SIMPL, INTPR, REPRO, or VV". PY.14 instantiates RSRC.10. Add RSRC.

26. Optional. Notes "Types" cite PEP 729 only for the Council, fine. "Python 3.15 ... NumPy 2.5.0 ... with 3.15 support from its release candidates" is ambiguous; rewrite.

## (d) Checkability

27. Should-fix. Add a small table in the Notes mapping each provision to the rule that decides it and the part left to review. From my reading:
    - Mechanical: PY.2 (config), PY.4 functions (ANN), PY.5 (config, wheel contains py.typed), PY.6 (ANN401 plus review), PY.7 (PGH003, PGH004, RUF100, ignore-without-code), PY.9 (D, numpydoc GL07 for order), PY.12 (NPY002), PY.14 (T20, LOG, G), PY.15 (B006, B008), PY.18 (E722, BLE001).
    - Review only: PY.1, PY.3, PY.8, PY.10, PY.13, PY.19 (there is no rule; a grep for seterr, filterwarnings, and simplefilter is the best check), PY.4 variables.
    - PY.4's variable clause is also over-broad. "Each module-level name and class attribute ... other than a literal of a built-in type" requires an annotation on `logger = logging.getLogger(__name__)`, on every call-initialized constant, and on enum members. The typing specification says enum members must not be annotated. Narrow it to names the checker cannot infer (mypy `var-annotated`), and exclude enum members.
    - PY.8's "name that holds a NumPy array" read literally covers every local variable. Say module and class names and public attributes.
    - PY.4 "each function" includes lambdas, which cannot be annotated. Say "defined by a def statement".

## (e) Drafting rules from the brief

28. Should-fix. STND.DRAFT.12 (no explanation in provision bodies): PY.5 "so that the type checkers of its dependents read its annotations", PY.12 "which accepts None, a seed...", PY.14 "which leaves the handling...", PY.17 "which the optimizing mode... removes". Move to Notes. STND.DRAFT.15 (negated list): PY.12 sentence 2 names two items under SHOULD NOT; make it one sentence per item. STND.DRAFT.28 (atomic): PY.16 joins paths and encodings, which are applied apart; split it. PY.5 joins strict checking and py.typed; consider splitting. PY.11 (floors, then CI on oldest and newest) is also splittable. Terms: "Work documentation" is imported and unused in the provisions; drop it.

29. Optional. The reading-copy header says "Adopted by The Custodian as revision 1.0 in ledger entry 101" while also saying it is a rehearsal. Make sure the adopted copy is generated only at adoption (GOV.49, PRIME.2).

## (f) Prose against STND.DOCS.6

30. Optional. American spelling clean, no em dashes, no listed generated-text vocabulary found. Only issues: the "Types" paragraph (about 350 words, several topics) should be split; the sentence in finding 13; the "as a run of each on a sample file showed" phrasing is clumsy; the config table is acceptable. State in the Notes that the mypy, pytest, and numpydoc blocks were not executed (research note section 5), since the Notes say facts are "as of 2026-10-22".

## (g) Minimal gaps worth adding

31. Candidate defaults, each one provision:
    - Packaging metadata: "Work distributed as a Python package SHOULD declare its metadata in pyproject.toml per PEP 621, including requires-python" (REPRO.9). Includes py.typed in the built distribution (PEP 561).
    - Exceptions: raise specific exception classes derived from Exception, chain with `raise ... from` (B904), and return no sentinel for an error.
    - Mutable global state (DSGN.14): no `global` statement (PLW0603) and no module-level mutable caches shared across calls. PY.15 covers only parameter defaults.
    - Security: no `eval`, `exec`, `shell=True`, unsafe `yaml.load`, or pickle/marshal of untrusted data, and no `verify=False`. This is GUARD.17 and could be binding at every class if the custodian wants it, else a default using the `S` rules.
    - Notebooks and `contextlib.suppress(BaseException/Exception)`: say whether notebook cells are in scope for PY.5, and add suppress to PY.18 scope.
    - Lower value: frozen dataclasses and enums instead of magic strings; explicit dtype where precision affects a result (SIMPL.6, NUMER.5); f-strings and lazy logging arguments (G004 is already selected).

VERDICT: Sound structure and mostly correct tool facts, but not ready to ratify: 0.1 has about a dozen defects (findings 5, 6, 7, 22, 23, 25 and the PY.4/PY.8/PY.9/PY.10/PY.13 scoping errors) and an under-argued "always"; revise to 0.2, adding the GOV.48 agent annotation route and re-scoping PY.18 and PY.19 to PRIME.4.
