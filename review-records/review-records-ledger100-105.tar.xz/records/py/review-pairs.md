STND.HARN.28 pair review of STND.PY draft 0.1 (read-only; no files changed). I checked the 72 pairs in /home/claude/scratch-py/pairs.txt against the other-side texts in /home/claude/scratch-py/governance/, then read the harness misses (CODE, DOCS, DEPS, WPROC, CLASS.10, PRIME.4/7, GOV, DRAFT.42, NUMER, VVUQ) and the sibling /home/claude/scratch-jl/draft.md. Local checks used numpy 2.5.3 on python 3.13. I could not run numpydoc, Ruff, mypy or pytest, which are not installed, and there is no network. Claims about those tools come from my knowledge and are marked "verify".

## A. Pair verdicts (72)

- Compatible: 62.
- Conflict: 0.
- Redundancy: 0.
- Gap: 5 (#10, #19, #27, #51, #55).
- Trap: 5 (#1, #2, #20, #36, #56).
- No pair is a conflict, so the adopter summary under HARN.28 holds no conflict pairs.
- Matters that no shared-matters table gives:
  - The channel by which library code reports PRIME.4-class anomalies. PY.14 must own it (finding 1).
  - The form of tolerance literals. PY.13 owns the form; NUMER.11 owns the basis.
  - Random-stream independence is already owned by NUMER.24. PY.12 owns only the Python form.
  - No new owning profile is needed.

Compatible, by basis (62):

| Basis | Count | Pairs | Reason |
|---|---|---|---|
| VV.3 | 12 | #21-26, 28-33 | PY.13 asks only for stated tolerances. The other provisions govern criteria, basis, and timing, and PY.13 neither contradicts nor duplicates them. |
| VV.8 | 11 | #4-7, 9, 66-71 | Version and doctest checks re-verify; they are not hardware or model evidence. Doctests are not correctness evidence (DOCS.10). |
| REPRO.1 | 8 | #11-18 | Those provisions record device, configuration and image identities. Seeds are not at issue. |
| REPRO.7 | 8 | #58-65 | A reasoned `Any` or a coded suppression is a decision record at the point of implementation, and REPRO.7 allows a comment. |
| PRIME.4 | 7 | #46, 47, 48, 50, 52, 53, 54 | PY.17-19 forbid constructs. They add no response to the hardware-fault, saturation or completion duties. |
| REPRO.3 | 5 | #38-42 | PY.16 only fixes encoding and paths. |
| DSGN.2 | 3 | #44, 45, 49 | A raised exception, not `assert`, implements the input checks. |
| INTPR.1 | 3 | #43, 57, 72 | PY.3 grouping, PY.9 numpydoc Notes and PY.16 are neutral to NUMER.4 (equations beside the code). Trap #1/#56 is separate. |
| REPRO.9 | 2 | #3, 8 | The lock file serves as the exact-revision record (finding 11). |
| RSRC.10 | 2 | #34, 35 | AGENT.14 and AGENT.2 concern agent-to-owner communication, not logging. |
| DSGN.16 | 1 | #37 | NUMER.27 against logging. Note that logging inside JAX-traced kernels runs at trace time only. |

Gaps:
- **#10 (HDES.3) and #19 (ML.3).** These require the seeds of tools and fits in the record. PY.12 allows `rng=None`, which draws OS entropy that no one records (finding 5).
- **#27 (NUMER.11).** PY.13 forces an atol with no basis (finding 8).
- **#51 (HW.8).** PY.18 does not catch `except Exception`, which swallows MemoryError and FloatingPointError, nor log-and-continue (finding 7).
- **#55 (HW.GPU.3).** PY.19 covers only NumPy errstate and warnings. Accelerator libraries have their own process-wide switches (finding 9).

Traps:
- **#1 and #56 (PY.1, PY.2 against NUMER.4).** NUMER.4 wants equation notation mapped to code names. The recommended Ruff `N` rules (N802, N803, N806) flag the usual symbols `A`, `K`, `Phi` (finding 12).
- **#2 (PY.11 against CPS.3).** PY.11 pushes the interpreter and NumPy floors forward at every release. For a hardware-commanding system that is a change CPS.3 requires the hazard analysis to cover. A qualified revision (a DEPS term) is not exempted (finding 11).
- **#20 (PY.12 against NUMER.24).** `rng` accepts a seed, and `default_rng(42)` called in two functions gives two identical streams (finding 5).
- **#36 (PY.14 against CPS.5).** CPS.5 needs a PRIME.4 response when a command is rejected or clamped. A logger-only response under NullHandler is silent (finding 1).

## B. Findings

### Defects

**1. PY.14 against PRIME.4 and CODE.7.**
- Problem: PY.14 sends "anomalies" through a logger and allows only `NullHandler`, which suppresses even Python's last-resort stderr output. Non-convergence, invalid input, clamping and exhaustion then pass silently unless the importing program configures logging. PRIME.4 forbids that, and RSRC.10 calls silence where action is needed a defect. The warnings sentence that covers this sits only in the Notes ("a problem that the caller should fix is raised as a warning").
- Fix: Add to PY.14: "A condition that PRIME.4 lists SHALL NOT be reported only through a logger; it is raised as an exception or warned through `warnings`, and the logger record is in addition." Move the warnings sentence into the provision. Keep logging for progress and decisions.

**2. "Strict type checking" definition against the mypy row (Terms, PY.5, Types note, table).**
- Problem: The definition requires reporting "each value whose type becomes Any without an annotation that states it", and the Notes say mypy strict meets it. To my knowledge mypy `--strict` does not report that (verify). It would need `disallow_any_expr`, which is unusable with NumPy, or pyright strict's `reportUnknown*`. Untyped third-party imports also become `Any`, and the draft says nothing about stubs. Stubs would be dev dependencies (DEPS.9, DEPS.6 digest checks, and PRIME.7 install authorization).
- Fix: Define strict checking as the listed findings that both mypy strict and pyright strict report: untyped defs, missing type arguments, untyped calls, unused ignores, `Any` returns. Treat implicit `Any` from untyped imports as a separate sentence: stubs are declared in the dev-tool record, or the import carries a coded suppression with its reason. Alternatively, name pyright strict as primary in the table.

**3. PY.9 doctests against DOCS.10 (stated tolerance).**
- Problem: DOCS.10 compares shown results "within a stated tolerance". The table gives only `NORMALIZE_WHITESPACE` and `ELLIPSIS`. Ellipsis truncation is an unstated tolerance, and exact float reprs break across BLAS and platforms. This also sits oddly with PY.13 (state both rtol and atol). Two related points:
  - Doctest compares exception messages, and messages change between the oldest and newest Python that PY.11 runs.
  - DOCS.10 covers all documentation examples, but PY.9 and the table cover docstrings only.
- Fix: Add the pytest `NUMBER` flag, and require that the shown precision is the tolerance. Alternatively, examples print a boolean from `np.allclose` or `assert_allclose` with both tolerances stated. Add `IGNORE_EXCEPTION_DETAIL`. Add `--doctest-glob` for document examples, or a Sphinx doctest row.

### Should-fix

**4. Class onset against CLASS.10 (and the JL sibling).**
- Problem: The paragraph says each default instantiates "only DSGN, SIMPL, INTPR, REPRO, or VV". PY.14 instantiates RSRC.10. JL's equivalent sentence lists RSRC, and CLASS.10 applies RSRC in full from CSQ3. Separately, the Types note says CLASS.10 applies DSGN.1 and DSGN.3 "in full" from CSQ3. The CLASS.10 table has a DSGN.3 row (mechanical checking of safety-related contracts) that starts at CSQ0. JL.9 handles the same issue explicitly.
- Fix: Add RSRC to the list. Reword to "DSGN.3 applies from CSQ3 except the safety-related part, which starts at CSQ0".

**5. PY.12: `rng=None`, seed integers, and parallel streams (REPRO.1, REPRO.3, NUMER.24; JL.10-12).**
- Problem:
  - `None` yields fresh entropy that the standard does not require anyone to record. A script's `np.random.seed(0)` has no effect on `default_rng(None)`.
  - Passing an integer to two functions of one method yields identical streams, which NUMER.24 prohibits.
  - Parallel streams (`SeedSequence.spawn`) are only in the Notes. JL.11 makes the equivalent a provision (stream by part index, not thread id). Python's equivalent traps are worker pid and fork-copied state.
  - JL.12 (stable streams for exact-value tests, hash values) and JL.16 (seeded doctests) have no PY analog. NumPy `Generator` streams are not frozen across versions (NEP 19), and PY.11 spans NumPy 2.3 to 2.5. `PYTHONHASHSEED` varies string `hash` and set order.
- Fix:
  - Say that `None` or an integer is accepted only at an entry point, which records `rng.bit_generator.seed_seq.entropy` (I checked this works). Inner functions pass the Generator or its spawned children.
  - Add a clause like JL.11 for parallel work, spawned by part index from the recorded seed.
  - Add a clause like JL.12 for exact-value references, using `RandomState` or a stored array. State that doctests construct `default_rng(<seed>)`.
  - Extend the second sentence to also forbid seeding global state.

**6. PY.10 against numpydoc Returns, Yields and Attributes (verify with a numpydoc run).**
- Problem: To my knowledge the numpydoc guide says the return type is always required in Returns, and a lone header line parses as a type. RT02 also objects to a name on a single-value Return. Omitting types is workable for Parameters, whose type is optional, but the draft's claim that the guide is "silent" is only true about annotations. The Sphinx configuration (autodoc-typehints, `typehints_document_rtype`, napoleon or the numpydoc extension) is not in the table.
- Fix: State the Returns and Yields header form that numpydoc requires, and allow it. Alternatively, state that Parameters omit types and Returns carry the type only as the header. Run `numpydoc validate` on a sample. Add a documentation-build row.

**7. PY.18 scope and rationale.**
- Problem: MemoryError and FloatingPointError derive from `Exception`. The risky catch-all is `except Exception: pass` or log-and-continue, and PY.18 does not reach it. BLE001 in the config only partly helps, because it allows logging in place of a re-raise. Only CODE.7 (binding) covers it. A tuple containing BaseException is also uncovered.
- Fix: Extend PY.18 to `Exception`: the handler SHALL re-raise, or name classes narrower than those that include MemoryError, or end the failure visibly. Cover tuples. Correct the Notes.

**8. PY.13 (VV.3, NUMER.11, VVUQ.1/3; JL.19).**
- Problem:
  - Hand-rolled `abs(a-b) < 1e-9` is neither "a function that takes tolerances" nor an equality operator, so it is outside both sentences.
  - `assert_array_almost_equal` takes `decimal`, and `assert_array_max_ulp` takes `maxulp`. Neither can state both rtol and atol.
  - The defaults for NaN differ (`assert_allclose` `equal_nan=True`; `np.isclose` False; `math.isclose` False). VVUQ.3 governs NaN agreement, so the parameter should be stated.
  - VVUQ.1 admits bitwise and ULP tiers when justified. PY.13 allows exactness only under a "recorded requirement".
  - Forcing an atol invites copied `1e-8` with no basis.
  - `x == pytest.approx(...)` uses an equality operator.
- Fix: Reword to "each comparison within a tolerance, by function or by expression". Require, per VVUQ.1, the tier-appropriate parameters and an explicit NaN policy. Allow exact comparison of exact values. Name tolerances as constants (CODE.10) with the NUMER.11 basis beside them.

**9. PY.19 Note against CODE.7/12, and scope.**
- Problem: The Note says a scoped suppression with a CODE.12 reason is acceptable even for "convergence warnings that PRIME.4 requires". CODE.12 covers only failures that PRIME.4 does not list. For a PRIME.4 kind, CODE.7 forbids discarding at all, scoped or not. PY.19 covers only NumPy errstate and `warnings`. `scipy.special.errstate`, JAX `jax_debug_nans`, and torch anomaly mode are outside it.
- Fix: Say that confinement does not make discarding a PRIME.4-listed failure acceptable. The code must handle the status (for example, check solver convergence) and may then silence the redundant warning. Extend the scope sentence to "floating-point error handling of NumPy, SciPy or an accelerator library".

**10. Terms: "Public interface" and "Library code".**
- Problem:
  - "Public interface" includes tests, scripts and conftest, so every test function would need numpydoc and doctests.
  - It unions underscore-free names with `__all__`. Pydocstyle and Ruff treat a name outside an existing `__all__` as private. PY.2 relies on those rules.
  - "Library code" is circular, because tests import everything.
- Fix: Define the public interface as the underscore-free names of library code, or exactly the names in `__all__` where it exists. Define library code by the packages the work distributes. Exclude tests, scripts and notebooks explicitly.

**11. PY.11 and dependency record (DEPS.3, 4, 9, 10; REPRO.9; PRIME.7; HW.7).**
- Problem:
  - Metadata declares lower bounds, not the exact revision REPRO.9 and DEPS.10 need. A lock file with hashes is needed for DEPS.6 digests, and the draft does not say so.
  - Checks run on the oldest and newest Python, not on the declared lowest NumPy or SciPy. An untested lower bound is a false declaration.
  - The oldest/newest matrix runs at release. WPROC.9 allows that only as a recorded RSRC.12 deferral.
  - No exception exists for a qualified revision (trap #2).
  - The Notes claim library code "keeps the oldest release inside the window", but the provision only caps age.
  - NumPy 2.2 still lies inside a 24-month window on 2026-10-22 if it was released in December 2024 (verify). The provision literally allows declaring it, though the Notes say new work declares 2.3.
- Fix:
  - Add a lowest-bound resolution run to the release checks and record the deferral.
  - Say that the lock file is the pin.
  - Add "except a qualified revision, whose change CPS.3, HW.7 and HW.CPU.3 govern".
  - Either make the library statement a provision or recast it as informative.

**12. PEP 8 naming against mathematical notation (trap #1/#56; NUMER.4, DOCS.9).**
- Problem: The recommended `N` rules flag uppercase symbols. DOCS.9 lets a symbol stand beside the code name, and NUMER.4 wants notation mapped to names.
- Fix: In the Notes or table, allow a coded `# noqa: N803` with a symbol-to-name reason at the declaration (PY.7, CODE.4), or a per-file ignore for numerical modules. W505 at 72 columns also hits `.. math::` lines, so allow a per-docstring `noqa` there.

**13. PY.8 against PY.4 (within PY).**
- Problem: PY.4 limits variable annotations to module-level names and class attributes. PY.8 requires annotating "name that holds a NumPy array", which reads as every local. Inferred local arrays do not need it.
- Fix: PY.8 should read "each parameter, return value, module-level name and class attribute".

**14. PY.2 against the rule table.**
- Problem:
  - PY.2 requires agreement of raised exceptions. To my knowledge numpydoc validation has no Raises check, and the Ruff DOC rules are preview and optional, so that clause has no gating tool.
  - PY.16's encoding half has no selected rule (PLW1514 is a preview rule outside the table's sets).
  - T20 (no `print`) is configured repo-wide. PY.14 applies only to library code, and the Terms exempt scripts, CLIs and notebooks.
  - There is no provision-to-rule map: NPY002 for PY.12, B006 and B008 for PY.15, PTH for pathlib, E722 and BLE001 for PY.18.
- Fix: Add the map. Set per-file ignores for T20 outside library code. Relax or reword the exceptions clause, or gate it with the DOC rules.

**15. STND.VVUQ is cited but not listed.**
- Problem: The Notes say "STND.VVUQ governs comparisons of non-finite values", but the References table lacks it. DOCS lists the standards it cites.
- Fix: Add STND.VVUQ to References.

### Optional

**16. JL.9 analog is absent.**
- Problem: Python's equivalents of `@inbounds` and `@fastmath` go unmentioned: numba `fastmath=True`, `boundscheck`, `error_model`, extension builds with `-ffast-math`, and SciPy `check_finite=False`. The last of these removes input validity checking (PRIME.4).
- Fix: Add a default like JL.9: each use states why it is valid at its location, and fastmath on a numerical path is a performance approximation (NUMER.16/17).

**17. Silent substitution (PRIME.4).**
- Problem: `errors='ignore'` or `'replace'` in `open`, `decode` and `encode` silently corrupts data. PY.16 asks for the encoding only. `nan_to_num` and `clip` substitute silently in the same way.
- Fix: Add to PY.16, or to the Notes, that `errors=` is left strict. Note `nan_to_num` as a silent-default hazard.

**18. DRAFT.42 / PROJ.3 / DEPS.6 wording.**
- Problem: The type-checker install "needs an authorization (PRIME.7)". It does not say that a standing authorization under PROJ.3, with DEPS.6 digest checks, can give it. The same applies to Ruff, numpydoc and pytest.
- Fix: One clause naming the standing authorization.

**19. Docstring contract (JL.14 against PY.9/10).**
- Problem: JL.14 requires the CODE.3 contract (requires, guarantees, units, range). PY.10 covers only units, shape and range, and PY.9 documents only "raised exceptions for the caller to handle".
- Fix: Add "state the CODE.3 contract" to PY.9 or PY.10, and align the Raises wording with JL.14.

**20. PY.3 friction.**
- Problem: A nested `def` needs a blank line before it (Black, E306), which conflicts with "no blank line inside a block". The ERA001 rule may flag heading comments that contain `=` or code-like text.
- Fix: Add "except where the formatter requires one". Note the ERA false positives.

**21. PY.6 and ANN401.**
- Problem: A top-level `Any` triggers ANN401, so it needs both the PY.6 reason and the PY.7 coded suppression.
- Fix: Say that one comment of the form `# noqa: ANN401 - <reason>` serves both.

**22. Cross-language wording (JL.19 against PY.13).**
- Problem: PY.13 is wider (any comparison, plus an equality ban) than JL.19 (tests with `isapprox` only). Their LVL0 bases also differ: JL.19 cites NUMER.11, PY.13 does not.
- Fix: Align the two, ideally by adopting the PY.13 wording in both.

**23. Facts I could not verify.**
- Items to check before ratification: the Python 3.15 release date (2026-10-09), the tool versions (Ruff 0.16.8, Black 26.5.1, mypy 2.4, pyrefly 1.0), the NumPy 2.3 mypy plugin deprecation, and the Ruff 0.16 default changes.

**24. Ledger entry collision.**
- Problem: PY and JL both say "ledger entry 101" on the same base of entry 99. Only one can take 101.
- Fix: Re-rehearse the second one as 102.

## Verdict
No pair conflicts, and the draft is sound enough to adopt after three fixes: make anomaly reporting in PY.14 loud, restate "Strict type checking" so the mypy row meets it, and give doctests a stated tolerance. Findings 4-15 should be dealt with before ratification.
