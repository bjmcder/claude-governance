# Cold verification of STND.CXX draft 0.2

"Verify" marks a claim not checked offline.

## Findings

**1. Defect. Terms, "High-assurance code"; Purpose; CXX.31 to CXX.33.** The term covers all code of CSQ1 work but only the safety-related components of CSQ0 work. A CSQ0 component that is not safety-related therefore gets neither MISRA nor CXX.32, less than any CSQ1 code, inverting the class order that CLASS.18 keeps. *Fix:* define the term as code that "a release of work of CSQ1 or CSQ0 delivers or runs". Keep the CSQ0 SHALL of CXX.33 for safety-related components only: "For high-assurance code of a safety-related component of work of CSQ0 … SHALL; for other high-assurance code … SHOULD".

**2. Defect. Adoption rationale, `/home/claude/pkg/apply_cxx.py`, rehearsed as ledger entry 102.** The rationale still uses the 0.1 numbering:
- it says "31 provisions" where there are 33;
- it gives the transition period as "STND.CXX.18 and STND.CXX.19 within six months", but the binding provisions are CXX.4, CXX.19, and CXX.20;
- it says "STND.CXX.29, .30, .31 before reliance" where it means .31, .32, .33.

The Notes defer the transition to this append-only record (GOV.42). *Fix:* correct it before live application.

**3. Defect (technical; informative, but agents will copy it). Run-time detection paragraph.** In Clang, `float-cast-overflow` is already part of `-fsanitize=undefined`. The checks that the group leaves out are `float-divide-by-zero`, `unsigned-integer-overflow`, `implicit-conversion`, `local-bounds`, and `nullability-*`. Also, `integer` and `implicit-conversion` report defined behavior, such as unsigned wraparound in random-number generators and hashes. Under `-fno-sanitize-recover=all` they fail correct tests. *Fix:*
- drop `float-cast-overflow`;
- add `local-bounds`, and `float-divide-by-zero` only where the work does not rely on IEEE infinities;
- run `integer` and `implicit-conversion` in an advisory job with suppressions.

**4. Should-fix. CXX.6 sentence 2 and the Notes on `__FINITE_MATH_ONLY__`.**
- GCC and Clang always define `__FINITE_MATH_ONLY__`, as 0 or 1, so the obvious `#ifdef` stops every build. The test is `#if __FINITE_MATH_ONLY__` (or `__FAST_MATH__`).
- Contraction (`-ffp-contract`, `--fmad`) and most effects of `-march` have no predefined macro, so "stop compilation … under an option that it does not support" cannot be met for them.

*Fix:* "…under an edition, or an option that the compiler makes visible to the source, that it does not support".

**5. Should-fix. CXX.2 against CXX.3.**
- CXX.3 sentence 2 exempts an edition that a hardware contract or a toolchain qualification fixes. CXX.2 has no such exemption, so the same unit meets CXX.3 and breaches CXX.2. Sentence 2 otherwise repeats CXX.2 and carries two conditions (DRAFT.16).
- CXX.3 sentence 1 has a compiler-change trigger, which STND.DEPS.4 already covers ("each unit of work that changes a pinned revision").
- Sentence 3 restates HW.7 and STND.DEPS.5.

*Fix:* move the exemption into CXX.2 as its single leading condition, together with CXX.32. Reduce CXX.3 to "At each review of STND.DEPS.4, the edition in force SHOULD be reviewed against STND.CXX.2", and move sentence 3 to the Notes.

**6. Should-fix. CXX.2 test and the term "Toolchain matrix".**
- The matrix names compilers only, but standard-library support is documented separately, and CXX.12 treats the library as distinct.
- Read literally, "states complete support" may fail even for C++20 wherever a status page marks modules or a library item as partial. That would hold units at C++17, against the direction (verify against the status pages).

*Fix:* add the standard-library implementation to the term. Write "complete support of the edition's language features, modules excepted, and of its library by the unit's standard-library implementation".

**7. Should-fix. CXX.33, assertion row.** The "designed safe state" is defined by PRIME.13 only for systems that command hardware. A CSQ0 safety-related component that commands nothing, such as a criticality or shielding calculation, cannot meet the SHALL. *Fix:* "…drives the designed safe state where the component commands physical hardware, and otherwise halts with a diagnostic".

**8. Should-fix. CXX.33 table.**
- **Dereference row.** Member access goes through `this`, and iterators and smart pointers overload `->`, so the level count of `p_->x` is undecidable. *Fix:* "At most one explicit dereference of a raw pointer in each expression, the implicit `this` not counted".
- **"What it makes checkable" column.** It is explanation inside a provision body (DRAFT.12, the same issue as cold D5). Move it to the Notes.
- **Preprocessor row.** Say whether invoking a macro that a standard header or a dependency defines (`errno`, `UINT32_C`, `assert`) counts as use of the preprocessor. Pair D2 asked.

**9. Should-fix. CXX.31 sentence 2, when no analyzer is provisioned.** MISRA's text is licensed per named person, and at CSQ1 the per-change reviewer may be an agent (CLASS.18). Without rule text or an analyzer, a review cannot judge conformance, yet the record would claim it (PRIME.2). *Fix:* the record states whether a reviewer holding the rule text judged it. Where neither a license nor an analyzer is held, conformance is not claimed, and a decision record names a rule set that the work holds.

**10. Should-fix. CXX.26.**
- Sentence 2 requires every object shared with an interrupt handler to be a lock-free atomic. That forbids a ring buffer guarded by interrupt masking, which sentence 1 admits as "a synchronization facility of the target". *Fix:* add "…and that no facility of the first sentence orders".
- The onset paragraph says CXX.26 instantiates "the verification of DSGN.15". It states a protocol, so its onset is CSQ3.

**11. Should-fix. CXX.21 sentence 3.** With C++ exceptions disabled, every allocating standard operation "reports failure by throwing" (`bad_alloc`). The sentence therefore bans most of the library that CXX.11 prefers. *Fix:* "…SHOULD NOT reach a standard-library operation whose failure the path is designed to handle". The Notes then add that the build routes the remaining throws to a handler that halts with a diagnostic.

**12. Should-fix. Onset paragraph (cold D2 is only partly resolved).**
- It omits CXX.27. Checking an assumption is invariant checking (DSGN.2, VV.10, CSQ1).
- For CXX.16, expected results "taken from the stated requirement" are the independent-oracle part of VV.1 (CSQ2). Either list it or cite PRIME.2 as the basis.
- "None asks for … documentation" contradicts the decision record that CXX.4 asks for. State the consequence instead, as STND.DOCS.10 does: silent loss of the direction (GOV.11).

**13. Should-fix. Naming paragraph of the Notes.**
- `readability-identifier-naming` cannot separate the trait row either, because a trait is a struct and falls under StructCase. Nor can it check the type-alias row, because it has one TypeAliasCase.
- `k_eff` is already snake_case; use `Λ` as the example.

**14. Should-fix (scope). Growth.** 33 provisions, up from 24; several restate others despite the Purpose's "restates neither". Merge or move to the Notes without loss:
- CXX.8 (Core Guidelines F.7 and F.23, carried by CXX.1 and CXX.28);
- CXX.15 sentence 2 and CXX.26 sentence 3 (CP.8);
- CXX.16 sentence 3 (restates NUMER.11);
- CXX.3, merged into CXX.2 (finding 5);
- CXX.5 and CXX.6, as one "Stated build settings" with three sentences;
- CXX.20 sentence 1, reduced to its increment over STND.CODE.6.

That leaves 30.

**15. Optional. CXX.16 sentence 1.** "Shows one of its static assertions" invites a copy in the comment that drifts from the code (pair S16, STND.DOCS.13). *Fix:* "refers to the static assertion that follows it".

**16. Optional. CXX.4.** It binds only lowering. An agent that creates a new unit at an old edition, or deletes the stated edition, escapes it. Consider "set or lower".

**17. Optional. Smaller technical and prose points.**
- "`std::span` or `std::mdspan` at C++20 and C++23" should read: span at C++20, mdspan at C++23.
- CMSIS-style vendor headers cast inside a macro; only a linker-placed object needs no cast.
- "Unwinding unspecified" should read "ISO C++ defines no behavior".
- "Is reported to" (twice) is vague attribution under STND.DOCS.9; cite the GCC manual.
- A function-level `[[nodiscard]]` is lost through `std::function`; the type-level attribute covers indirect calls.
- The Purpose's "restrictions … that MISRA does not carry" contradicts the recursion row (pair O30 is only partly resolved).
- CXX.11 lacks a reason row for accelerator memory spaces (CXX.10).

**Checked, no finding:**
banned words, modal counts, titles, citation fields; modes (no default's closure reaches PRIME); STND.DRAFT.42; GOV.18; GOV.19; Notes against STND.DOCS.9 apart from item 17; the `[[nodiscard]]`, fast-math, contraction, MISRA, JSF, and C++26 claims.

## Dispositions

| Rows | Status |
| --- | --- |
| Cold D1, D3 to D6, S7, S8b, S8d, S10, S12 to S18, S20 to S22, O23 to O29; pair D1, D3, S4, S6 to S8, S10 to S15, S17, S19, O20 to O29, O31 | Resolved |
| Cold D2 (onset, finding 12); S8a (decline is reasoned and accepted); S8c and pair S18 (finding 9); S9 (scope inverted, finding 1); S11 (dereference and safe state, findings 7 and 8); S19 (wrong group, finding 3); pair D2 (macro invocation, finding 8); S5 (GSL mode unrecorded); S9 (sticky state, acceptable under HW.GPU.3); S16 (finding 15); O30 (finding 17) | Partly |
| None | Not |

## Verdict

Not ready for ratification. Findings 1 (the high-assurance scope inversion), 2 (stale numbering in the adoption record), and 3 (the sanitizer configuration) block. Findings 4 to 11 should go in before presentation.
