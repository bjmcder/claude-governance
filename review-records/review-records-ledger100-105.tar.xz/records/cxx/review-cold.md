# Cold review of STND.CXX 0.1 (condensed by the lead agent from the reviewer's report)

Severity: D = defect, S = should-fix, O = optional. Line numbers refer to draft.md.

## Defects

**D1. Notes, NASA.** "There is no NASA C++ coding standard" is unsupported. The research notes that the NASA Software Engineering Handbook names a GSFC C++ flight-software standard that was not retrieved. Say so and list it as an open item.

**D2. Class-onset paragraph.** Several defaults instantiate parts that CLASS.10 starts earlier than CSQ3:

- DSGN.15 verification at CSQ2 (CXX.18, CXX.20);
- DSGN.4 and DSGN.5 at CSQ2 (CXX.6, CXX.7, CXX.17);
- DSGN.2 postconditions at CSQ1 (CXX.21);
- DSGN.3 mechanical checking and VV.1 proof at CSQ0 (CXX.22 to CXX.24).

Do as HW.EMBED does: state the onset of each one, and state the tightening explicitly (PRIME.15). Also say what CXX.22 conformance serves. It reduces undefined behavior through a mechanical check, and it is not VV.1 evidence of correctness (risk of breaching PRIME.2).

**D3. CXX.16.** "Pass, in the statement that receives it, to a resource handle" cannot be met for out-parameter APIs (`cudaMalloc(&p, n)`, `MPI_Comm_dup`). Use: "SHOULD pass to a resource handle of the work before any other operation that is able to fail". The Notes should name a factory that takes the creating call.

**D4. CXX.17.** An OpenMP structured block carries no error. Allow "or recorded in a variable of the work (e.g. a `std::exception_ptr` or status) that code outside the foreign interface checks". Name `bugprone-exception-escape` in the Notes.

**D5. CXX.13 table.** The Example column puts examples into a provision body (STND.DRAFT.12). `PKS_ASSERT` also contradicts the CXX.24 preprocessor row. Move the examples to the Notes.

**D6. CXX.2 sentence 1.** It has a leading condition and a trailing one (DRAFT.16), and "implements" cannot be decided. Split it, and make it checkable: "the newest published edition for which each compiler's documentation lists complete support". Review the level when a compiler revision changes (DEPS.8). Put the allowance for individual newer features in its own sentence.

## Should-fix

**S7. C++17 at CSQ1/CSQ0 (CXX.23) against the standard's own idioms.** Concepts, `span`, `bit_cast`, and `consteval` are C++20. `expected`, `mdspan`, and `start_lifetime_as` are C++23. `inplace_vector` is C++26.

- Give CXX.6, .9, .11, and .12 their C++17 fallbacks: a named trait with `static_assert` naming the failed requirement; `gsl::span` or a project view type.
- Soften "no qualified compiler or analyzer covers C++20". That is absence of evidence. The decisive fact is that MISRA C++:2023 targets C++17.

**S8. CXX.22 scope, licensing, and fallback.**

- (a) Exclude third-party headers, dialects the analyzer does not parse, generated code, and tests from the claim of conformance. List them in repository configuration, each with its interface contract.
- (b) MISRA and the analyzers are paid. A purchase is reserved to the human owner. An agent works from analyzer diagnostics. Rule text is not copied into the repository or into agent context beyond what the license permits. Cite rules by identifier.
- (c) Give a fallback when no analyzer is available, following the DEPS.7 precedent: record that conformance was judged by review alone. The work should not block.
- (d) MISRA Compliance:2020 (GEP, GCS, deviation records) is the deviation procedure. This is unverified; say so.
- Add the DRAFT.42 statement to the Notes.

**S9. Scope of CXX.22 to CXX.24.** At CSQ0, scope to "the code of each safety-related component" (as CLASS.10, .17, and .18 do), not to the whole work. Align the title "Safety-critical" with "safety-related".

**S10. CXX.22 names no rule set.** Adopt MISRA C++:2023 in the provision, "unless a decision record names another (REPRO.7)", or state why it is left open. The custodian asked for a recommendation to adopt.

**S11. CXX.24 table.**

- Recursion is already a MISRA rule, and "no exceptions" comes from JSF/JPL, not Power of 10. Power of 10 rules 4 (function length) and 9 (pointer indirection) are omitted. Fix the Notes claim.
- Loop row: exempt a loop the design requires never to end, stating its exit conditions. Define "fixed" as a constant or documented maximum.
- Allocation row: define "initialization ends" and "general-purpose heap". A pmr `monotonic_buffer_resource` falls back to `new_delete_resource` unless its upstream is `null_memory_resource`; say so.
- Assertion row: a failure goes to the designed safe state (PRIME.13), not a bare abort.
- Exception row: make it checkable, by building with exceptions disabled or by analyzer proof.
- Preprocessor row: exempt include guards and the hardening and feature macros.

**S12. CXX.15, binding.**

- "Reports a failure" is wider than PRIME.4. Scope it to failures of a kind PRIME.4 lists, as CODE.7 does.
- CXX.19 is a default, so at CSQ4 the attribute has no consumer.
- `expected`, `optional`, and `error_code` are not `[[nodiscard]]` in the standard library.
- The transition sentence in the Notes cannot relax a binding SHALL.
- Proposed: "Each function of the work that returns a failure of a kind that PRIME.4 lists SHALL be declared so that the compiler or a static check diagnoses a call that ignores the result (PRIME.4)". Name `[[nodiscard]]` in the Notes.

**S13. No failure-channel policy.** Add a default: the repository configuration states, for each build, whether exceptions are enabled. Where they are enabled, a failure the caller is expected to handle is reported by return value. Where they are disabled, the code does not call standard-library operations that report failure by throwing. Also require that a destructor which detects a failed release reports it.

**S14. CXX.9 and CXX.10 narrow two directions without saying so.**

- "Prefer generic" became "only where already used for more than one type".
- "Prefer header-only" became "non-template code compiled", although `inline` makes header-only possible.
- The closed-set explicit-instantiation rule blocks `long double`, AD, and interval types.

State these departures with reasons in the Notes, and base the compile criterion on measurement (RSRC.4).

**S15. CXX.3 and header-only libraries.** An INTERFACE target cannot set `CXX_STANDARD` or disable extensions for consumers. Say "the minimum level a library delivered as headers requires". Exempt the language extensions that a foreign interface requires (CUDA).

**S16. `gsl::owner`.** The clang-tidy owning-memory check matches the alias template named `::gsl::owner`, so a project alias in another namespace is missed. This is unverified; check the clang-tidy source and say so in the Notes.

**S17. CXX.1.** Listing every Core Guidelines rule not followed is infeasible (about 500 rules). Say "each rule that the checks of STND.CXX.19 exclude, and each rule the work knowingly departs from". Sentence 2 duplicates CXX.22 at a weaker modal; delete it.

**S18. Reproducibility.**

- Contraction defaults differ: GCC uses `-ffp-contract=fast` for C++, Clang `on`, NVCC `--fmad=true` (verify). Record them under HW.5.
- `-ffinite-math-only` deletes `isnan` checks (PRIME.4).
- Standard-library random distributions, unordered-container order, and `std::reduce` order are implementation-defined or unspecified.

Add a default (REPRO.2, REPRO.3): where a reported result depends on such a facility, use an owned implementation or record the library revision with the result.

**S19. Sanitizers.**

- UBSan recovers by default. Require `-fno-sanitize-recover=all`, or state that the test fails on detection.
- `-fsanitize=undefined` omits `float-cast-overflow`, `implicit-conversion`, `integer`, and `local-bounds` in Clang.
- Archer needs Clang with OMPT.

**S20. Term "Metaprogramming facility".** It covers every template. Narrow it to "a concept, a type trait, an alias template, or a function template whose purpose is to compute a type or a value during compilation, or a constexpr or consteval function intended for evaluation during compilation".

**S21. CXX.18.** Add interrupt and signal handlers: lock-free `std::atomic` (`is_always_lock_free`) or `volatile std::sig_atomic_t`.

**S22. Prose and Notes.**

- "Each provision answers one of these" is false. Say "most".
- "Message passing … have their own rules" is wrong; they are not yet drafted.
- Present the MPI/OpenMP/CUDA deferral as a recommendation, not as decided.
- Remove drafting-stage text ("recommendations for the custodian to confirm", "presented to the custodian as a decision"). State each rule with its reason instead.
- The direction says metaprogramming is "recommended, but interpretable". The draft never recommends it affirmatively.
- Cite sources for dated facts (ISO page, compiler status pages, CUDA guide) and group them.
- "Offers" (copula avoided) appears in the CXX.8 and CXX.21 bodies.
- The section headings "Ownership and memory", "Libraries and generic code", "Names and documentation", and "Failures and boundaries" are reflexive "X and Y" headings.

## Optional

- **O23.** Qualify these unverified claims: MISRA categories, TC1:2026, vendor full-coverage claims, NVCC C++23 host requirements, `-Wlifetime-safety-permissive`, GCC C++23 marked experimental, and library support for `start_lifetime_as`. "An exception unwinding through C frames has no defined behavior" is better worded as "unspecified by ISO C++".
- **O24.** Naming:
  - Add a row for type aliases that are not trait results.
  - snake_case for namespaces and data members goes beyond the direction; list it as a choice to confirm.
  - Tighten the "STL-like" term to "models a named requirement or concept of the standard library by providing its member names".
- **O25.** CXX.6: write "view or range". "Computational kernel" is undefined.
- **O26.** CXX.21: hardening macros must be defined uniformly across a program (ODR/ABI). Mention `-fhardened`, `_FORTIFY_SOURCE=3`, and stack protectors, or say they are out of scope.
- **O27.** Lexicon collisions: "baseline" (measured performance) and "exception" (governance). Use "Core Guidelines reference" and "C++ exceptions at foreign boundaries".
- **O28.** SEI CERT C++ was recommended by the research as a gap review at CSQ1/CSQ0. Say whether it is intended only in the Notes.
- **O29.** No additions are needed for const-correctness, initialization, include hygiene, casts, or ABI, since the Core Guidelines cover them. Add a pointer to `cppcoreguidelines-init-variables`, `-Wconversion`, and `-Wsign-conversion`.

Verdict: the structure is sound and mostly honest. Fix the six defects and the issues with the C++17 consequences and with CXX.22 to CXX.24 before ratification.
