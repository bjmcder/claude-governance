# Dispositions of the cold verification of STND.CXX draft 0.2

Draft 0.3 renumbers the provisions. The 0.2 provisions map to 0.3 as follows:

| 0.2 | 0.3 |
| --- | --- |
| 1, 2 | 1, 2 |
| 3 | merged into 2 |
| 4 | 3 |
| 5, 6 | 4; the header-library guard moved to 10 |
| 7 | 5 |
| 8 | moved to the Notes as Core Guidelines F.7 and F.23 |
| 9 to 18 | 6 to 15 |
| new | 16, "Responses to listed failures" (binding; the shared PRIME.4 response list) |
| 19 to 22 | 17 to 20 |
| 23 and 24 | 21 |
| 25 to 33 | 22 to 30 |
| new | 31, "High-assurance deviations" (deviation sentences moved out of 0.2's 31 and 33) |

The count is 31 provisions. Four are binding: 3, 16, 17, and 18.

| Finding | Disposition |
| --- | --- |
| 1 High-assurance scope | Fixed. The term now covers the code that a release of work of CSQ1 or CSQ0 delivers or runs. STND.CXX.30 makes the restrictions SHALL for safety-related components of CSQ0 and SHOULD for other high-assurance code. The Purpose and Notes are updated. |
| 2 Rationale numbering | Fixed. `apply_cxx.py` gives 31 provisions and the 0.3 numbers. Its transition clause names binding provisions 16, 17, and 18, with 3 applying to agent actions from adoption. It cites no ledger entry number. |
| 3 Sanitizer list | Fixed. The `undefined,local-bounds` job adds `float-divide-by-zero` only where IEEE infinities are not relied on. `integer` and `implicit-conversion` run in an advisory job with suppressions. `float-cast-overflow` is dropped. |
| 4 `__FINITE_MATH_ONLY__` and invisible options | Fixed. STND.CXX.10 reads "an option that the compiler makes visible to the source". The Notes give `#if __FINITE_MATH_ONLY__` or `__FAST_MATH__`, and say contraction and `-march` go into the contract. |
| 5 CXX.2 against CXX.3 | Fixed. The exemption is the single leading condition of STND.CXX.2, together with STND.CXX.29. Review happens at STND.DEPS.4. HW.7 and STND.DEPS.5 are now in the Notes. |
| 6 Matrix and complete support | Fixed. The term covers the standard library implementations. The test reads "complete support of the language features, modules excepted, ... and of the library". The consequence that remaining library gaps may hold units at an older edition is listed as a decision for the custodian. |
| 7 Safe state of the assertion row | Fixed. The row reads "enters the designed safe state where the component commands physical hardware, and otherwise halts with a diagnosis", matching STND.CXX.16. |
| 8 Table of restrictions | Fixed: the dereference row (explicit raw-pointer dereference, `this` not counted), the explanation column moved to the Notes, and macro invocation excluded from "use of the preprocessor". |
| 9 No analyzer, no license | Fixed. STND.CXX.28 has conformance judged by provisioned analyzers and by reviewers who hold the text. The record names each judge, or says conformance is not claimed. The Notes cover agent reviewers and naming a rule set the work holds. |
| 10 CXX.26 interrupts; onset | Fixed. STND.CXX.23 sentence 2 opens "Where no synchronization facility of the target orders the accesses". It is removed from the DSGN.15 verification list, so its onset is CSQ3. |
| 11 CXX.21 sentence 3 | Fixed. STND.CXX.19 reads "SHOULD NOT reach a standard-library operation whose failure the path is designed to handle". The Notes describe the remaining throws as halting under STND.CXX.16, unverified for each library. |
| 12 Onset paragraph | Fixed. STND.CXX.24 is listed with DSGN.2 at CSQ1, and STND.CXX.13 with the independent-reference part of VV.1 at CSQ2. The floor claim is replaced by the consequence of omitting each binding provision. |
| 13 Naming tool limits | Fixed. The Notes now say the trait and alias rows are not separable. The notation examples are `Λ` and `β_eff`. |
| 14 Growth | Fixed. Removed: 0.2's CXX.8 (to the Notes), CXX.15 sentence 2 and CXX.26 sentence 3 (T.123 and CP.8 in the Notes), and CXX.16 sentence 3 (NUMER.11 in the Notes). Merged: CXX.3 into 2, CXX.5 and 6 into 4, and CXX.23 and 24 into 21. CXX.20 sentence 1 is reduced to its increment over STND.CODE.6. The brief's response provision and the deviation split bring the total to 31. |
| 15 Comment example | Fixed. The comment refers to the static assertions that follow it. |
| 16 Agent edition | Fixed. STND.CXX.3 has a second sentence: no new unit below the edition of STND.CXX.2. It is not extended to existing units below that edition, because a binding rule at CSQ4 would then force a change of edition on every touch. |
| 17 Smaller points | Fixed: span at C++20 and mdspan at C++23, CMSIS casts inside macros, "ISO C++ defines no behavior", the vague attributions replaced (FTZ and libc++ fast mode marked unverified, since the research notes do not support them), type-level `[[nodiscard]]` for indirect calls, the Purpose wording on MISRA overlap, and an accelerator-memory row. |

## Brief 0.3 shared items

- **Item 1.** STND.CXX.16 is the response list. STND.CXX.21, STND.CXX.22, and the assertion row refer to it or match it.
- **Items 2 to 5.** Python and Julia only; nothing for C++.
- **Item 6.** The performance-approximation classification is stated in the Notes only.
- **Item 7.** The judgments go to the decisions list, not the Notes.
- **Item 8.** The narration about the research is removed. "Unverified" marks only facts that the research notes do not support. GCC C++23 being experimental is [S], so it is no longer marked.
- **Item 9.** 31 provisions.
- **Item 10.** AT is 12:10. The rationale holds no ledger entry numbers.

## Remaining harness findings

- **g.14:** the number in "MISRA C++:2023", which is a name.
- **g.18 bundles:** STND.CXX.2, 4, 5, 10, 11, 19, 20, 21, 22, 28.

## Final verification

| Finding | Disposition |
| --- | --- |
| D1 CXX.29 feature permission | Fixed: "MAY be compiled at that later edition and use that feature and no other feature of that edition". |
| D2 CXX.3 project alternative | Fixed: "STND.CXX.2, or the alternative that a project instrument adopts in its place". The exemption in both sentences now names the compiler, the rule set, the hardware contract, or the qualification of the toolchain. |
| S1 Notes hygiene | Fixed. Each listed fact is marked unverified or rewritten. "About 500" becomes "several hundred". The ABI clause is dropped. The GSL macro name is replaced by "the contract-violation setting of the GSL release in use", marked unverified. |
| S2 libc++ lower | Fixed in the Notes, marked unverified, and listed in decisions.md as item 2. |
| S3 LVL0 in the Notes | Fixed. The Notes now cite PRIME.6 and PRIME.7 with an authorization. The repository holds identifiers and diagnostics, not rule text. "Code compiled into CSQ0 work is used at CSQ0 (GOV.14)". |
| S4 CXX.18 at CSQ4 | Fixed: the provision opens "Where CPS.5 or CPS.9 applies to the work". |
| S5 Onset of CXX.3 sentence 2 | Fixed in the Notes, and listed in decisions.md as item 5. |
| S6 Sanitizer line | Fixed: "with Clang". |
| O1 Commas in CXX.16 | Fixed. The title "C++ responses to listed failures" is kept. |
| O2 "or runs" | Fixed in the Purpose and the rationale. |
| O3 `_M_FP_FAST` | Fixed. |
| O4 MISRA categories | Fixed. Only MISRA Compliance:2020 stays unverified. |
| O5 RSRC.12 | Fixed. |
| O6 Records in the rationale | Fixed, cited generically. |

The remaining harness findings are all of class review:

- **g.11 on CXX.3:** the list sits in the exemption, not under the prohibition.
- **g.14:** the number in "MISRA C++:2023", which is a name.
- **g.18:** ten three-modal bundles.

## Rulings of 2026-10-23

| Ruling | Disposition in draft 0.4 |
| --- | --- |
| Floor judgments agreed | Applied. The Notes state the ruling (PRIN.10), and the rationale repeats it. |
| C++ naming rows kept | Applied. The Notes cite the ruling. |
| Shared: platform and compiler agnostic | Applied. No provision names a version, compiler, platform, library dependency, or tool. The Notes carry no tool configuration. Compilers and libraries are described generically, apart from hazard examples. The GSL, MISRA, JSF, NASA, Power of 10, compiler names, flags, and dated status facts are removed. |
| CXX 1, any high-assurance standard | Applied. STND.CXX.28 requires conformance to the standard that a decision record adopts, with its revision and deviation procedure: SHALL for safety-related components of CSQ0, SHOULD elsewhere. The new binding STND.CXX.29 (PRIME.2) limits claims to what was checked and says by what means. The term is "High-assurance coding standard". |
| CXX 2, no restriction table | Applied. The table is removed. The Notes describe in general terms what such standards restrict. |
| CXX 3, validation status | Applied. STND.CXX.30 requires an edition that the adopted standard covers and that the toolchain is validated or qualified for (SHALL or SHOULD as in CXX.28). No edition is named. One later feature at a time is allowed by decision record. |
| CXX 4, latest supported elsewhere | Applied. STND.CXX.2 requires the newest edition that each compiler and standard library documents as supported, and keeps the admission of later features. |
| CXX 5, licensing | Applied. All licensing and purchase text is removed. |
| CXX 6, transition | Applied. The rationale says "Transition (GOV.42): none". The Notes hold no transition sentence. |
| CXX 7, GSL | Applied. STND.CXX.5 asks for "a type alias that the static checks of STND.CXX.25 recognize as marking ownership". |
| STND.CODE.13 | Cited in the naming paragraph of the Notes. |

## Verification of the rulings

| Finding | Disposition |
| --- | --- |
| D1 Dates | Left to the coordinator, as directed. DATE and AT are unchanged. |
| D2 Floor of CXX.29 | Fixed. The Notes and the rationale attribute the ruling only to STND.CXX.3, STND.CXX.16, STND.CXX.17, and STND.CXX.18. CXX.29's own argument is stated: it adds only the naming of means to PRIME.2 and reaches only high-assurance code. It stays as item 1 in decisions.md. |
| S1 CXX.26 | Fixed. It now reads "each kind of undefined behavior that the repository configuration lists". |
| S2 CXX.30 | Fixed. It now reads "that the decision record of STND.CXX.28 states the work requires", and STND.CXX.28 is added to refers_to. |
| S3 Term | Fixed. It now reads "its own or one that the decision record adopting it sets". |
| S4 CXX.31 in the Notes | Fixed. The Notes now say STND.CXX.31 requires the record of each deviation wherever such a standard is adopted (REPRO.7). |
| S5 CXX.16 | Fixed. It now reads "enter the designed safe state of PRIME.13 of the hardware that it commands". |
| O1 CXX.30 sentence 1 | Fixed. It opens with "Other than for a feature that a decision record admits under this provision". |
| O2 Model names | Fixed. The Notes now use the Purpose's generic terms. |
| O3 Dated Core Guidelines release | Fixed (dropped). |
| O4 DRAFT.42 narration | Fixed (dropped). |
