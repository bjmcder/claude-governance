# STND.CXX draft 0.4: open decisions for the custodian

The rulings of 2026-10-23 closed every earlier item, except item 2 below, which remains from the earlier list (item 8). The remaining items are new in 0.4.

1. **New binding provision STND.CXX.29 (PRIME.2).**
   - What it does: a claim that high-assurance code conforms to its adopted coding standard states the means that checked it and the rules those means covered. The claim goes no further than that.
   - Why it is binding: it instantiates PRIME.2, so it binds at every class. High-assurance code exists only at CSQ1 and CSQ0, so it never reaches the floor.
   - *Recommend:* accept, and rule that it raises no floor.
2. **MPI, OpenMP, and CUDA.** They have no LVL2 standards yet; STND.CXX holds only the C++ rules at their boundaries.
   - *Recommend:* draft one standard per model later, MPI first, in agnostic form.
3. **Edition wording (STND.CXX.2).** The ruling says "the latest possible that's supported by the compiler". The draft reads that as "the newest edition that the documentation of each compiler and standard library of the matrix states as supported".
   - This drops the "published" and "complete support" tests from 0.3.
   - Consequence: a compiler mode for a draft edition qualifies once its documentation marks it supported.
   - *Recommend:* accept. Feature-test macros guard the individual features.
