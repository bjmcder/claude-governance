# STND.HARN.28 pair review of STND.CXX draft 0.1

Reviewer is not the author. Nothing under /home/claude was changed. I read the draft, the 24 CXX provision files, the cited LVL0/LVL1/LVL2 text in the scratch corpus, and STND.HARN.28. I ran the read-only `pairs` command. Claims about MISRA contents, compiler flags and library behavior are from recall, since there is no network. I mark them "verify".

## 1. Harness pairs (320)

**Harness list check.** The `pairs` output is byte-identical to pairs.txt. I recomputed the set independently from `instantiates` fields (every CXX provision against every AGENT/NUMER/MEAS/CPS/ML/HW*/HDES provision sharing a LVL0 provision outside GOV and PRIN). It gives the same 320 pairs, with none missing and none extra. CXX.4, .5, .10, .16 and .19 have no pair at all.

**Verdict counts: compatible 312, conflict 0, gap 3, redundancy 2, trap 3.**

**Compatible pairs (312), by basis:**

| Basis | Count | Changed side |
| --- | --- | --- |
| VV.1 | 217 | CXX.12: 56, CXX.22: 55, CXX.23: 55, CXX.24: 51 |
| DSGN.5 | 24 | CXX.17 (all 24) |
| REPRO.7 | 21 | CXX.1: 4, CXX.8: 4, CXX.21: 4, CXX.22/23/24: 3 each |
| RSRC.4 | 10 | CXX.8: 5, CXX.21: 5 |
| REPRO.2 | 10 | CXX.3 |
| DSGN.4 | 10 | CXX.6: 5, CXX.7: 5 |
| INTPR.1 | 6 | CXX.1, .2, .11, .12, .13, .14 against NUMER.4 |
| DSGN.15 | 5 | CXX.18: 2, CXX.20: 3 |
| PRIME.4 | 3 | CXX.15 against HDES.14, HW.8, HW.GPU.3 |
| REPRO.7 + VV.1 | 3 | CXX.22/23/24 against NUMER.5 |
| DSGN.16 | 2 | CXX.7 against CPS.5 and NUMER.27 |
| DSGN.2 | 1 | CXX.21 against ML.6 |

Notes on the compatible groups:
- The VV.1 group is the CXX.22/23/24 rule-set and level provisions, plus CXX.12, against profile provisions about hardware, numerics and design. They add language-level coding evidence and never contradict or duplicate the profile evidence. HDES.* applies only if C++ is the hardware description (see finding 26).
- #99 (CXX.20 against HW.11) is compatible. Thread-sanitizer runs are detection, not the HW.11 protocol verification, and the draft does not claim otherwise.
- #91 (CXX.17 against HW.EMBED.4): a `noexcept` violation ends in `std::terminate`, which is a halt, so its output state belongs in the HW.EMBED.4 contract (see finding 11).
- #90 (CXX.17 against HW.CPU.3): an FP-state change needs an RAII guard so it is restored on every return to foreign code (see finding 23).
- #304 (CXX.7 against CPS.5): the register layer is the natural place for the CPS.5 limit check.
- #316 and #317 (CXX.8 against NUMER.16 and NUMER.17): CXX.8's "measured shortfall" evidence covers speed only. Accuracy is NUMER.17's job, and a cross-reference would help.

**Non-compatible pairs (8):**

- **#95 CXX.18 against HW.11 (DSGN.15): gap.** CXX.18 says "from more than one thread". HW.11 covers "an interrupt handler and the code it interrupts". CXX.18 cites HW.11 as instantiated but narrows its scope, which PRIME.15 disallows. See finding 10.
- **#101 and #102 CXX.21 against CPS.5 and CPS.9 (DSGN.2): trap.** CPS.5 and CPS.9 want a limit or plausibility check that cannot be dropped. CXX.21 lets library-hardening checks be dropped under a budget. If a project implements those checks with hardening, `assert` or GSL contract macros, CXX.21's escape removes them. See finding 5.
- **#232 CXX.24 against CPS.4 and #263 CXX.24 against HW.EMBED.4: gap.** CXX.24 row 5 keeps assertions in production but never says what a failed assertion does. CPS.4 needs a safe state on loss of the commanding software. HW.EMBED.4 needs the output state after a halt. See finding 11.
- **#259 CXX.24 against HW.20 and #262 CXX.24 against HW.EMBED.3: redundancy, benign.** Rows 1 to 3 (heap, loop bound, recursion) overlap the memory, stack and WCET bounds. HW.EMBED.3 and HW.20 demand evidence and a margin, and CXX.24 supplies only the means. Add a cross-reference, not a change of obligation.
- **#320 CXX.9 against NUMER.27 (DSGN.11): trap.** CXX.9 gates generality on "more than one type the work uses". NUMER.27 makes derivative capability a standing need. The real conflict is CXX.10 against NUMER.27 (finding 1), which the harness never pairs.

**HARN.28 second question (matters no table gives).** I found no matter that needs a new owning-profile entry. Two matters sit between CXX and an existing owner without a cross-reference. Memory, stack and timing bounds belong to HW ("Budgets of a constrained target"). Concurrency in interrupt context belongs to HW.11.

## 2. Findings

Severity: D = defect, S = should-fix, O = optional.

**D1. CXX.10 (closed-set split) against NUMER.27, with CXX.9.** Pair #320.
- *Problem:* CXX.10 sentence 2 and the Notes put templates instantiated for a closed set (`float`, `double`) in a source file, so the definition is invisible to other types. NUMER.27 says a numerical method must not preclude derivatives (dual or AD types) without reimplementation. A LVL2 default that contradicts LVL1 is void under PRIME.15. CXX.9's "present need" wording invites the same misreading.
- *Fix:* In CXX.10, keep the template definition in the header and let the source file hold only an `extern template` declaration plus the explicit instantiation. Say that a numerical method under NUMER.27 never takes the closed-set exemption. In CXX.9, say that NUMER.27 supplies the present need.

**D2. CXX.24 row 6 (preprocessor only for includes and build-configuration tests) against CXX.10, CXX.13, CXX.21 and CODE.4.**
- *Problem:* Row 6 is a SHALL at CSQ0, and the draft itself contradicts it:
  - CXX.10 requires guarded headers (SF.8), which means `#ifndef` and `#define`.
  - CXX.13's macro row uses `PKS_ASSERT`.
  - CXX.24 row 5 needs assertions, which at C++17 means a macro (no `std::source_location`).
  - CXX.21 defines `_GLIBCXX_ASSERTIONS` "before every include".
  - CODE.4 suppression with a reason needs `#pragma` for compiler diagnostics.
  - It is unclear whether invoking a library macro such as `Expects` counts as "use of the preprocessor".
- *Fix:* Extend row 6 with "include guards, diagnostic-suppression pragmas that carry their reason, and the project's single assertion macro". State that invoking a macro defined elsewhere is allowed only for those. Give the hardening macros as command-line definitions only.

**D3. CXX.23 (C++17 at CSQ1/CSQ0) against CXX.6, .8, .9, .11, .12 and the Notes.**
- *Problem:* The standard's own idioms are unavailable at the classes where it says SHALL:
  - Concepts (CXX.9, .11, .12) are C++20.
  - `std::span` (CXX.6) is C++20.
  - `std::mdspan` and `std::expected` are C++23.
  - `std::inplace_vector` is C++26, and `std::start_lifetime_as` (CXX.7 Notes) is C++23.
  - `consteval` is C++20.
  - The Notes' list of "likely candidates" omits concepts. So every CSQ1/CSQ0 project meets CXX.11 only by a per-feature decision record, or by the `enable_if` style that the Notes discourage.
- *Fix:*
  - Add "at the edition in force (STND.CXX.2 or .23)" to CXX.6, .8, .9, .11 and .12, and name the C++17 fallback (project view type, `static_assert` on a named trait).
  - Add concepts to the candidate list, or say plainly that CSQ1/CSQ0 code states constraints by trait and `static_assert`.
  - Make the Notes examples (`start_lifetime_as`, `inplace_vector`, `expected`) conditional on the edition.

**S4. Mixed classes: scope of CXX.2, .10 and .22 to .24.**
- *Problem:* CXX.22 to .24 say "work of CSQ1/CSQ0", but nothing says what code that covers.
  - A header-only library included by both a CSQ0 controller and a CSQ3 simulation falls under CXX.23 (C++17, rule set) for the CSQ0 translation unit. This conflicts with CXX.10's "headers alone" and CXX.11's concepts, and the draft states no rule for it.
  - Test and tool code (GoogleTest and Catch2 macros, heap, exceptions) and vendored third-party headers fall under rows 1, 4 and 6 literally.
  - GOV.13/14 allow a lower class only for a component shown to be isolated, and a shared header is not isolated.
- *Fix:* State three things.
  - Code compiled into a translation unit of a component takes the provisions of that component's class, so a shared library meets the most severe class of any includer.
  - CXX.22 to .24 apply to the work's own released code, not to test and tool code (the project may opt in).
  - Incorporated external code is governed by STND.DEPS and DSGN.5, not by the rule set, and its contract and the wrapper that isolates it are recorded.

**S5. CXX.21 and Notes: checks that a build setting can remove, against CODE.6, DSGN.2, CPS.5 and CPS.9.** Pairs #101 and #102.
- *Problem:* The Notes address `assert` and contracts but not the other removable checks:
  - Library hardening (`_GLIBCXX_ASSERTIONS`, libc++ and MSVC modes).
  - `gsl::not_null` and `narrow` under `GSL_UNENFORCED_ON_CONTRACT_VIOLATION`, and `NDEBUG`.
  - CXX.21's budget escape applies to every hardened check, so a project that uses `.at()` or a hardened `operator[]` as its input validation can disable CODE.6 and DSGN.2 checks by decision record.
  - Separately (verify), libc++'s "fast" mode traps with no message, which lacks PRIME.4's "actionable diagnosis".
- *Fix:*
  - Add to CXX.21, as normative text, that a check CODE.6, CPS.5, CPS.9 or HW.8 requires is ordinary code with a defined failure response and does not rely on hardening, `assert` or GSL contract macros.
  - Say that the budget escape covers only hardening checks that no such obligation depends on.
  - Record the GSL contract-violation mode in the dependency decision (DEPS.1).
  - Prefer a hardening mode that prints a diagnostic where PRIME.4 applies.

**S6. `-ffast-math`, `-march=native` and header-only code compiled with the consumer's flags.**
- *Problem:* The Notes treat fast-math as an arithmetic matter only (HW.5, NUMER.17). It also implies `-ffinite-math-only`, so `isnan` and `isfinite` input checks can be optimized away. That is a CODE.6/PRIME.4 breach and is not an HW.5 matter. Linking with fast-math can also set flush-to-zero and denormals-are-zero for the whole process (verify), which is HW.CPU.3 control state. Header-only code (CXX.10) is compiled with the consumer's flags, so the shipped contract cannot control them. CXX.3 pins only the language level and extensions.
- *Fix:*
  - Add a CXX.3 sentence: the repository configuration also states each option that sets floating-point semantics (fast-math family, contraction, `-march`, hardening mode).
  - Say that `-ffinite-math-only` and `-ffast-math` are never applied to a unit containing a non-finite check.
  - Give header-only libraries a compile-time guard of the CXX.2 kind, e.g. `#error` if `__FINITE_MATH_ONLY__`, and state the supported flags in the library contract (CXX.14).

**S7. CXX.17: "converted to an error that the foreign interface carries."**
- *Problem:* Some foreign interfaces carry no error: the OpenMP structured block (which the Notes cite), a `std::thread` entry, a C comparator or callback. For those the only compliant act is `catch (...)`, then swallow, which is silent continuation (PRIME.4, CODE.7).
- *Fix:* Add "where the interface carries none, the error is stored (e.g. `std::exception_ptr` or a status object ordered per CXX.18), checked after the region or thread returns, and reported or re-raised there".

**S8. CXX.16/CXX.4: RAII release hides failure.** Touches HW.GPU.3 (binding), PRIME.4 and CODE.7.
- *Problem:* The Notes recommend handles for "a device allocation, a stream, a file", and the draft says only that destructors do not throw. Several release paths report earlier errors and lose them in a destructor:
  - `cudaFree` and stream or event destruction can report earlier asynchronous kernel errors.
  - `std::ofstream` and `MPI_File_close` can fail on flush or close, e.g. disk full, which is resource exhaustion.
  - HW.GPU.3 requires completion status before a result is relied on.
  - The Notes cite CODE.7 for "a destructor that detects a failed release still reports it", but CODE.7 covers only PRIME.4-listed failures (CODE.12 covers the rest). Nothing says how a destructor reports.
- *Fix:* In CXX.16, a handle whose release can fail in a way that affects a result SHALL offer an explicit `[[nodiscard]]` `close()` or `synchronize()` that returns the status, and the destructor is the fallback. Cite CODE.7 and CODE.12 correctly.

**S9. CXX.15 scope and forms.**
- *Problem:*
  - "Failure" is undefined. PRIME.4's list (invalid input, precondition violation, non-convergence, resource exhaustion) is not referenced.
  - `std::expected` is, I believe, not required to be nodiscard (verify), so every function returning it needs the attribute or a project wrapper.
  - "Through its return value" misses out-parameters and sticky state (`errno`, stream state, `cudaGetLastError`).
  - Foreign functions (`fclose`, `cudaError_t`, `MPI_*`) are not "of the work", so only CODE.7 reaches them.
  - `static_cast<void>` and `std::ignore` silently defeat the attribute.
- *Fix:*
  - Define failure by reference to PRIME.4 and name the CXX.15 coverage.
  - Add "a call that casts the result to void or assigns it to `std::ignore` discards it (CODE.7, CODE.12)".
  - Add that a foreign status return is wrapped by a nodiscard function of the work (CXX.16).

**S10. CXX.18 scope.** Pair #95.
- *Problem:* "More than one thread" omits interrupt handlers and signal handlers. A `volatile` flag is still not an ordering tool there, and lock-free atomics are the tool. Freestanding builds may lack `<atomic>`.
- *Fix:* Write "more than one thread, interrupt handler, or signal handler (HW.11)". Add a reason row to the CXX.8 table for atomics unavailable on a freestanding target.

**S11. CXX.24 row 5 (assertions kept in production): failure response.** Pairs #232 and #263.
- *Problem:* Row 5 and the CXX.17 `noexcept`/terminate path say nothing about what a failed assertion does. In a safety-related component a bare abort can leave outputs unsafe (PRIME.13, CPS.4, HW.EMBED.4, HW.8).
- *Fix:* Add "and its failure drives the designed safe state with a diagnostic (PRIME.4, PRIME.13)". Add a Notes line that `std::terminate` and the abort handler on such paths are configured to do so and are covered by the HW.EMBED.4 output-state statement.

**S12. CXX.24 row 2 (loop bounds).**
- *Problem:* A bounded iterative solver that exits silently at its bound is a PRIME.4 non-convergence failure (NUMER.10 stopping criteria).
- *Fix:* Add "a loop that reaches its bound without meeting its exit condition reports non-convergence (PRIME.4, NUMER.10)".

**S13. CXX.8 reason table is closed but incomplete.**
- *Problem:*
  - There is no row for cross-implementation reproducibility. `<random>` distributions, `std::reduce` and parallel algorithms, unordered iteration order and `std::hash` differ across libstdc++, libc++ and MSVC. CXX.2 envisages exactly such multi-compiler matrices, and REPRO.3, HW.12, NUMER.24 and DSGN.17 are affected.
  - There are no rows for CXX.24 rows 3 and 4. Library facilities that recurse (`std::sort`, `std::map` destruction) or throw (`at`, `bad_alloc`, `function`, `optional::value`) cannot be justified by "Exceptions disabled", because CXX.24 does not require that build setting.
  - A C++-as-hardware-description (HLS) target has no "synthesis subset" row.
- *Fix:* Add rows:
  - "Reproducibility across the matrix": the unspecified behavior, and the REPRO.3 test.
  - "Class restriction (CXX.24)": the row, and the operation that violates it.
  - "Synthesis subset": the tool's supported facilities.

**S14. CXX.2 and the Terms: "toolchain matrix."**
- *Problem:*
  - The Term is project-wide ("compilers that build a translation unit of the work"). CXX.2 uses "its toolchain matrix", per unit. Read project-wide, a single NVCC or MSVC pulls every host translation unit down to the lowest level. CXX.23 uses a third wording, "each compiler building its released code".
  - "Newest edition each compiler implements" is dynamic. Every compiler bump silently moves the target level, against DEPS.3/4 pinning, REPRO.1 and VV.8.
- *Fix:* Define "toolchain matrix of a unit". Use that one phrase in CXX.2, .3 and .23. Say that CXX.2 is evaluated at the DEPS.4 review, and that a level change is a recorded change with re-verification.

**S15. CXX.12: overbroad term.** Pairs #46 to #63 are unaffected, since they are compatible.
- *Problem:* The Terms define "metaprogramming facility" as any template "whose result is a type". Every class template qualifies, so CXX.12 (a comment, an example, and `static_assert`s of accepted and rejected cases) lands on every container, algorithm and solver. The term also lists `consteval` but not `constexpr`, while CXX.11 names both.
- *Fix:* Narrow it to "a template, concept, trait, or constexpr/consteval function whose purpose is to compute a type, value or choice of code at compile time from its arguments".

**S16. CXX.12 against DOCS.8 and DOCS.10 (checked examples), and PRIME.2.**
- *Problem:* The comment example and the `static_assert` are separate texts that can drift. DOCS.10 wants documentation examples run in the checks. A `static_assert` that restates the facility's own definition is tautological evidence (PRIME.2). A floating-point constexpr result is computed by the compiler's arithmetic, which is another execution path with its own delivered arithmetic (HW.5, NUMER.5). Equality assertions on it can differ across compilers.
- *Fix:* Say that the example is the `static_assert` (or is compiled from it), and that the expected value comes from the stated semantic requirement, not from the facility. For floating-point results, compare to the run-time result within a NUMER.11 tolerance.

**S17. Last Notes paragraph: "Existing code conforms when a change next touches it" against GOV.14.**
- *Problem:* On promotion to CSQ1/CSQ0, GOV.14 says nothing is grandfathered. A C++23 code base promoted to CSQ1 must be at C++17 and MISRA-conformant before reliance, not when next touched.
- *Fix:* Limit the sentence to adoption of this standard, and add that work moved to CSQ1/CSQ0 meets CXX.22 to .24 before reliance (GOV.14).

**S18. CXX.22 and tooling: PRIME.7, GUARD.1/13, reserved actions, DRAFT.42, WPROC.**
- *Problem:*
  - CXX.22's analyzers (Polyspace, Helix QAC, SonarQube in the Notes) need installation (PRIME.7). A purchase is an explicit monetary transaction, reserved to the human owner. Fetching GSL, clang-tidy or other tools needs network authorization (GUARD.13).
  - MISRA is licensed to a named person. An agent author or an agent reviewer (CLASS.18 and WPROC.10 allow agent reviewers at CSQ1 and below) cannot hold it. Departure records must cite rule identifiers, not quote the licensed text.
  - The provision gives no fallback when no analyzer is provisioned.
  - DRAFT.42: no violation, because the purchase is an assigned decision. But the line of work should halt and refer (PRIME.14), not the whole project.
  - WPROC.9 may defer a heavy analyzer run to release (RSRC.12), which CXX.22's "each change SHALL conform" does not mention.
- *Fix:* Add a Notes paragraph covering these points:
  - Analyzers and licenses are provisioned by the human owner. An agent never installs or buys them.
  - An absent analyzer halts and refers that line only.
  - Rule text reaches agents only through analyzer output.
  - Cite rules by identifier.
  - State whether deferral to release is allowed.
  - Record analyzers in the DEPS.9 tool record.

**S19. Requirements that live only in the Notes (informative).** Under "Normative and informative parts" they do not bind.
- *Problem:*
  - The Notes say this standard governs where it differs from the Core Guidelines.
  - They say destructors do not throw.
  - They say `assert` and contract assertions cannot serve as CODE.6 checks.
  - They give the register-access pattern.
  - They say `observer_ptr` is not used.
- *Fix:* Move the first three into the bodies of CXX.1, CXX.4/16 and CXX.15/21 respectively. Leave the rest informative.

**O20. CLASS.10 application text.**
- *Problem:* The draft says CXX.1 to .21 "apply from CSQ3". For CXX.6/7 (DSGN.4 schema part), CXX.17 (DSGN.5 contracts) and CXX.18/20 (DSGN.15 verification), the LVL0 part starts at CSQ2. HW.EMBED states that kind of tightening explicitly.
- *Fix:* Say the same here, or start those provisions at CSQ2.

**O21. Drafting and terms.**
- "Safety-related component" (CXX.24) is defined in STND.CLASS but not imported in Terms.
- "Resource" in CXX.4 and CXX.16 collides with the Lexicon (compute time, energy, memory and so on), and as written it would cover memory only. Use "owned resource" and define it.
- "Departure" is used for rule deviations, while AGENT.47 and WPROC.13 use "departure" differently. Use "deviation".

**O22. CXX.1 second sentence** says the work "SHOULD follow the rule set" where it differs. CXX.22 says SHALL, so the sentence is a weaker redundancy. Delete it or make it "SHALL (STND.CXX.22)".

**O23. FP control state (HW.CPU.3).** An FP-environment guard is naturally a "resource handle" in CXX's sense. Name it in CXX.4 or the Notes, with the new-thread behavior.

**O24. Assumption attributes.** `[[assume]]` (C++23), `__builtin_assume` and `std::unreachable` turn a precondition into undefined behavior if it is false, which contradicts DSGN.1 and PRIME.4. Say that an assumption is used only where a check or proof precedes it.

**O25. Naming and boilerplate.**
- CXX.13 rows 2/3 are not mechanically checkable. A class that gains `begin()` or `size()` flips category, which means a public rename (DSGN.6).
- CXX.14 asks for the owner and validity of every pointer, reference and view in every declaration, which invites boilerplate (DOCS.6). Exempt arguments borrowed only for the call.

**O26. HLS scope.** One sentence on whether C++ used as hardware description (HLS) or testbench is in scope. If it is, HDES applies to the realization, CXX to the source, and CXX.8 needs the synthesis-subset reason (S13).

**O27. CXX.7 under the rule set.**
- *Problem:* A `reinterpret_cast` or integer-to-pointer register access is a CXX.22 deviation at CSQ1/CSQ0 (verify the MISRA category; a mandatory rule admits no deviation). The CXX.7 body mentions neither the deviation nor the CPS.5 limit-check placement.
- *Fix:* Prefer the linker-symbol or vendor-header `extern volatile` register object, which needs no cast. Say that the CPS.5 limit check sits in the register layer.

**O28. CXX.15 and the floor.** The Notes call CXX.15 "a tightening of PRIME.4 at every class" and also say "no provision raises the floor (GOV.11)". STND.CODE.6/7 take the same stance, so this is consistent with corpus practice. Reword to avoid the apparent self-contradiction.

**O29. CXX.4 sentence 2 repeats CXX.16 sentence 1** (foreign resource passes to a handle), and CXX.16 sentence 3 repeats CXX.4 sentence 1. Merge or cross-cite.

**O30. CXX.24 table against MISRA overlap (verify).** The Notes say the table holds only Power of 10 rules that MISRA does not carry. Recursion, and probably preprocessor use and dynamic memory, are MISRA C++:2023 rules. If so, the claim is inaccurate, but the table is still harmless as "in addition". Reword the claim, or check against the licensed text.

**O31. Release reporting.** WPROC.13 and AGENT.47 require every skipped, disabled or weakened check and every deviation to be presented at release. Specify one greppable marker for CXX.22 deviations and CODE.4 suppressions so the release record is generated mechanically.

**Checked, no finding:**
- DRAFT.42 passes.
- GOV.18 passes: tool names sit in the Notes.
- GOV.19 passes: only CXX.15 is binding.
- DOCS.3 passes: REPRO.7 decision records are not process records, so code may cite them (CXX.8, .21, .22).
- DEPS.8 and DEPS.1 are consistent with the CXX.2 and CXX.4 Notes.
- CODE.3, .4, .5, .10, .11 and .12 and DOCS.5, .6 and .9 raise no conflict beyond the points above.
- CXX.8's "No dynamic allocation" row does connect CXX.24 row 1 to STL-first.
- CLASS.17, .18 and .19 raise no conflict beyond S18.

**Verdict: not ready to ratify as 0.1. The 320 harness pairs are clean (312 compatible, 8 minor), but three defects need correction first: D1 CXX.10 against NUMER.27, D2 the CXX.24 row 6 contradictions, and D3 C++17 at CSQ1/0 against the standard's own idioms. The should-fix items S4 to S8 and S17 to S19, which concern PRIME.4, mixed classes, promotion and tooling, should also go in before adoption.**

Memory notes for the main session: none needed.
