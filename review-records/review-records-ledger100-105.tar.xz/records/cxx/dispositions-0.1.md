# Dispositions of the reviews of STND.CXX draft 0.1

Draft 0.2 renumbers the provisions. Old numbers in the findings map to the new ones as follows. 1→1, 2→2 (and the new 3), 3→5 (and the new 6), 4→7, 5→8, 6→9, 7→10, 8→11, 9→14, 10→13, 11→14 and 15, 12→16, 13→17, 14→18, 15→19, 16→22, 17→25, 18→26, 19→28, 20→29, 21→30, 22→31, 23→32, 24→33.

These provisions are new in 0.2:

- 3, Edition review (version rules)
- 4, Agent edition changes (binding, GOV.48)
- 6, Floating-point build options
- 12, Implementation-defined library behavior
- 20, Checks no option removes (binding)
- 21, Failure channel
- 23, Status of foreign calls
- 24, Release failures
- 27, Compiler assumptions

## Cold review

| Finding | Disposition |
| --- | --- |
| D1 NASA claim | Applied. The Notes say the research found no NASA-owned C++ standard, and that the Handbook names a GSFC C++ flight-software standard that was not retrieved. It is listed as open. |
| D2 Class onset | Applied. The onset paragraph names CXX.9, CXX.10, CXX.3, CXX.23, and CXX.25 (DSGN.4 and DSGN.5 at CSQ2), CXX.26 and CXX.29 (DSGN.15 at CSQ2), CXX.30 (DSGN.2 at CSQ1), and CXX.31, CXX.32, and CXX.33 (DSGN.3 at CSQ0), each tightening under PRIME.15. The Notes state that conformance is a mechanical check against undefined behavior and is not VV.1 evidence. CXX.31 and CXX.32 no longer instantiate VV.1. |
| D3 CXX.16 statement | Applied in CXX.22: "before each other operation that is able to fail". A factory example is in the Notes. |
| D4 CXX.17 error-less interfaces | Applied in CXX.25. A stored object is checked after the invocation returns. `bugprone-exception-escape` is in the Notes. |
| D5 Example column | Applied. The examples moved to the Notes. The macro row no longer conflicts with CXX.33, whose preprocessor row admits the one assertion macro. |
| D6 CXX.2 conditions | Applied. The rule is "documentation states complete support". The later-feature allowance is its own sentence. Review is the new CXX.3. |
| S7 C++17 idioms | Applied. CXX.14 has a C++17 form (static assertions on named traits). CXX.9 says "view or range", with the C++17 view types in the Notes. The other Notes examples are tied to their editions. The claim about compiler and analyzer coverage is replaced by "MISRA targets C++17". |
| S8a Scope of conformance | Applied in part. The term "High-assurance code" excludes tests, development tools, and incorporated external code, which STND.DEPS and DSGN.5 govern. Declined for generated code and for dialects the analyzer does not parse: they ship in the released code, and a project records a deviation for them instead. |
| S8b Licensing and agents | Applied in the Notes. |
| S8c No-analyzer fallback | Applied in CXX.31: the record of the change names each analyzer, or the absence of one. The Notes say this does not block the work. |
| S8d MISRA Compliance:2020 | Applied in the Notes, marked unconfirmed. |
| S8 DRAFT.42 | Applied in the Notes. |
| S9 Scope to safety-related components | Applied through the term "High-assurance code". The title is now "Safety-related code restrictions". |
| S10 Name the rule set | Applied. CXX.31 adopts MISRA C++:2023 "or the high-assurance rule set that a decision record names in its place". |
| S11 CXX.24 table | Applied: rule-origin claims, loop exemption and maximum, allocation definition and pmr upstream, safe state on assertion failure, checkable exception row, preprocessor exemptions, and Power of 10 rules 4 and 9. Rule 9 is stated as one level of dereference only; the ban on function pointers is not adopted, because virtual dispatch and callbacks to foreign interfaces need them. |
| S12 CXX.15 scope | Applied in CXX.19: "a failure of a kind that PRIME.4 lists", diagnosed by the compiler or a static check, with `[[nodiscard]]` in the Notes. The transition sentence now says the binding provisions follow the recorded transition period. |
| S13 Failure channel | Applied as the new CXX.21. Destructor reporting is in the new CXX.24. |
| S14 Narrowed directions | Applied. The Notes state both departures with reasons. Explicit instantiation is now a measured optimization (RSRC.4) that keeps the definitions visible. Non-template code is header-only unless it wraps a foreign interface or holds process state. |
| S15 Header-only level and extensions | Applied in CXX.5 (extension exemption for foreign interfaces) and CXX.6 (minimum edition and options of a header library). |
| S16 `gsl::owner` matching | Applied. CXX.7 asks for a type that the checks recognize. The Notes mark the alias question as unconfirmed. |
| S17 CXX.1 | Applied. |
| S18 Reproducibility | Applied: the new CXX.12 and CXX.6, with contraction defaults and finite-math in the Notes (marked unverified) and in CXX.20. |
| S19 Sanitizers | Applied. CXX.29 fails the test at the first detection. The flags, extra groups, and Archer requirement are in the Notes. |
| S20 Metaprogramming term | Applied. |
| S21 Interrupt and signal handlers | Applied in CXX.26. |
| S22 Prose and Notes | Applied: "most", the scope statement for the models, drafting-stage text removed, an affirmative recommendation of metaprogramming (CXX.15 sentence 1), sources grouped with the dated facts, "offers" removed, section headings renamed. |
| O23 Unverified claims | Applied. Claims are marked unverified. The C++ frames wording is now "unspecified". |
| O24 Naming | Applied: a type-alias row, rows extending the direction stated as such with a reason, and the term tightened. |
| O25 View or range; kernel | Applied in CXX.9. |
| O26 Hardening uniformity and other options | Applied in the Notes. |
| O27 Lexicon collisions | Applied: "Core Guidelines reference", "C++ exception", "owned resource", "deviation". |
| O28 SEI CERT | Applied. The Notes say it is not required, and why. |
| O29 Core Guidelines coverage pointers | Applied in the Notes. |

## Pair review

| Finding | Disposition |
| --- | --- |
| D1 CXX.10 against NUMER.27 | Applied. CXX.13 keeps definitions in headers and makes explicit instantiation a measured optimization with extern template declarations. CXX.14 cites NUMER.27 as a present need. |
| D2 Preprocessor row | Applied in CXX.33. Hardening macros are set on the command line (Notes). |
| D3 C++17 against idioms | Applied, as cold S7. Concepts are listed first among the candidate features in the Notes. |
| S4 Mixed classes | Applied through the term "High-assurance code" and the Notes. A shared header takes the most severe class it is compiled into. Tests, tools, and external code are excluded. |
| S5 Removable checks | Applied as the new binding CXX.20, which covers STND.CODE.6, CPS.5, and CPS.9. The mechanisms it excludes are named in the Notes. The diagnostic quality of libc++ fast mode is in the Notes, marked unverified. |
| S6 Fast-math and header flags | Applied: CXX.6, the second sentence of CXX.20, and the Notes on flush-to-zero (unverified). |
| S7 CXX.17 error-less interfaces | Applied, as cold D4. |
| S8 Release hides failure | Applied as the new CXX.24, with STND.CODE.7 and STND.CODE.12 cited correctly. It is a SHOULD rather than the proposed SHALL, because a default that covers every release failure goes beyond PRIME.4's list. |
| S9 CXX.15 forms | Applied: the PRIME.4 scope, void casts and `std::ignore` (Notes), foreign status wrapped by the new CXX.23. |
| S10 CXX.18 scope | Applied in CXX.26, with the atomics row in the CXX.11 table. |
| S11 Assertion failure response | Applied in the CXX.33 table and the Notes. |
| S12 Loop bound and non-convergence | Applied in the CXX.33 table. |
| S13 Reason rows | Applied: rows for reproducibility, high-assurance restriction, and synthesis subset. |
| S14 Toolchain matrix | Applied. The term is per unit, used the same way in CXX.2, CXX.5, and CXX.32. Review at STND.DEPS.4 and verification of a change are in CXX.3. |
| S15 Overbroad term | Applied, as cold S20. |
| S16 Examples and tautology | Applied in CXX.16: the example is one of the static assertions, the expected result comes from the requirement, and floating-point results use a NUMER.11 tolerance. |
| S17 Transition and GOV.14 | Applied in the Notes and in the rationale. |
| S18 Tooling and agents | Applied in the Notes: provisioning by the human owner, absence recorded, rule text, deferral to release under STND.WPROC.9, and the STND.DEPS.9 record. "Before its release" is in CXX.31. |
| S19 Requirements only in the Notes | Applied. Precedence is in CXX.1, destructors in CXX.24, removable checks in CXX.20. The register pattern and `observer_ptr` stay informative. |
| O20 Onset | Applied, as cold D2. |
| O21 Terms | Applied: Safety-related component imported, Owned resource defined, "deviation" used. |
| O22 CXX.1 sentence 2 | Applied (deleted). |
| O23 FP environment guard | Applied in the Notes. Declined for the behavior of new threads, which the research did not confirm. |
| O24 Assumption attributes | Applied as the new CXX.27. |
| O25 Naming flips; comment boilerplate | Applied: the Notes cover naming flips, and CXX.18 exempts arguments borrowed only for the call. |
| O26 HLS scope | Applied in the Notes and the synthesis-subset row. |
| O27 Register access | Applied in the Notes: the `extern volatile` object, the deviation, and the place of the CPS.5 check. |
| O28 Floor wording | Applied: "none asks for evidence or documentation, so none raises the floor". |
| O29 CXX.4 and CXX.16 overlap | Applied. CXX.7 cites CXX.22 for the wrapper. |
| O30 MISRA overlap claim | Applied (reworded). |
| O31 Release marker | Applied. CXX.31 asks for one deviation marker that the repository configuration names. |

## Brief decisions

- 1: CXX.4 is the agent-only binding provision.
- 2: CXX.19 and CXX.20 stay within PRIME.4's list.
- 7: CXX.17 and the Notes.
- 8: CXX.2 and CXX.3.
- 9 to 11: the Notes and the headings.
- 3 to 6 apply to PY and JL. CXX.12 covers library random distributions.

## Counts

- Applied: 66 findings, 6 of them in part.
- Declined in part, with the reasons above:
  - cold S8a, for generated code and unparsed dialects;
  - cold S11, for the function-pointer half of rule 9;
  - pair S8, SHOULD in place of SHALL;
  - pair O23, the behavior of new threads.
- Remaining harness findings after revision:
  - 10 three-modal bundles: CXX.3, 7, 14, 16, 21, 22, 25, 26, 31, 33. Each is confirmed as applied together.
  - The number in "MISRA C++:2023", which is the name of the rule set.
