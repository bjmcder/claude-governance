# STND.HARN.28 pair review: STND.ANNEX 1.0 (2026-10-23)

Pairs by other document: HW 82; sub-profiles 55 (CPU 9, EMBED 13, FPGA 9, ASIC 9, QPU 15); HDES 154 (HDES 76, ASIC 58, FPGA 20); NUMER 66; CPS 32; ML 12; AGENT 3. No pair names MEAS, STND.VVUQ, STND.DFLT, or HW.GPU. I read all 67 distinct other-side provisions in full and judged each pair against its ANNEX provision. Read closely: 389 (all HW, sub-profile, HDES, NUMER, CPS). Sampled: 15 (ML, AGENT), all read, no interaction.
## Findings

### Defect

None. Each gap below leaves the HW provision binding where the default is silent (GOV.23).

### Should-fix

1. **ANNEX.8 × HW.EMBED.4, CPS.4.** HW.EMBED.4 has the hardware contract state each output's state at power-on, reset, halt, and stall, and CPS.4 rests the safe-state verification on those states. ANNEX.8 has no row for them and its Stated column says "Nothing". That falsifies the Note's claim that citation plus the column give everything HW.4 and HW.5 ask. Fix: add the row "Outputs at reset and halt", Stated column: "For each output commanding, configuring, or powering physical hardware, its states and evidence as HW.EMBED.4 asks".
2. **ANNEX.5 × HW.5, HW.CPU.3, NUMER.5.** Rounding and subnormal handling are given as "what the control state sets at the start of a process", but the value is never stated. HW.CPU.3 then has nothing to confirm against, and NUMER.5 nothing to record. Fix: add to the Stated column "The rounding and the handling of subnormal values that the floating-point control state sets at the start of a process".
3. **ANNEX.7 × HW.5, HW.12.** Classical operations take ANNEX.5's arithmetic, but not its Stated-column items (number formats, build settings) or its variation in order of combination. Fix: add to the Stated column "for its classical operations, each item that STND.ANNEX.5 leaves to the citing contract", and add the ANNEX.5 variation for those operations to the variation row.
4. **ANNEX.9/10 × HDES.10, HW.4.** "None relied upon at an operating condition … stated as not analyzed" is false for synchronous logic, and read as a limit it would block use there. Fix: "not established at each operating condition that the record of that analysis states as not analyzed".
5. **ANNEX.9/10 × HDES.5, HDES.7.** The arithmetic row cites HDES.7 only, which covers only operations that approximate a real-valued computation. Integer wrap-around and non-finite handling sit under HDES.5. Fix: "under HDES.5 and HDES.7"; the Notes already name HDES.5.
6. **ANNEX.2/5/6/8 × HW.4.** HW.4 asks for limits "on capacity, timing, or power", but the Stated column asks only for "each other capacity", so a watchdog period or offload timeout is missed. Fix: "Each other limit on capacity, timing, or power that the component is able to reach in its regime of use".
7. **ANNEX.3 × HW.4; ANNEX.9/10 × HW.10 (class cost).** HW applies HW.4 from CSQ2, and its _doc notes HW.10 is idle at CSQ3. A citing contract at CSQ3 states undetected faults, which engages HW.10. It also carries HW.4-only content: ANNEX.2's capacity items, ANNEX.8's response, and ANNEX.3 sentence 2, which rests on DSGN.5 and HW.4 alone. So the Note "at no cost beyond the citation" is wrong. This raises no floor, since citing is opt-in. Fix: reword the Note to state that cost.
8. **ANNEX.9/10 × HW.12.** The variation rows leave out choices made at run time. Fix: add "and the configurations that the path loads during a run" in ANNEX.9, and "and the choices at run time that the design record states" in ANNEX.10.
9. **ANNEX.7 × HW.QPU.5 (outside the list).** The default says "no noise model relied upon beyond those error rates", yet it admits provider error mitigation, which rests on assumptions about device noise. Fix: add to the Stated column "The noise assumptions of each error mitigation applied, as HW.QPU.5 states them".

### Optional

10. **Notes on HW.8.** The defaults choose halt, one of the three responses HW.8 allows, so "restates an obligation that already binds" overstates. Also read "with an actionable diagnosis that includes what the platform reports".
11. **ANNEX.5/6/8, "every other kind: undetected".** List the kinds in HW's Term Hardware fault. HW.4 asks for each kind, and HW.10 needs a means able to detect each one.
12. **ANNEX.9/10 × HDES.15.** Write "detection or correction" in the upset rows.
13. **ANNEX.9 × HW.FPGA.4.** In the Evidence row, add "in each part of the regime of use that the evidence does not cover".
14. **ANNEX.10 × HDES.ASIC.12, sentence 3.** Mark a property whose only evidence is a realization in programmable logic until HW.ASIC.4 measurement supports it.
15. **ANNEX.8 × CPS.8.** "No other timing; no accuracy or drift of a clock" contradicts each loop's stated period. Add to the Stated column "Each period, latency, and clock accuracy on which the component relies".
16. **ANNEX.4 sentence 1 × HW.6.** It restates HW.6, and is harmless as a guard.
17. **Pairing gaps (not an ANNEX fault).** Pairing by shared basis misses ANNEX.6 × HW.GPU.3 (checked: consistent), ANNEX.5–8 × HW.10, ANNEX.7 × HW.QPU.5, and ANNEX.8 × HW.EMBED.6 (checked: consistent).

Not checked: the rank and waivability closures, which are left to `verify`.

## Verdict

There is no conflict or wrong precedence. The nine should-fix gaps sit in the Stated columns (1, 2, 3, 6) and the HDES-based rows (4, 5, 8). Each is a wording fix that keeps the defaults agnostic and raises no floor. Adopt after the should-fix edits; the optional items can go to 1.1.

Pairs read: 404 (389 closely, 15 sampled). Pairs with findings: 30 listed pairs (finding 9 and part of 17 fall outside the list).
