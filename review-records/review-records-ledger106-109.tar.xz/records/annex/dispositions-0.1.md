# Dispositions of the reviews of STND.ANNEX draft 0.1

Cold review: /home/claude/scratch-r6/review-cold-annex.md. Pair review: /home/claude/scratch-r6/review-pairs-annex.md. Draft 0.2: /home/claude/scratch-annex/draft.md.

## Cold review

| # | Class | Finding | Disposition |
| --- | --- | --- | --- |
| C1 | Defect | ANNEX.9 is empty when the project holds no design record | Fixed. ANNEX.9 gains a second sentence: for a configuration whose design record the project does not hold, each entry that rests on the design record is read as resting on the supplier's documentation, and each property that documentation does not state is not established. The Response row asks the citing contract for each response that neither source states. |
| C2 | Defect | References table lacks HDES.FPGA and CPS | Fixed. Configuration and Target model are now imported from HW.FPGA, which ANNEX.9 cites, so HDES.FPGA is no longer mentioned. The Notes cite CPS.4, and the derived table now lists CPS. The table also gained HW.EMBED from ANNEX.8. |
| C3 | Defect | Error-correcting memory is not simply "corrected" | Fixed in ANNEX.5 and .6: "corrected and detected within the capability that the documentation of the hardware model states for its error correction, and otherwise undetected"; the Notes explain miscorrection. |
| C4 | Should-fix | The citation does not name the annex revision | Fixed in ANNEX.1, which now instantiates REPRO.2. The Notes cover DSGN.6 and HW.7. |
| C5 | Should-fix | HW.4-only items apply from CSQ3 | Fixed. A Basis column is added to every table. ANNEX.2 covers the HW.5 and HW.12 rows from CSQ3. ANNEX.3 covers the HW.4 rows from CSQ2, instantiates only DSGN.5 and HW.4, and includes further reliance. The Notes onset is corrected. |
| C6 | Should-fix | Undocumented accuracy; ANNEX.8 lacks elementary functions and contraction | Fixed: "and otherwise not established" in .5, .6, and .8; .8 gains fused and contracted operations and elementary functions. |
| C7 | Should-fix | "Correctly rounded" is not general | Fixed: "in each format for which the processor documents correct rounding, and otherwise to the accuracy that its documentation states". The Stated column gains reduced-precision and matrix instruction modes. |
| C8 | Should-fix | Hardware threads are not a capacity | Fixed: dropped from the ANNEX.5 Limits row. |
| C9 | Should-fix | ANNEX.8 gaps: output states, language memory model, clock | Fixed. A new row "Outputs at reset and halt" (HW.EMBED.4) is added. The language memory model now covers the firmware and its interrupt handlers. Timing takes the documented accuracy of each clock source, and its Stated column asks for each clock source, period, and latency. |
| C10 | Should-fix | ANNEX.7 arithmetic Stated items; noise model versus mitigation | Fixed. The Stated column takes the ANNEX.5 Stated items for classical operations. The noise row adds the assumptions that the record of HW.QPU.5 states for the mitigation in force. |
| C11 | Should-fix | ANNEX.10 lacks analog behavior and test escapes; variation omits noise and unset state | Fixed. ANNEX.10 gains the row "Analog and mixed-signal behavior" (HDES.5, corners of HDES.ASIC.5), and defects that HDES.ASIC.11 leaves undetected are listed as undetected. Variation rows gain unset state elements (HDES.12) in .9 and .10, block noise in .10, and analog noise in .6. |
| C12 | Should-fix | Soft processor firmware arithmetic is unstated | Fixed in the ANNEX.9 arithmetic Stated column, which points to ANNEX.8's items. The Notes are aligned. |
| C13 | Should-fix | Notes narration, HW.8 wording, accelerator clause | Fixed. The narration and the custodian paragraph are removed. The Notes now say that the defaults "select a halt ... among the responses that HW.8 allows". The accelerator clause is replaced by a description of the table. |
| C14 | Optional | Purpose cites GOV.18 for agnosticism | Fixed: Purpose now says the choices are left to each project's instruments (GOV.18), which is what GOV.18 says. |
| C15 | Optional | Import Error mitigation and Fabrication readiness record | Fixed. Corner and Manufacturing test are also imported. |
| C16 | Optional | DRAFT.19 ancestors | Fixed: .1 adds REPRO.2 and .4 adds DSGN.5. |
| C17 | Optional | "beyond what that measurement shows" | Fixed: "beyond the spread that HW.ASIC.4 records". |
| C18 | Optional | Allow resubmission | Fixed in .6 and .7: resubmission stated under HW.9 as a visible degradation. |
| C19 | Optional | Rationale lists only some referred IDs | Fixed: the rationale lists every referred ID. |

## Pair review

| # | Class | Finding | Disposition |
| --- | --- | --- | --- |
| P1 | Should-fix | ANNEX.8 × HW.EMBED.4, CPS.4 | Fixed, as C9. |
| P2 | Should-fix | ANNEX.5: initial control state never stated | Fixed: the Stated column adds the rounding and subnormal handling that the control state sets at the start of a process. |
| P3 | Should-fix | ANNEX.7: classical Stated items and variation | Fixed: Stated items as in C10; the variation row adds the ANNEX.5 variation for classical operations. |
| P4 | Should-fix | "None relied upon" at conditions not analyzed | Fixed in .9 and .10: "not established at each operating condition that the record of that analysis states as not analyzed". |
| P5 | Should-fix | Arithmetic row cites HDES.7 only | Fixed: "under HDES.5 and HDES.7". |
| P6 | Should-fix | "Each other capacity" misses timing and power | Fixed in .5 to .8: "Each other limit on capacity, timing, or power that the component is able to reach in its regime of use". |
| P7 | Should-fix | Note on cost at CSQ3 | Fixed. The split moves HW.4-row statements to CSQ2 (C5). The Notes state the HW.10 cost that a citing contract carries at CSQ3. |
| P8 | Should-fix | Variation rows omit run-time choices | Fixed: .9 adds configurations loaded during a run and .10 adds the run-time choices of the design record. |
| P9 | Should-fix | ANNEX.7 × HW.QPU.5 | Fixed, as C10. The assumptions sit in the default cell by reference to the record of HW.QPU.5, which already states them, so they are not stated twice. |
| P10 | Optional | HW.8 wording and diagnosis | Fixed: the Notes wording is changed as in C13, and the responses now read "an actionable diagnosis that includes what the platform reports". |
| P11 | Optional | List the kinds of fault | Fixed in .5, .6, and .8 from the Term Hardware fault, with loss of power treated by type. |
| P12 | Optional | "detection or correction" | Fixed in .9 and .10. |
| P13 | Optional | Evidence row coverage | Fixed in .9: "in each part of the regime of use that evidence under HW.FPGA.4 ... does not cover". |
| P14 | Optional | Programmable-logic-only evidence for an ASIC | Fixed in the .10 Evidence row. |
| P15 | Optional | ANNEX.8 × CPS.8 | Fixed, as C9. |
| P16 | Optional | ANNEX.4 sentence 1 restates HW.6 | Declined. The reviewer calls it harmless as a guard, and it keeps the citation from being read as evidence. |
| P17 | Optional | Pairing gaps | No change. The reviewer marks this as not an ANNEX fault, and the pairs it names were checked as consistent. |

## Rehearsal-only finding

| # | Finding | Disposition |
| --- | --- | --- |
| R1 | g.18 review: ANNEX.3 carried three modals after the split | Fixed: the item statement and the departure statement were merged into one sentence, so ANNEX.3 now carries two modals. |

## Verification of 0.2

Verifier: /home/claude/scratch-r6/verify-annex.md. Draft 0.3: /home/claude/scratch-annex/draft.md.

| # | Class | Finding | Disposition |
| --- | --- | --- | --- |
| V1 | Defect | ANNEX.9: supplier configuration leaves limits and fault kinds "not established" | Fixed. In the Hardware faults row, every other kind reads "as the design record states under HDES.5, and otherwise undetected", in .9 and also in .10. The Limits row's Stated column asks for each reachable limit on capacity, timing, or power that the supplier's documentation does not state. |
| V2 | Defect | ANNEX.8 "Outputs at reset and halt" has CSQ2 onset under HW.4 | Fixed. The row's Basis is now HW.EMBED.4. ANNEX.2 covers rows of basis HW.5, HW.12, or HW.EMBED.4, and instantiates HW.EMBED.4 and VV.1. It stays a default and applies from CSQ3. |
| V3 | Should-fix | Further reliance on arithmetic is lost at CSQ3 | Fixed. ANNEX.2 gains a sentence for reliance on delivered arithmetic or run-to-run variation, and its two earlier sentences were merged, so it still has two modals. The Notes are updated. |
| V4 | Should-fix | Soft-processor firmware lacks ANNEX.8's default arithmetic | Fixed. The ANNEX.9 arithmetic Default cell takes ANNEX.8's delivered arithmetic for that firmware, and the variation row takes ANNEX.8's variation. |
| V5 | Should-fix | ANNEX.6 resubmission may reuse corrupted state | Fixed: "submits the offloaded work again from inputs that the fault leaves unaffected". |
| V6 | Should-fix | Missing "otherwise not established" fallbacks | Fixed in three places: the ANNEX.6 subnormal and non-finite clause, the ANNEX.8 rounding, subnormal, and non-finite clause, and the ANNEX.8 clock accuracy clause. |
| V7 | Optional | Purpose cites GOV.18 for agnosticism | Fixed. The Purpose now cites the custodian's direction for agnosticism, and cites GOV.18 only for leaving the choices to LVL3, one of the levels at which GOV.18 places them. |
| V8 | Optional | HW.6 rows fall under neither ANNEX.2 nor ANNEX.3 | Fixed: a Notes sentence says those rows ask nothing beyond HW.6, HW.FPGA.4, and HW.ASIC.4. |
| V9 | Optional | "renewed as HW.7 asks" | Fixed: now reads HW.6. |
| V10 | Optional | ANNEX.3 sentence 1 attachment | Fixed: the differing-property object comes first, followed by "in place of that default". ANNEX.2 has the same order. |
| V11 | Optional | ANNEX.2 title | Fixed: "Arithmetic, variation, and output statements", because the provision now also covers the HW.EMBED.4 row. |
