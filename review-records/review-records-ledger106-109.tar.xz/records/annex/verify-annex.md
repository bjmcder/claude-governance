# Cold verification: STND.ANNEX draft 0.2 (2026-10-23)

Read: the reading copy, the ten provision files, `apply_annex.py`, both reviews, and the dispositions. I checked them against HW, its sub-profiles and their onset notes, HDES, HDES.ASIC, CPS.4/8, GOV.18, DSGN.6, CLASS.10, and the DRAFT rules. Scans pass: no excluded words; at most two modals per provision; body IDs equal instantiates ∪ refers_to; titles are short and unique. The closure (DSGN.5, REPRO.2/3, VV.1, HW.4/5/6/12) makes all ten provisions defaults. The Notes are clean. I did not rerun `verify`; I relied on verify.log (PASS).

## Findings

### Defect

1. **ANNEX.9 sentence 2 and the Limits and Hardware faults rows (new; C1 only partly fixed).** For a supplier's configuration, an undocumented limit or fault kind now reads "not established", and the Stated column asks nothing. HW.4 sentences 2 and 3 do not accept that answer: they need each reachable limit and whether each fault kind is detected. An unknown fault kind also escapes HW.10, which fires only on "undetected"; ANNEX.5, .6, and .8 default unknown kinds to undetected. *Fix:* Hardware faults: "every other kind: as the design record states under HDES.5, and otherwise undetected". Limits, Stated column: "For a configuration whose design record the project does not hold, each limit on capacity, timing, or power reachable in its regime of use that the documentation of its supplier does not state".
2. **ANNEX.8 row "Outputs at reset and halt" has the wrong class onset (new).** With Basis HW.4, ANNEX.3 completes it, and ANNEX.3 applies only from CSQ2. HW.EMBED.4 applies from CSQ3, so at CSQ3 the cited default says "Not established" for output states that HW.EMBED.4 requires and CPS.4 rests on. *Fix:* set the Basis to HW.EMBED.4, and add "or HW.EMBED.4" to the row selection of ANNEX.2, citing HW.EMBED.4 there. Its closure (DSGN.5, VV.1) keeps ANNEX.2 a default from CSQ3.

### Should-fix

3. **Further reliance is lost at CSQ3 (new, from the C5 split).** The reliance sentence applied from CSQ3 in 0.1, but ANNEX.3 now applies from CSQ2. At CSQ3 the annex no longer asks for reliance on an arithmetic property that the default marks "not established". HW.5 still binds, so nothing is relaxed, but the Notes cite only ANNEX.3. *Fix:* give ANNEX.2 a third sentence for HW.5 and HW.12 rows (bundle review under g.18). Alternatively, have the Notes state that at CSQ3, HW.5 governs that reliance directly.
4. **ANNEX.9 soft-processor firmware (C12 partly fixed).** ANNEX.9 imports only ANNEX.8's Stated items, not its default arithmetic: compiler-documented rounding, software floating point, and elementary functions. HDES.7 does not cover those. *Fix:* as ANNEX.7 does, put "for firmware that a processor realized in the configuration runs, the delivered arithmetic of the default contract of STND.ANNEX.8" in the Default cell, and its interrupt-timing variation in the variation row.
5. **ANNEX.6 resubmission (new, from C18).** Resubmission after a memory error or reset can reuse corrupted device state. *Fix:* "submits the offloaded work again from inputs that the fault leaves unaffected".
6. **Fallbacks the Notes promise are missing (C6 partly fixed).** The Notes say "No default leaves a matter empty". But "and otherwise not established" is absent from the ANNEX.6 subnormal/non-finite clause, the ANNEX.8 rounding/subnormal/non-finite clause, and the ANNEX.8 clock-accuracy clause. *Fix:* append "and otherwise not established" to each.

### Optional

7. **Purpose (C14 partly fixed):** GOV.18 places these choices at LVL2 and LVL3, not with projects. *Fix:* cite the custodian's ruling.
8. **Basis HW.6 rows** (Evidence, .9/.10) fall under neither ANNEX.2 nor ANNEX.3. *Fix:* a Notes sentence saying HW.6, HW.FPGA.4, and HW.ASIC.4 bind them.
9. **Notes:** "renewed as HW.7 asks" should read "HW.6", since HW.7 concerns hardware identity.
10. **ANNEX.3 sentence 1:** "in place of that default" attaches to both objects. *Fix:* put the differing-property object first.
11. **ANNEX.2 title:** it also covers the variation rows. *Fix:* "Arithmetic and variation statements".

## Prior findings

| Finding | Status |
| --- | --- |
| C1 | Partly (finding 1) |
| C2 | Resolved (DRAFT.34 met as written) |
| C3, C4, C7, C8, C10, C11, C13, C15–C17, C19 | Resolved |
| C5 | Resolved, but it introduced findings 2 and 3 |
| C6 | Partly (finding 6) |
| C9 | Resolved, except the clock fallback (finding 6) |
| C12 | Partly (finding 4) |
| C14 | Partly (finding 7) |
| C18 | Resolved, with finding 5 |
| P1–P15 | Resolved (P9 soundly by reference to the HW.QPU.5 record) |
| P16, P17 | Soundly declined or left |
| R1 | Resolved (two modals) |

## Verdict

Most prior findings are resolved; the defaults stay agnostic and non-binding, raise no floor, and limit no performance. Not ready: fix Defects 1 and 2, which arise from the C1 and C5 fixes, together with Should-fix 3 to 6, before adoption. The Optional items can go to 1.1.
