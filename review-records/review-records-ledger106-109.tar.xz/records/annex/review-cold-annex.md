# Cold review: STND.ANNEX 1.0 (ledger 106 rehearsal)

Read: the reading copy, the provision frontmatter, `apply_annex.py`, HW 1.1 and its six sub-profiles, HDES with HDES.FPGA and HDES.ASIC, GOV.11/18/19/42, DSGN.5/6, STND.CLASS.10, and STND.DRAFT.12/19/24/34. Scans are clean: no excluded words, at most two modals per provision, and body IDs equal instantiates ∪ refers_to. The closure reaches only DSGN.5, REPRO.2, REPRO.3, and VV.1, so marking all provisions as defaults is correct. Not checked: the STND.HARN.28 pairs, and a rerun of `verify`.

## Findings

### Defect

1. **ANNEX.9: no source without a project-held design record.** HW.FPGA.3 allows configurations whose design record the project does not hold, and HDES does not bind such work. Then each "As the design record states" row has nothing behind it, and every Stated-by cell is "Nothing". The citation would discharge HW.4 and HW.5 empty (PRIME.15). *Fix:* add "or, where the project holds no design record, as the supplier's documentation states, and otherwise not established". Alternatively, limit the scope.
2. **References (DRAFT.34).** HDES.FPGA (cited in Terms) and CPS (cited in Notes) are missing. *Fix:* add both.
3. **ANNEX.5 and .6 Hardware faults: ECC memory is not simply "corrected".** Error-correcting codes correct only within their capability, and larger errors are miscorrected or missed. The row hides that exposure from HW.10. *Fix:* "corrected and detected within the capability its documentation states, and otherwise undetected".

### Should-fix

4. **ANNEX.1: name the revision.** A revision of the annex silently changes every citing contract, against DSGN.6 and HW.7. *Fix:* "by a citation of that default contract and the revision of this standard".
5. **ANNEX.2 and class onset.** ANNEX.2 applies from CSQ3 through HW.5 → REPRO.2. Yet it also demands the HW.4-only items, "each other capacity" and (.8) the fault response, which apply from CSQ2. So the Notes' "no cost beyond the citation" at CSQ3 is false. *Fix:* split off the HW.4-only items into a provision that instantiates DSGN.5 and HW.4 only, then correct the Notes.
6. **Undocumented accuracy (.5, .6, .8).** "To the accuracy their library documents" is empty where nothing is documented. *Fix:* add "or, where none is documented, not established". ANNEX.8 also lacks the elementary-function and contraction items that HW's term Delivered arithmetic includes.
7. **ANNEX.5: "correctly rounded" is not general.** It is untrue for the reduced-precision and matrix instructions of some processors. *Fix:* "in each format for which the processor documents correct rounding", and add those modes to Stated-by, as in ANNEX.6.
8. **ANNEX.5 Limits: hardware threads are not a capacity.** The row lists hardware threads beside capacities ("each *other* capacity"), but HW's term Capacity excludes limits that only slow execution. Read as a capacity, oversubscription would invoke the HW.8 halt rather than the HW.CPU.5 report. *Fix:* drop hardware threads.
9. **ANNEX.8 gaps.**
   - The Stated-by column lacks the output states of HW.EMBED.4.
   - Memory and ordering lacks the language memory model that HW.11 uses for interrupt handlers.
   - "No accuracy or drift of a clock relied upon" is untrue of most data-acquisition firmware. *Fix:* state the accuracy that the documentation gives for the clock source, and put the clock source in Stated-by.
10. **ANNEX.7 inconsistencies.**
    - It imports the ANNEX.5 default but not its Stated-by items (number formats, build settings). *Fix:* add them.
    - "No noise model relied upon beyond those error rates" contradicts the provider error mitigation that the same table admits (HW.QPU.5). *Fix:* append "and the assumptions that HW.QPU.5 states for the mitigation in force".
11. **ANNEX.10 and mixed-signal designs.**
    - No row covers analog or mixed-signal block behavior (HDES.ASIC.5). *Fix:* add "Analog and mixed-signal behavior: as the design record states under HDES.5 at each corner of HDES.ASIC.5".
    - No row covers defects that escape the manufacturing test (HDES.ASIC.11). *Fix:* list them as undetected.
    - Run-to-run variation in .6, .9, and .10 omits device noise and the state elements that HDES.12 leaves unset. HW counts analog accelerators as accelerators, so .6 needs this too.
12. **Notes on soft processors.** Firmware on a processor realized in programmable logic cites ANNEX.9. That leaves its compiler and build arithmetic unstated, because HDES.7 covers only the design's own operations. *Fix:* also have that firmware state the ANNEX.8 Stated-by items.
13. **Notes wording.**
    - Remove the drafting narration: "…are given here", "Following the custodian's direction", and the paragraph "The custodian directed…".
    - "Each response restates an obligation that already binds" is inexact, because halt narrows HW.8's three options. *Fix:* "selects halt among the responses HW.8 allows".
    - The accelerator paragraph says correct rounding needs a departure, but the table already takes the documented accuracy. *Fix:* delete the clause.

### Optional

14. **Purpose:** cites GOV.18 for agnosticism, but GOV.18 places those choices at LVL2. Cite the custodian's ruling instead.
15. **Terms:** import Error mitigation (HW.QPU) and Fabrication readiness record (HDES.ASIC).
16. **DRAFT.19:** ANNEX.1 to .3 omit REPRO.2, and ANNEX.4 omits DSGN.5. The corpus is inconsistent here (24 of 463 LVL2 provisions).
17. **ANNEX.10:** "beyond what that measurement shows" is hard to check. *Fix:* "beyond the spread HW.ASIC.4 records".
18. **ANNEX.6 and .7:** allow resubmission recorded under HW.9 as a visible degradation, rather than halt only.
19. **Rationale:** "refers to HW.8 and HW.GPU.3" leaves out the other referred IDs.

## Verdict

The adoption rules (.1 to .4) are sound in form, and the binding/default analysis is correct. The defaults mostly tighten and do not limit performance. Not ready as rehearsed: fix 1 to 3, together with 4, 5, and 9, before adoption. The rest can follow in 1.1.
