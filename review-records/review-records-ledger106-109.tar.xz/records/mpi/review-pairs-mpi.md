# STND.HARN.28 pair review: STND.MPI (2026-10-23)

Scope: 226 pairs, read against `scratch-r6/governance`. I read closely all 106 whose other side is in HW, HW.CPU, HW.GPU, or NUMER. The list has no pair with STND.CODE, CXX, PY, JL, VVUQ, or DSGN (STND.HARN.28 needs a profile side; DSGN is LVL0), so I checked the Notes' citations of CODE.2, CODE.7, CXX.5, CXX.20, CXX.21, CXX.22, VVUQ.1, and VVUQ.2 by hand. Of the other 120, I sampled 21 (#1, 5, 6, 12, 16, 18, 21, 29, 53, 60, 77, 78, 86, 119, 120, 190, 193, 196, 199, 222, 224), with no finding. Every shared matter has an owner (HW hardware-contract or boundary-contract row, or NUMER tolerance-basis row).

## Findings

### Defect

None. No pair conflicts. Precedence is correct: STND.MPI.5 and .6 are binding on binding HW.8 and PRIME.4, and defaults on HW apply only where HW binds.

### Should-fix

1. **STND.MPI.6 vs HW.8 (#194): the survivors lose the safe-state option.** HW.8 and PRIME.4 allow three responses: halt, degrade visibly, or move to a designed safe state. STND.MPI.6 makes the halt end every other process unless that process "receives it as a reported error". A design that warns survivors by its own message and moves them to a safe state is only arguably compliant. This can conflict with CPS work (PRIME.13). Fix: replace "nor receives it as a reported error" with "nor receives notice of it and responds as PRIME.4 requires".
2. **STND.MPI.6 vs HW.8 (#194): the diagnosis record may raise the floor at CSQ4 (GOV.11).** "A record that the operator reads and that persists beyond the parallel execution" asks for more than HW.8's "actionable diagnosis". The Note's real reason is output that is lost because it was not flushed. Fix: "SHALL first complete the write of its diagnosis to where the operator reads it". Or keep it and justify persistence in the GOV.11 Note.
3. **STND.MPI.2 vs HW.3 (#72): placement is claimed in a Note but missing from the body.** The Notes say "the placement of processes, which the record of STND.MPI.2 holds", but the body lists only the number of processes and of nodes. Placement affects which collective algorithm runs. HW.CPU.4 records placement only while resource use is measured. Fix: add "the placement of processes on nodes" to the items in STND.MPI.2, or delete the claim from the Note.
4. **STND.MPI.19 and STND.MPI.24 vs STND.VVUQ.1 (not a listed pair): there is a gap at tier 1.** Tier 1 of VVUQ.1 admits no difference in "process and thread counts". A comparison across process counts therefore falls to tier 3, and STND.MPI.24's third sentence sends it there. A project that makes bitwise identity across process counts its acceptance criterion (STND.MPI.19) is never told to test that criterion. Fix: add a second sentence to STND.MPI.19 (two modals in total): "Each comparison between runs at different numbers of processes SHOULD then judge identical bits (VV.3)."

### Optional

5. **STND.MPI.14 vs HW.13 and HW.14 (#14, #15).** Neither side settles whether a message between processes on different hardware models of one execution path crosses a boundary under HW.13. The Note mentions HW.13 only for accelerator memory. Fix: add a Note sentence that a parallel execution spanning hardware models crosses an HW.13 boundary. Its datatype conversion enters that boundary contract through HW.13's second sentence.
6. **STND.MPI.2 vs HW.5 (#73).** When an implementation picks a collective algorithm at run time, it is choosing among implementations that differ in delivered arithmetic. HW.5's second sentence already asks for that range; STND.MPI.18 asks for it again. Fix: cite HW.5 in the GOV.31 Note paragraph, and let the size in STND.MPI.18 be given by reference to it.
7. **STND.MPI.19 vs NUMER.24 (#64).** In a stochastic method, random streams keyed to rank defeat identity across process counts even when reductions follow STND.MPI.19. Fix: add a Note sentence that identity across process counts also needs random streams keyed to the same process-count-independent blocks (STND.VVUQ.2, second sentence).
8. **STND.MPI.18 vs HW.12 (#49).** HW.12 and REPRO.3 cover variation "on identical recorded inputs". Once STND.MPI.2 records the process count, results at different process counts come from different inputs. Fix: add a Note sentence that the declaration also covers runs that differ only in the items of STND.MPI.2.
9. **STND.MPI.7 vs HW.CPU.5 (#221).** HW.CPU.5 counts threads against each path's affinity. It is unclear whether co-located processes with overlapping affinity masks count together. Fix: add a Note sentence that reads the run as all processes on a node, as the Note already does for HW.8. (My interpretation.)

No finding: STND.MPI.5 and .6 vs HW.GPU.3 (#192, #195); the DSGN.15 group vs HW.11; STND.MPI.22 vs HW.13 and HW.14; STND.MPI.24 vs NUMER.11, .25, .26, and HW.15 to HW.17. Every STND.CODE and STND.CXX citation in the Notes matches the cited text.

Not checked: the MPI facts the Notes mark unverified (no network). Outside scope: the brief says 0.1, but `STND/MPI/_doc.md` and the reading copy say revision 1.0; confirm the intended label.

## Verdict

STND.MPI passes the STND.HARN.28 pair review with no conflict and no unowned matter. Fix items 1 to 4 before adoption, or record them as accepted. Items 5 to 9 are optional Note clarifications.

Pairs read: 127 of 226 (106 closely, 21 sampled). Listed pairs with findings: 8 (#14, #15, #49, #64, #72, #73, #194, #221), plus 1 finding outside the list (STND.MPI.19/24 vs STND.VVUQ.1).
