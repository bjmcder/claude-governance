# Cold verification: STND.MPI draft 0.2 (rehearsed as 1.0, entry 108)

Read: the reading copy, the provision files, _doc, the dispositions, both reviews, the 0.1 content, and the cited upstream texts. A read-only script passed: modal counts, banned words, titles, body IDs, names, spelling. `verify` passes. [K] means checked against my knowledge only.

## Findings

### Defect

None.

### Should-fix

1. **STND.MPI.7 s2 "that it does"** (new). Now that s1 states two things, the antecedent is ambiguous. Fix: "Where that contract does not establish that such an end ends the other processes, ...".
2. **STND.MPI.6 s1 "through MPI or its message protocol".** This binding sentence excludes notice that arrives by another route, for example a signal from the launcher or a supervisor, which narrows PRIME.4's responses at CSQ4. Fix: delete the phrase and keep both routes in the Notes as examples.
3. **Notes, floor paragraph: "is put to the custodian for decision".** This is drafting narration, carried over from 0.1, and it becomes false on adoption. Fix: use the corpus form "the custodian ruled at ratification (date) that it raises no floor".
4. **STND.MPI.19 s2 vs STND.VVUQ.1.** VVUQ.1 tier 1 excludes a difference in process count, so VVUQ.1 still points to tier 3. The two defaults rank equally under GOV.5. Fix: a Note saying the acceptance criterion fixed under VV.3 governs, or propose that VVUQ.1 tier 1 admit process counts under a VVUQ.2 combination.
5. **STND.MPI.24 s1.** "At least three numbers of processes" still needs a decision record when a protocol admits fewer counts. Fix: "at least three numbers that its message protocol admits, or each where it admits fewer".

### Optional

6. Class Note: "The statement ... apply" should read "applies".
7. STND.MPI.10: change "each world model" to "the world model". In s2, also query whether it has been finalized [K].
8. HW.5 Note: change "gives the size" to "is the basis for the size".
9. HW.13 Note: "enters that boundary contract" should say "may enter", because HW.13 s2 is a MAY.
10. Abort Note: "ends them" conflicts with "best attempt (unverified)". Use "is meant to end them".
11. HW.CPU.4 and .5 reading: this is an interpretation of another standard (both are defaults). Mark it as this standard's reading.
12. STND.MPI.2 "MPI library" clashes with the defined term Library. Use "library of the MPI implementation".
13. `rc/mpi-0.1-draft.md` carries the adopted heading, not "draft 0.2". Only `/home/claude/scratch-mpi/draft.md` (entry 107) does, so the label disposition is inaccurate.

No finding on these:
- Self-communicator errors [K]
- Session abort (note 3.1)
- Point-to-point and collectives not interfering [K]
- Agnosticism
- STND.DRAFT.42
- The custodian's directions
- Class onset (.7 s3 at CSQ1; .12 s2 and s3 and the .7 contract at CSQ2)

Apart from finding 2, STND.MPI.5 and .6 ask only what PRIME.4 and HW.8 require.

## Prior findings

| Finding | Status | Finding | Status |
| --- | --- | --- | --- |
| C1 | Resolved | C14 | Resolved |
| C2 | Resolved (see 2) | C15 | Resolved |
| C3 | Resolved (see 1) | C16 | Resolved [K] |
| C4 | Resolved | C17 | Resolved |
| C5 | Resolved | C18 | No change, sound |
| C6 | Resolved | C19 | Resolved |
| C7 | Resolved | C20 | Declined, sound |
| C8 | Resolved | P1 | Resolved (see 2) |
| C9 | Resolved | P2 | Resolved |
| C10 | Resolved | P3 | Resolved |
| C11 | Resolved | P4 | Partly (see 4) |
| C12 | Resolved | P5 to P8 | Resolved |
| C13 | Partly (see 5) | P9 | Resolved |
| Label remark | Partly (see 13) | | |

Not resolved: none.

## Verdict

Both prior defects are resolved, and no new defect was found. After the one-sentence should-fixes 1 to 5, or a recorded acceptance of them, the standard is ready to ratify.
