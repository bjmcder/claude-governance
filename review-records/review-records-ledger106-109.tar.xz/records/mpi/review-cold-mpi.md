# Cold review: STND.MPI 0.1 (rehearsed as 1.0, entry 108)

Read: the reading copy, the 25 provision files, the _doc, apply_mpi.py, parallel-models.md, the cited LVL0/LVL1/HW/STND provisions, STND.CLASS.10, and STND.DOCS.9. Mechanical checks (read-only script) passed: body IDs equal instantiates ∪ refers_to; at most 3 modals, one per sentence; no banned body words; titles unique, at most 4 words, not verb-initial; no DOCS.9 patterns. The instantiates closure reaches PRIME only for .5 and .6, so the binding marks are right. I did not work through the 226 pairs. [K] means checked against my knowledge only.

## Findings

### Defect

1. **STND.MPI.6 s2 raises the floor.** "persists beyond the parallel execution" is INTPR.8, which STND.CLASS.10 applies from CSQ1. PRIME.4 asks only for an actionable diagnosis, and the floor argument leaves this cost out. Fix: "SHALL first write its diagnosis where the operator reads it (PRIME.4)". Move persistence into a default that instantiates INTPR.8 (in .7), at CSQ1.
2. **STND.MPI.6 s1 removes PRIME.4's alternatives.** Its only exemption is a process that "receives it as a reported error". Read narrowly, it forbids designed degradation: for example, a manager that learns of a halted worker through its own protocol and reassigns the work. A binding provision cannot be replaced, so at CSQ4 this tightens "halt, degrade visibly, or safe state" to "halt". Fix: "...nor receives notice of it, through MPI or its message protocol, and answers it as PRIME.4 requires".

### Should-fix

3. **Notes:** "The default fatal handler ... meets the first sentence of STND.MPI.5 with no code." The MPI standard does not require that handler to write a diagnosis, and abort is only "best attempt" [K]. Mark the claim unverified. Have the .7 contract state whether the fatal handler writes one.
4. **STND.MPI.4 s1:** since MPI-4, errors that belong to no object are raised on the self communicator [K]. Fix: "...each predefined communicator that it uses or on which MPI raises errors that belong to no object".
5. **STND.MPI.2:** the Notes say the record holds "the placement of processes", but the body does not. The research note (6.3) also asks for the ABI choice. Add the placement of processes on nodes and the MPI library loaded at run time.
6. **STND.MPI.11 s3** ("received from another component") conflicts with s1 when ownership passes, for example a returned new communicator. Fix: "...that another component owns", which matches STND.CXX.20.
7. **STND.MPI.10 s1** discourages a library from opening its own session, which is what sessions exist for [K]. Fix: exempt a session that the library initializes and finalizes itself.
8. **STND.MPI.17:** it is unclear whether "collective operations" covers calls that create or free communicators, windows, and files, which are a common source of order deadlocks [K]. Fix: add "those that create or free a communicator, window, or file included".
9. **STND.MPI.19:** "order-independent summation" departs from the custodian's "fixed or order-independent combination", and it fits max, min, or product badly. Fix: "combination".
10. **STND.MPI.20** covers loads and stores only of the holding process. Shared-memory windows let other processes on the node access the memory directly [K]. Fix: "by loads and stores of a process to that memory".
11. **Gap, progress:** add to .12: "The argument SHOULD rely on no progress of MPI outside MPI calls beyond what the MPI standard guarantees (DSGN.5)." See note 3.1 on passive-target waits.
12. **Class Note:** .12 s2 and s3 verify a protocol invariant, so they fall under the DSGN.15 row at CSQ2. The Note places .12 at CSQ3 only. List them under CSQ2.
13. **STND.MPI.24 s1:** a protocol that cannot run on one process needs a decision record, which blocks work needlessly. Fix: "Where its message protocol admits one process, ...".

### Optional

14. .16 s3 and .11 s1 overlap on requests. Keep the persistent-request free in one place.
15. .24 s3: "recorded before the comparison" restates VV.3 (GOV.31). Drop it.
16. .8 s3: duplicating the communicator costs a collective. Consider exempting a library whose protocol is only blocking collectives issued in the caller's order.
17. Notes: the attached send buffer is no longer only process-wide; MPI-4.1 added buffers per communicator and per session [K]. Freeing an active send request is legal MPI [K], so "the completion call that correct use already makes" overstates the case.
18. Notes: the items marked unverified about file handlers, window models, external32, sync-barrier-sync, and freeing predefined handles match my knowledge [K].
19. Notes on .25: "which the repository configuration names" reads as an obligation that is not in the body, and "deferred to the release" narrows RSRC.12. Reword both.
20. Low-priority gaps: which thread finalizes MPI; Fortran hazards with nonblocking buffers; partitioned communication.

The scope matches the custodian's directions. HW.GPU and STND.CXX stay separate, no product or version is named, and the reproducibility directions are met (apart from finding 9). .11 s2 and s3 parallel STND.CXX.20 in language-general form, which is acceptable. No provision asks for a decision of the human owner.

## Verdict

Not ready to ratify as rehearsed. Defects 1 and 2 make the binding provisions raise the floor (GOV.11); each needs one sentence reworded. After those and findings 3 to 13, the standard is sound, checkable, and faithful to the custodian's directions.
