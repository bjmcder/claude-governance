# Dispositions of the reviews of STND.MPI 0.1 (draft 0.2)

Sources: /home/claude/scratch-r6/review-cold-mpi.md (C) and /home/claude/scratch-r6/review-pairs-mpi.md (P). Provision numbers are unchanged from 0.1.

| Finding | Class | Disposition |
| --- | --- | --- |
| C1, P2: STND.MPI.6 s2 persistence raises the floor | Defect / should-fix | Fixed. STND.MPI.6 s2 now asks the process to "first complete the write of its diagnosis to a place that the operator reads (PRIME.4)". Persistence moved to the new STND.MPI.7 s3 (INTPR.8, default, from CSQ1 under its STND.CLASS.10 row). "Where the operator reads it" was flagged by g.12 as a trailing condition, so it reads "to a place that the operator reads". |
| C2, P1: STND.MPI.6 s1 removes degradation and safe state | Defect / should-fix | Fixed. "Each other process of that execution SHALL halt, or receive notice of that halt through MPI or its message protocol and respond to it as PRIME.4 requires". Halt, visible degradation, and the designed safe state all remain; the Notes give the coordinating-process example. |
| C3: fatal handler need not write a diagnosis | Should-fix | Fixed. The Notes mark it unverified. STND.MPI.7 s1 has the contract state whether the fatal handler writes a diagnosis, and the floor argument counts at most one error handler. |
| C4: errors that belong to no object | Should-fix | Fixed in STND.MPI.4 s1. The Notes mark the self-communicator fact unverified and name no revision. |
| C5, P3: placement and run-time library missing from STND.MPI.2 | Should-fix | Fixed. Added the MPI library loaded at run time and the placement of processes on nodes. |
| C6: STND.MPI.11 s3 conflicts with passed ownership | Should-fix | Fixed: "that another component owns". The Notes say ownership passes with a return value. |
| C7: STND.MPI.10 discourages sessions | Should-fix | Fixed. s1 and s2 now speak of the world model; s3 leaves world models and sessions to the component that initialized them. The Notes explain sessions. |
| C8: create and free calls in STND.MPI.17 | Should-fix | Fixed: "those that create or free a communicator, window, or file included". |
| C9: "summation" in STND.MPI.19 | Should-fix | Fixed: "order-independent combination". |
| P4: no tier-1 test for bitwise identity across process counts | Should-fix | Fixed. Added STND.MPI.19 s2 ("SHOULD judge identical bits (VV.3)"). STND.MPI.24 s3 now applies only where STND.MPI.19 does not govern, so the two do not conflict. |
| C10: shared-memory windows in STND.MPI.20 | Should-fix | Fixed: "by loads and stores of a process to that memory". |
| C11: progress rule | Should-fix | Fixed, folded into STND.MPI.12 s2 to stay at three modals: the argument relies "on no progress of MPI outside MPI calls beyond what the MPI standard guarantees (DSGN.15, DSGN.5)". |
| C12: onset of STND.MPI.12 s2 and s3 | Should-fix | Fixed. The class Note lists them at CSQ2 under DSGN.15; s1 stays at CSQ3. |
| C13: one-process run blocks protocols that need two processes | Should-fix | Fixed. STND.MPI.24 s1 now asks for at least three process counts, "among them the smallest number that its message protocol admits". No decision record is needed. |
| C14: requests in both .11 and .16 | Optional | Fixed. STND.MPI.11 s1 excludes requests; STND.MPI.16 keeps them. |
| C15: "recorded before the comparison" restates VV.3 | Optional | Fixed. Dropped. |
| C16: duplicating the communicator costs a collective | Optional | Fixed. STND.MPI.8 s3 now applies only where a library sends point-to-point messages; the Notes give the reason (collective operations match by order, not by tag). |
| C17: per-communicator buffers; freeing an active send request is legal | Optional | Fixed in the Notes (both unverified). The floor argument now counts a completion call only where code would otherwise free an active request. |
| C18: unverified items match the reviewer's knowledge | Optional | No change. They stay marked unverified, since the confirmation is [K] only. |
| C19: Notes on STND.MPI.25 | Optional | Fixed. Now "the project chooses the check", and deferral is "under RSRC.12 to the latest point at which its result is still needed". |
| C20: thread that finalizes; Fortran buffer hazards; partitioned communication | Optional | Declined for 0.2. Each needs facts the research note does not hold (no network). Proposed for the next revision. |
| P5: messages across hardware models and HW.13 | Optional | Fixed. Note sentence added. |
| P6: HW.5 range and STND.MPI.18 size | Optional | Fixed. Note cites HW.5 as the source of the size; the body is unchanged. |
| P7: random streams keyed to rank | Optional | Fixed. Note sentence added, citing DSGN.17. |
| P8: STND.MPI.18 and "identical recorded inputs" | Optional | Fixed. Note sentence added. |
| P9: HW.CPU.5 and co-located processes | Optional | Fixed. Note states the reading (all processes on one node), as for HW.8. |
| P, outside scope: 1.0 against 0.1 | Remark | No change. The files carry the label they will have when adopted (1.0), as earlier rounds did; the reading copy is titled draft 0.2. |
| Rehearsal g.11 on STND.MPI.10 s3, g.19 "manager" in the Notes | New | Fixed. Positive form for s3; "coordinating process" replaces "manager". |

## Verification of 0.2

Source: /home/claude/scratch-r6/verify-mpi.md (V). Result is draft 0.3.

| Finding | Class | Disposition |
| --- | --- | --- |
| V1: STND.MPI.7 s2 "that it does" | Should-fix | Fixed: "Where that contract does not establish that such an end ends the other processes, ...". |
| V2: STND.MPI.6 s1 limits the route of notice | Should-fix | Fixed. "Through MPI or its message protocol" deleted. The Notes give MPI, the message protocol, a signal from the launcher, and a supervising process as examples. |
| V3: floor paragraph narrates a pending decision | Should-fix | Fixed. The Notes give the argument as the standard's reasoning ("Neither raises the floor (GOV.11), for these reasons."), with no mention of drafting or decision. The ruling sentence is added at ratification. The rationale in apply_mpi.py now ends "and so raise no floor (GOV.11)". |
| V4: STND.MPI.19 s2 vs STND.VVUQ.1 tier 1 | Should-fix | Fixed by a Note: where the acceptance criterion fixed under VV.3 is bitwise identity across process counts, that criterion governs, and the tier of STND.VVUQ.1 does not lower it. |
| V5: STND.MPI.24 s1 with fewer admitted counts | Should-fix | Fixed: "at least three numbers of processes that its message protocol admits, the smallest among them, or on each number that it admits, whichever set is smaller". The verifier's "where it admits fewer" drew a g.12 finding (trailing condition), so it is worded without one. |
| V6: "apply" should be "applies" | Optional | Fixed. |
| V7: "the world model"; query finalization | Optional | Fixed in STND.MPI.10 s2 and s3. |
| V8: "is the basis for the size" | Optional | Fixed. |
| V9: HW.13 s2 is a permission | Optional | Fixed: "is able to enter that boundary contract through the permission of the second sentence of HW.13". |
| V10: "ends them" against "best attempt" | Optional | Fixed: "is meant to end them". |
| V11: reading of HW.CPU.4 and HW.CPU.5 | Optional | Fixed. Marked as this standard's own reading of those defaults. |
| V12: "MPI library" clashes with the Library term | Optional | Fixed: "the library of the MPI implementation that the processes load at run time". |
| V13: label disposition inaccurate | Optional | Fixed. The earlier row was accurate only for /home/claude/scratch-mpi/draft.md, which is now titled draft 0.3. Other copies, among them rc/mpi-0.1-draft.md, are not mine and carry the adopted heading. |
