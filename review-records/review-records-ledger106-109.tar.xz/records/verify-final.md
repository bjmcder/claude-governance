# Final check: STND.ANNEX and STND.MPI, last revision (2026-10-23)

Scope: the diffs from v02 to pkg for both content and apply scripts, checked against verify-annex.md and verify-mpi.md. The rehearsed corpus carries the new text. Bodies of ANNEX and MPI contain no excluded words. Changed provisions have at most three modals, and ANNEX titles are unique. I read verify.log (PASS) but did not rerun verify.

## Findings

### Defect

1. **ANNEX.9 sentence 2 conflicts with the new fault fallback (Defect 1 is only partly resolved).** The rows now say "and otherwise undetected", and the Limits Stated cell is correct. But sentence 2 still reads every property that the supplier's documentation does not state as "not established". For a supplier's configuration, a fault kind the documentation omits therefore falls under both readings, and the "not established" reading escapes HW.10. *Fix:* in sentence 2, write "and each other property that this documentation does not state, other than a kind of hardware fault, as not established".

### Should-fix

2. **ANNEX.3 sentence 2 overlaps the new ANNEX.2 sentence 2.** ANNEX.3 covers reliance on any unstated property, so at CSQ2 and CSQ1 arithmetic and variation reliance falls under both provisions. The Notes and the apply rationale say "other reliance under STND.ANNEX.3", which claims the two do not overlap. *Fix:* ANNEX.3 sentence 2 should read "a property of its execution path, other than one of delivered arithmetic or of run-to-run variation, that the default contract does not state".
3. **MPI.24 sentence 1: "the smallest among them" lost its referent.** It now reads as the smallest of the chosen set, which is always true and adds nothing. The test at the protocol's minimum count is lost. *Fix:* "on at least three numbers of processes that its message protocol admits, among them the smallest that it admits, or on each number that it admits, whichever set is smaller". Apply the same wording to the apply_mpi rationale.

### Optional

4. ANNEX Purpose: "At the custodian's direction" gives no date, and the closing "(GOV.18)" repeats the citation already in the sentence. Write "direction of 2026-10-23" and drop the parenthesis.
5. The MPI Notes list of routes (MPI.6) reads as a closed list. Add "among other routes".
6. The MPI.24 Note does not mention the case where the protocol admits fewer than three counts.
7. The content_annex.py docstring still says "draft 0.2".

## Requested fixes

| Item | Status |
| --- | --- |
| ANNEX D1 | Partly (finding 1) |
| ANNEX D2 | Resolved. Basis is HW.EMBED.4; ANNEX.2 covers it from CSQ3 (HW.EMBED.4 instantiates DSGN.5 and VV.1, so ANNEX.2 stays a default); ANNEX.8 refers_to and the class Note are updated. |
| ANNEX S3 | Resolved, with finding 2 |
| ANNEX S4, S5, S6 | Resolved |
| ANNEX O7 | Partly (finding 4) |
| ANNEX O8 to O11 | Resolved |
| MPI S1, S2 | Resolved. The binding sentence of MPI.6 no longer narrows the routes by which notice arrives. |
| MPI S3 | Resolved. GOV.11 needs no custodian ruling, the statement holds on adoption, and the rationale matches. |
| MPI S4 | Resolved. The Note agrees with the MPI.24 Note. |
| MPI S5 | Partly (finding 3) |
| MPI O6 to O12 | Resolved |
| MPI O13 | Partly (the docstring says 0.3; the reading-copy heading is unchanged by design) |

No change raises the floor, sets a class onset early, makes a provision binding, names a product, or puts an obligation in the Notes.

## Verdict

Not ready to present. Three one-phrase edits are needed: ANNEX.9 sentence 2 (finding 1), ANNEX.3 sentence 2 (finding 2), and MPI.24 (finding 3). After those, both drafts are ready. The Optional items can wait.
