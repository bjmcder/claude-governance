# Verification r6b

## Findings

**D1 (Defect), STND.VVUQ.82 s1: misses the named cases.** HW.12 covers runs on identical recorded inputs. Thread count, process count, and hardware type are recorded inputs (STND.VVUQ.1 tier 1, STND.MPI.2), as the MPI Notes concede. The VVUQ and MPI Notes nevertheless claim the body settles those differences. Fix s1: "Where every source of a difference between compared results is stated in the declaration of run-to-run variation of a compared execution path (HW.12) or in the records of the compared runs, and the difference lies within the agreement that the acceptance criterion of the comparison fixed under STND.VVUQ.1 before the comparison, the difference SHOULD NOT be treated as a defect (REPRO.3, VV.3)." Do not cite STND.MPI.18, which entry 109 adopts later.

**D2 (Defect), s1: "the tier that admits those sources" is not unique.** Tiers 3 to 6 all admit rounding, so a looser tier can excuse a difference. With no bitwise exception, a tier-3 difference is also "no defect" where STND.VVUQ.2 or STND.MPI.19 make bitwise identity the criterion. That conflicts with VV.3 and STND.MPI.19. The D1 wording fixes both:
- A wrong tier fails STND.VVUQ.1.
- An excess fails the comparison.
- An undeclared source fails the condition.

**S1 (Should-fix), VVUQ Note.**
- Replace "not by further investigation" with: "A difference beyond that agreement, or one that remains with the declared sources held fixed, is outside STND.VVUQ.82; loosening its tolerance is the decision of STND.VVUQ.8."
- "Remains available" becomes "is permitted".
- Drop "its cost stated as RSRC.1 asks".

**S2 (Should-fix), MPI Note.** "Code is not changed only to remove it" states a recommendation as fact. Use "STND.VVUQ.82 recommends against a change made only to remove it". This Note also depends on D1.

**S3 (Should-fix), ANNEX Note.** STND.ANNEX.6 already takes the compiler's and library's documented accuracy for the path's settings. Only a stronger accuracy from another source goes under STND.ANNEX.2. Reword: "where documentation other than that of the compiler and runtime libraries, that of the hardware model for example, states a stronger accuracy, STND.ANNEX.2 has the citing contract state it in place of the default". The Note adds no obligation.

**S4 (Should-fix), MPI rationale.** Add "and of 2026-10-24 on determinism (STND.VVUQ.82)". The floor clause matches the Notes. Not verified: the source of "all processes of one run are read as one execution path of HW.8".

**No finding:**
- Drafting rules hold.
- Mode is default, onset CSQ3.
- None of the 22 pairs conflicts.
- Ledger order is 106 to 109, and verify passes (g.18 warning not traced).

**Q3: recommended.** STND.VVUQ does not apply at CSQ4, where the churn occurs. GOV.11 (keep exploratory overhead low) grounds a binding rule that adds only one record. Proposed: STND.VVUQ.83 "Agent conduct toward known variation", binding, instantiates GOV.11, GOV.48, PRIME.2:
> Where every source of a difference between compared results is stated in the record of the work, and the difference lies within the agreement that the work fixed for the comparison, an agent SHALL NOT, on its own initiative, change the work only to remove that difference (GOV.11, GOV.48). Where the work states no acceptance criterion of bitwise identity, an agent SHALL NOT, on its own initiative, extend a unit of work only to make results identical across numbers of threads, numbers of processes, or hardware types (GOV.11, GOV.48). An agent SHALL state in its work report each difference that it leaves under this provision, with its source (PRIME.2, GOV.48).

It asks no owner decision; fixing a race stays open.

## Verdict

Not ready: one revised s1 fixes D1 and D2. S1 to S4 are wording fixes. Q3 is recommended.
